% Renders figure 10.
% The shaded bifurcation estimate was drawn in manually within Adobe Illustrator, and is just
% region between 0.05 and 0.055 uM (based on the transition seen in the RDE_prepol result).
load('fig10_data');

% Use nanmean/nanstd since the particle-based data has some nans
% nans correspond to the missing replicates at 0.150 (n=3) and 0.155 uM (n=4)
% compared to the n=5 replicates at all other levels.
PDE600s_means = nanmean(PDE_600s_Hr2);
PDE600s_stds = nanstd(PDE_600s_Hr2);
PDE1800s_means = nanmean(PDE_1800s_Hr2);
PDE1800s_stds = nanstd(PDE_1800s_Hr2);
PB600s_means = nanmean(pb_H2ums,2); % the matrix is rotated
PB600s_stds = nanstd(pb_H2ums,[],2);

figure; hold on;
errorbar(pde_concs,PDE600s_means,PDE600s_stds,'linestyle','none','marker','^','markerfacecolor',[1 1 0],'markeredgecolor','k','color','k','markersize',10);
errorbar(pde_concs,PDE1800s_means,PDE1800s_stds,'linestyle','none','marker','square','markerfacecolor',[1 0 0],'markeredgecolor','k','color','k','markersize',10);
plot(RDE_prepol.concs,RDE_prepol.Hr2,'linestyle','none','marker','diamond','markerfacecolor','g','markeredgecolor','k','color','k','markersize',10);
errorbar(pb_concs,PB600s_means,PB600s_stds,'linestyle','none','marker','o','markerfacecolor','b','markeredgecolor','k','color','k','markersize',10);

axis([0 0.35 -0.2 3]);
set(gca,'fontsize',20);

