load('fig8_data');
figure;
subplot(2,3,1); hold on; box on;
plot(pb100.x,pb100.y,'r.','linestyle','none');
plot([-4 -3],[-4 -4],'k','linewidth',4);
set(gca,'xtick',[],'ytick',[]);
axis image;
axis([-4.4311 4.4311 -4.4311 4.4311]);
subplot(2,3,2); hold on; box on;
plot(pb200.x,pb200.y,'r.','linestyle','none');
plot([-4 -3],[-4 -4],'k','linewidth',4);
set(gca,'xtick',[],'ytick',[]);
axis image;
axis([-4.4311 4.4311 -4.4311 4.4311]);
subplot(2,3,3); hold on; box on;
plot(pb600.x,pb600.y,'r.','linestyle','none');
plot([-4 -3],[-4 -4],'k','linewidth',4);
set(gca,'xtick',[],'ytick',[]);
axis image;
axis([-4.4311 4.4311 -4.4311 4.4311]);

subplot(2,3,4)
histogram2('xbinedges',pb100_hist.x,'ybinedge',pb100_hist.y,'bincount',pb100_hist.counts,'facecolor','r');
subplot(2,3,5)
histogram2('xbinedges',pb200_hist.x,'ybinedge',pb200_hist.y,'bincount',pb200_hist.counts,'facecolor','r');
subplot(2,3,6)
histogram2('xbinedges',pb600_hist.x,'ybinedge',pb600_hist.y,'bincount',pb600_hist.counts,'facecolor','r');
