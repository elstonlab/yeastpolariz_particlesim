%%%%%%%%%%%%%%%%%%%%%%%%
% Process the raw data
%%%%%%%%%%%%%%%%%%%%%%%%
load('fig7_data');
brownian_time_mean = zeros(1,4);
brownian_time_std = zeros(1,4);
integral_time_mean = zeros(1,4);
integral_time_std = zeros(1,4);

brownian_realiz_mean = cell(1,4);
brownian_realiz_std = cell(1,4);
integral_realiz_mean = cell(1,4);
integral_realiz_std = cell(1,4);

for i=1:4 % # concentration levels
   % Realization average for Panel C
   brownian_realiz_mean{i} = mean(cell2mat(brownian(:,i)));
   brownian_realiz_std{i} = std(cell2mat(brownian(:,i)));
   integral_realiz_mean{i} = mean(cell2mat(integral(:,i)));
   integral_realiz_std{i} = std(cell2mat(integral(:,i)));
   % Time average for Panel D
   brownian_time_mean(i) = mean(brownian{1,i});
   brownian_time_std(i) = std(brownian{1,i}); 
   integral_time_mean(i) = mean(integral{1,i});
   integral_time_std(i) = std(integral{1,i}); 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting
% Uses jbfill, superbar, and supererr for plotting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
colors = [0 0.447 0.741; 0.85 0.325 0.098];
yaxs = [-5 15; 5 35; 20 60; 80 160];
yticks = {-5:5:15; 5:10:35; 20:20:60; 80:40:160};


% Panel C
figure;
for i=1:4 % concentration levels
    subplot(2,2,i); 
    jbfill( 0:dt:t_end,integral_realiz_mean{i}+integral_realiz_std{i},...
                       integral_realiz_mean{i}-integral_realiz_std{i},colors(2,:),'none');
    jbfill(dt:dt:t_end,brownian_realiz_mean{i}+brownian_realiz_std{i},...
                       brownian_realiz_mean{i}-brownian_realiz_std{i},colors(1,:),'none');
    set(gca,'xlim',[0 50],'fontsize',22,'xtick',[0 25 50],...
            'ytick',yticks{i},'ylim',yaxs(i,:),'linewidth',4,'fontname','arial');
end

% Panel D
figure;
barmean = [brownian_time_mean',integral_time_mean'];
barstd  = [brownian_time_std', integral_time_std'];
barcolors = zeros(4,2,3);
for i=1:4
    barcolors(i,1,:) = colors(1,:);
    barcolors(i,2,:) = colors(2,:);
end
for i=1:4 % concentration levels
    superbar(barmean,'E',barstd,'BarFaceColor',barcolors);
end
ylabel('Particles in explicit region')
set(gca,'ylim',[0 140],'ytick',0:20:140,'xtick',1:4,'xticklabel',{'0.01 \muM','0.05 \muM','0.1 \muM','0.3 \muM'},'fontsize',18,'fontname','arial');
set(gca,'xlim',[0.6 4.4])
children = get(gca,'children');
legend(children([15 9]),'Brownian dynamics','Injection/ejection method','location','northwest')
