
parameters_eta1_polar;

%BemGEF_tot2d  = 8.82;
%Cdc42_tot2d  = 145.46;
%Dconst=0.0025;
%Dconst_cyt=15;


syms y1 y2 y3 y4 y5 y6
syms l k2

%Cdc42T
%BemGEF42
%BemGEF
%Cdc42D		 
%Cdc42Dc
%BemGEFc

%L=(1.817*2); % full length of window
k2min=(2*pi/L)^2;

maxls=[];

%for Dconst = [0.0025 0.005 0.01 0.1 1]
%Dconst=0.01;
%for k3 = [0.3 0.1 0.05 0.01] 
%NCdc42s=[800:100:2000 773]
set_maxls=[];

%for NCdc42 = NCdc42s

%	Cdc42_tot=NCdc42/L^2;

fun = @rates;
x0=[Cdc42_tot/2, BemGEF_tot, 0, Cdc42_tot/2];
x=fsolve( @(x)fun(x,BemGEF_tot,Cdc42_tot,k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7),x0)

x=[x (Cdc42_tot-x(1)-x(2)-x(4)) (BemGEF_tot-x(2)-x(3))]

Nsp=size(x,2);

%calculate symbolic jacobian
fun_full = @rates_full;
Jsymb=vpa(jacobian(fun_full([y1,y2,y3,y4,y5,y6],k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7),[y1,y2,y3,y4,y5,y6]));

%substitute in symbolic jacobian the equilibrium values
A=double(subs(Jsymb,[y1,y2,y3,y4,y5,y6],[x(1),x(2),x(3),x(4),x(5),x(6)]));
D=diag([Dconst Dconst Dconst Dconst Dconst_cyt Dconst_cyt]);
Det=(det(l*eye(Nsp)-A+D*k2));
%compute lambda(k^2)


%k2_is=[0:0.1:10];

%for k2_i=k2_is;
%	k2_i
%	maxl= max(real(solve(vpa(subs(Det,k2,k2_i)))))
%	maxls=[maxls maxl];
%end

%set_maxls=[set_maxls ; maxls];

maxl= max(real(solve(vpa(subs(Det,k2,k2min)))))
%NCdc42
maxls=[maxls maxl];

%end

%for i = [14 3 6 9]
%	plot(k2_is,set_maxls(i,:))
%	xlim([0 10]);
%	hold on
%end
%set(gca,'fontsize',18);
%xlabel('k^2');
%ylabel('Re[\lambda (k^2)]');	
%yPos = 0;
%xPos = (2*pi/L)^2;
%hold on
%plot(get(gca,'xlim'), [yPos yPos],'black'); % Adapts to x limits of current axes
%plot([xPos xPos],get(gca,'ylim'), 'black'); % Adapts to y limits of current axes
%hold off
%ax=gca;
%ax.XTick = [0 (2*pi/L)^2 5 2*(2*pi/L)^2 10];
%ax.XTickLabels={'0','k_{01},k_{10}','5','k_{11}','10'};
%legend(['nCdc42 =' num2str(NCdc42s(14))],['nCdc42 =' num2str(NCdc42s(3))],['nCdc42 =' num2str(NCdc42s(6))],['nCdc42 =' num2str(NCdc42s(9))]);

%plot([0:0.1:15], maxls)