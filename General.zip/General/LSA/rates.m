
function F = rates(x,BemGEF_tot,Cdc42_tot,k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7)


	%Cdc42T
	F(1) = (k2a *x(3) +k3 *x(2) )*x(4) - k2b*x(1)  - k4a*x(3)*x(1)  + k4b*x(2)  - k7*(BemGEF_tot - x(2) - x(3))*x(1);
	%BemGEF42
	F(2) = k4a*x(3)*x(1) - k4b*x(2) + k7*(BemGEF_tot - x(2) - x(3))*x(1);   
    %BemGEF
	F(3)= k1a*(BemGEF_tot - x(2) - x(3)) - k1b*x(3) - k4a*x(3)*x(1) + k4b*x(2);
	%Cdc42D		 
	F(4) = k2b*x(1)  - (k2a *x(3) +k3 *x(2))*x(4) - k5b*x(4) + k5a*(Cdc42_tot - x(1) - x(4) - x(2));
