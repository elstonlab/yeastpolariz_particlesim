%%
% global so we don't have to pass into Euler function 

global k1a 
global k1b
global k2a  
global k2b 
global k3 
global k4a 
global k4b 
global k5a 
global k5b 
global k7 
global eta
global s
global s2
global N
global Ndw;

%% Set parameters
N = 50;     %number of spatial grid points 
Nspecies=6;%number of species diffusing
Ndw=5; %number of dw terms in stochastic reaction step
dtR=0.0002;             %aimed reaction time step 
nRsteps = 1;        %aimed number of reaction time steps per diffusion time step 
dtD = dtR*nRsteps; % aimed diffusion time step
time_save=1;
Dconst = 0.0025;                % diffusion coefficient, D
Dconst_cyt=15;

% variables for time-stepping
interval = 10;      % number of seconds to simulate, int
tsteps_rnd=1000; %random numbers will be generated every tsteps_rnd steps
%Cellsize = 5;								% sphere diameter (microns) including membrane width

%L=(0.5*1e8*2);%4.1;
L=(1.817*2);
%L=4.431*2;

Nav=6.022e23; 								% Avogadro's number
%eta = 0.01;  %eta: Vm/Vc, membrane/cytoplasm volume correction
%eta=(R^3-(R-width)^3)/(R-width)^3        with R = cell radius = Cellsize/2
%membrane_width=(Cellsize/2)*(1-(1/((eta+1)^(1/3)))); %membrane width 
membrane_width=0.0083; %membrane width 
dx=L/N;
%dx  = Cellsize*sqrt(pi)/N;          % spatial meshsize (1D)

%Vcyt=4/3*pi*(Cellsize/2)^3*10^-15; 		%cytosol volume (L)

%Vi=dx*dx*membrane_width*10^-15;			%bin volume (L)
%noise strength
s=1; %reaction
s2=1; %diffusion


k1a_uM = 10;       %s-1,       BemGEFc -> BemGEF
k1b_uM = 40;       %s-1,       BemGEF -> BemGEFc
%% GEF
k2a_uM = 0.1999;%0.0151;     %uM-1.s-1,  BemGEF + Cdc42D -> Cdc42T + BemGEF
k3_uM  = 0.9209;%;0.1793;     %uM-1.s-1,  BemGEF42 + Cdc42D -> Cdc42T + BemGEF42
%%GAP
k2b_uM = 0.35;    %s-1,       Cdc42T -> Cdc42D 
%%BemGEF42
k4a_uM = 0.2723;%0.0489;       %uM-1.s-1,  BemGEF + Cdc42T -> BemGEF42
k4b_uM = 31.3787;%10;%34.2806;       %s-1,       BemGEF42 -> BemGEF + Cdc42T
k7_uM  = 10;       %uM-1.s-1,  BemGEFc + Cdc42T -> BemGEF42
%%GDI (Cdc42 exchange)
k5a_uM = 36;		%s-1		Cdc42c -> Cdc42
k5b_uM = 13;		%s-1		Cdc42 -> Cdc42c




% reaction constants molecules/bin units

% Example for a conversion, the dimensions of each quantity is shown in []
%	d A[uM]/dt = k_uM B[uM]D[uM]      A, B and D in membrane 

%	A[uM] = nAi[molecules/bin] / (Vbin[L/bin]*Nav*10^-6[molecules/umol]) 

% 	dnAi/dt = k_uM*nBi*nDi/(Vbin*Nav*10^-6) 
%	k in molecules/bin is k_uM/(Vbin*Nav*10^-6) 

% dA/dt = = k B D
% dA2d/dt a/v = k B2d a/v D2d a/v
% d nAi/ai /dt = k/th nBi/ai nD/ai       k/th = k2d
% d nAi /dt = k/(th*ai) nBi nD

%k3d[uM^-1s^-1]
%k3d[L/(10^-6*Nav*part*s)]
%k3d[10^15um^3/(10^-6*Nav*part*s)]
%k2d=k3d/th=k3d*10^15um^3/(10^-6*Nav*part*s*0.0083um) 
%k2d=k3d*10^15*10^6*10^-23/(0.0083*6.022)
%k2d=k3d/(0.83*6.022)[um^2/(s*part)]


%BemGEF exchange  
k1a = k1a_uM;			       	%s-1,       BemGEFc -> BemGEF
k1b = k1b_uM;       			%s-1,       BemGEF -> BemGEFc
% GEF
k2a = k2a_uM/(membrane_width*100*6.022);	%um^2/(s*part),  BemGEF + Cdc42D -> Cdc42T + BemGEF
k3  = k3_uM/(membrane_width*100*6.022);		%um^2/(s*part),  BemGEF42 + Cdc42D -> Cdc42T + BemGEF42

%k3=k3_uM/(dx*dx*membrane_width*10^-15*Nav*10^-6)
%  =k3_uM/(Ai*membrane_width*10^-15*Nav*10^-6)
%  =k3_2d/Ai

%dA2d/dt = k2d B2d C2d
%d(nAi/Ai)d/dt = k2d nBi/Ai nCi/Ai
%d(nAi)d/dt = k2d nBi/Ai nCi
%d(nAi)d/dt = k2d/Ai nBi nCi

	
%GAP
k2b = k2b_uM;    				%s-1,       Cdc42T -> Cdc42D 
%BemGEF42
k4a = k4a_uM/(membrane_width*100*6.022);	%um^2/(s*part),  BemGEF + Cdc42T -> BemGEF42
k4b = k4b_uM;       			%s-1,       BemGEF42 -> BemGEF + Cdc42T
k7  = k7_uM/(membrane_width*100*6.022);	%um^2/(s*part),  BemGEFc + Cdc42T -> BemGEF42
%GDI (Cdc42 exchange)
k5a = k5a_uM;		%Cdc42c -> Cdc42
k5b = k5b_uM;		%Cdc42 -> Cdc42c


%Cdc42_tot2d=145.46; %molecules/um2
%BemGEF_tot2d=8.82;

%Cdc42_tot2d=1921/(L^2); %molecules/um2
%BemGEF_tot2d=24/(L^2);

Cdc42_tot2d=1921/(L^2); %molecules/um2
BemGEF_tot2d=1249/(L^2);


Cdc42_tot=Cdc42_tot2d; %comment when Cdc42_tot is a variable on functions
BemGEF_tot=BemGEF_tot2d;




%BemGEF_tot = 0.06*Vcyt*Nav*10^-6;
%Cdc42_tot = 1*Vcyt*Nav*10^-6;

%load homogenous steady states in uM
%load('HSS.mat');

% convert uM to molec/(bin) or molec/(cyt)
%Cdc42T0   = Cdc42T0*Vi*Nav*10^-6;



