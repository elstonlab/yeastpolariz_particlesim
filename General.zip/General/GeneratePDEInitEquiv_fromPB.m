% Script to generate initialization 'correction' matrices for the PDE
% systems.

% Generates a set of 100x100 matrices normalized to total particle counts
% of each type (i.e. the Cdc42T_pdeinit would be normalized to total Cdc42
% molecules). I normalize the GEF42 matrix to total GEF as an arbitrary
% ref.

% This pixellation is meant to provide the PDEs a reasonable starting point
% with respect to random polarization induced by noise.
% ======================================================================

% Load the file outside of the script.

disp(strcat('Using file ',{' '},outfile,{' '},'for pixellation.'))

disp('Extracting coordinate trajectories.')
CoordExtractor; % Extract Trajectories.

targetSimIdx = 10; % What grainstep to select for pixellation. 
                   % 10 = 1 s, 100 = 10 s, 500 = 50 s.

fprintf('Using a snapshot at %g seconds.\n',targetSimIdx*datagrain*dt);

[Cdc42T_pdeinit,~,~] = histcounts2(Cdc42T_Trajectories(:,targetSimIdx,1),...
                                   Cdc42T_Trajectories(:,targetSimIdx,2),...
                                   'numbins',[100 100],...
                                   'xbinlimits',[-xwin xwin],...
                                   'ybinlimits',[-ywin ywin]);
[Cdc42Dm_pdeinit,~,~] = histcounts2(Cdc42Dm_Trajectories(:,targetSimIdx,1),...
                                    Cdc42Dm_Trajectories(:,targetSimIdx,2),...
                                    'numbins',[100 100],...
                                    'xbinlimits',[-xwin xwin],...
                                    'ybinlimits',[-ywin ywin]);
[GEFm_pdeinit,~,~] = histcounts2(GEFm_Trajectories(:,targetSimIdx,1),...
                                 GEFm_Trajectories(:,targetSimIdx,2),...
                                 'numbins',[100 100],...
                                 'xbinlimits',[-xwin xwin],...
                                 'ybinlimits',[-ywin ywin]);
[GEF42_pdeinit,~,~] = histcounts2(GEF42_Trajectories(:,targetSimIdx,1),...
                                  GEF42_Trajectories(:,targetSimIdx,2),...
                                  'numbins',[100 100],...
                                  'xbinlimits',[-xwin xwin],...
                                  'ybinlimits',[-ywin ywin]);

totalCdc42 = nCdc42tot;%nCdc42Dm + nCdc42Dc + nCdc42T;
totalGEF   = nGEFtot;%nGEFm + nGEFc + nGEF42;         

Cdc42T_pdeinit = Cdc42T_pdeinit / totalCdc42;
Cdc42Dm_pdeinit = Cdc42Dm_pdeinit / totalCdc42;
GEFm_pdeinit = GEFm_pdeinit / totalGEF;
GEF42_pdeinit = GEF42_pdeinit / totalGEF;

Cdc42Dc_pdeinit = ones(100); % Before adding initial noise I would work with
GEFc_pdeinit = ones(100);    % fully inert cytoplasmic species.

Cdc42Dc_pdeinit = Cdc42Dc_pdeinit - Cdc42T_pdeinit - Cdc42Dm_pdeinit - GEF42_pdeinit * (totalGEF/totalCdc42);
GEFc_pdeinit = GEFc_pdeinit - GEFm_pdeinit - GEF42_pdeinit;

disp('Careful! Rows of pdeinit matrices correspond to the y axis (going up).')
disp('Careful! Cols of pdeinit matrices correspond to the x axis (going right).')
save(savefilename,'Cdc42T_pdeinit','Cdc42Dm_pdeinit','Cdc42Dc_pdeinit','GEFm_pdeinit','GEFc_pdeinit','GEF42_pdeinit')