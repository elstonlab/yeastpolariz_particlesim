function [r_vals,H600s,H1800s] = PDE_Hfn_clustQuant_600s1800s(filename)
% =====================================================================
% Implementation of the H-function for reaction-diffusion, PDE-simulated
% data.
% Uses a rescaled version of a well-known clustering metric.
% The H-function is a modification of the established Ripley's K-function.
% It is defined using the cumulative distribution of inter-particle
% distances, 
%          / r
%  K(r) =  |    P(r')dr'
%          / 0
%
% where P(r)dr is the probability of finding a particle lying between r and
% r + dr.
%
% Then, H(r) is defined as
%           ___________
%          |  L^2
% H(r) =  \| ____ K(r)   - r
%          |  pi
%
% where the -r represents the contribution from a complete spatial random 
% distribution. Therefore, non-zero H(r) represents deviation from complete
% spatial randomness at the particular inter-particle distance r.
%
% See Wehrens M, Rein ten Wolde P, and Mugler A. J Chem Phys 2014, 141,
% 205102-1 for more details.*
% *Note - Wehrens et al. do not derive P(r) f in the context of RD-PDEs.
% =====================================================================

% Load data
load(strcat(filename,'_tc.mat'));
load(strcat(filename,'.mat'));

% Get expected length of r_vals
[xs,~,~] = estimatePCF_PDE(RT_tc(end-99:end,:) +...
                           M_tc(end-99:end,:),...
                           xwin,xwin,N);
[~,Xedges] = histcounts(xs,'binwidth',0.02,'binlimits',[0 sqrt( (xwin*2)^2 + (xwin*2)^2 )/2;],'normalization','probability');
binCents_X = mean([Xedges(1:end-1);Xedges(2:end)]);
r_vals = binCents_X;

H_tc_vals = zeros(interval,length(r_vals));
for simt=1:1:interval
    if simt == 600 || simt == 1800
        fprintf('Time point %i of %i\n',simt,interval);
        [xs,~,~] = estimatePCF_PDE(RT_tc(100*(simt-1)+1:100*(simt-1)+100,:) +...
                                   M_tc(100*(simt-1)+1:100*(simt-1)+100,:),...
                                   xwin,xwin,N);

        % Normalize frequency distributions to get P(r)
        [freqX,Xedges] = histcounts(xs,'binwidth',0.02,'binlimits',[0 sqrt( (xwin*2)^2 + (xwin*2)^2 )/2;],'normalization','probability');
        pr_X = freqX / (Xedges(2) - Xedges(1));
        binCents_X = mean([Xedges(1:end-1);Xedges(2:end)]);

        %% ===========================
        %  Compute H-value
        %% ===========================
        r_vals = binCents_X;
        H_vals = zeros(length(r_vals),1);
        % The first value is zero.
        for i=1:length(r_vals)
            if i == 1
                H_vals(i) = 0;
            else
                H_vals(i) = sqrt( (2*xwin)^2 / pi * trapz(r_vals(1:i),pr_X(1:i))) - r_vals(i);
            end
        end
        H_tc_vals(simt,:) = H_vals;
    end
end
H600s = H_tc_vals(600,:);
H1800s = H_tc_vals(1800,:);
save(strcat(filename,'_Hfn_600s1800s.mat'),'r_vals','H600s','H1800s')

end

function [xdists,xs,ys] = estimatePCF_PDE(concDist,xwin,ywin,N)
npairs = 500000;

% Generate vectors to select random pairs of points
randVal1  = rand(1 ,npairs); 
randVal2  = rand(1 ,npairs);

% Generate vectors to perturb the particle within a given bin
randBinPerturbx_12 = rand(2, npairs);
randBinPerturby_12 = rand(2, npairs);

simBinLen = 2*xwin/N;

xdists = zeros(1,npairs);
xs = zeros(1,npairs*2); ys = zeros(1,npairs*2);
% Generate CDF from linearized matrix
concDist = reshape(concDist,1,N^2); % Linearize
concDist = cumsum(concDist);        % CDF
concDist = concDist / concDist(end); % Normalize

parfor n=1:npairs
    [xmeshs,ymeshs] = meshgrid(linspace(-xwin+simBinLen,xwin-simBinLen,N),...
                               linspace(-ywin+simBinLen,ywin-simBinLen,N));
    idx1 = find(concDist>randVal1(n),1); % Get index of first value 
    idx2 = find(concDist>randVal2(n),1); % greater than the random #
    
    [row1,col1] = ind2sub([N,N],idx1); % Get row,column from linearized index
    [row2,col2] = ind2sub([N,N],idx2);
        
    xlocs = [xmeshs(row1,col1); xmeshs(row2,col2)]; % Get (x,y) coords
    ylocs = [ymeshs(row1,col1); ymeshs(row2,col2)];
    
    % Randomly perturb the location 'within' the bin defined by the PDE
    xlocs = xlocs + simBinLen*(randBinPerturbx_12(:,n) - 0.5);
    ylocs = ylocs + simBinLen*(randBinPerturby_12(:,n) - 0.5);
    
    xs(n) = xlocs(1); ys(n) = ylocs(1);
    diffx = xlocs(1) - xlocs(2); % Precalculate differences for speed
    diffy = ylocs(1) - ylocs(2);
    
    % Metric for periodic boundaries.
    xdists(n) = (min(abs(diffx), xwin*2-abs(diffx))).^2 + ...
                (min(abs(diffy), ywin*2-abs(diffy))).^2;
end
xdists = sqrt(xdists);
end

