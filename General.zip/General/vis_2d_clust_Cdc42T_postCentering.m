% Visualize Cdc42-GTP distributions from simulations. Saves a movie
% in the same location as the datafile.
function vis_2d_clust_Cdc42T_postCentering(filename)

load(strcat(filename,'_par.mat')); % Parameters
load(strcat(filename,'_dat.mat')); % Raw data


% These are strictly defined, as using 'State' below.
Cdc42T_Trajectories  =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);
GEF42_Trajectories   =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);

%% ---------------------------------------------
% State (for CoordTracker)
%    GEFm    = 1    Cdc42Dm = 4
%    GEFc    = 2    Cdc42Dc = 5
%    GEF42   = 3    Cdc42T  = 6
%% ---------------------------------------------

for i=1:nCdc42tot+nGEFtot
    for j=1:1:nsteps/datagrain
        if CoordTracker(j,i,3)==3
            GEF42_Trajectories(i,j,1) = CoordTracker(j,i,1);
            GEF42_Trajectories(i,j,2) = CoordTracker(j,i,2);
        elseif CoordTracker(j,i,3)==6
            Cdc42T_Trajectories(i,j,1) = CoordTracker(j,i,1);
            Cdc42T_Trajectories(i,j,2) = CoordTracker(j,i,2);
        end
    end
end

Cdc42T_Trajectories(Cdc42T_Trajectories==0) = nan;
GEF42_Trajectories(GEF42_Trajectories==0)       = nan;

posT=vertcat(Cdc42T_Trajectories,GEF42_Trajectories(1:nGEFtot,:,:));

posTx=squeeze(posT(:,:,1));
posTy=squeeze(posT(:,:,2));

% UNCOMMENT TO RECENTER COORDINATES: AVOID POLARITY SITE WRAPPING AROUND EDGE ======
% [newposTx,newposTy] = recenterCoordinates(posTx,posTy,50,xwin,ywin);
% ==================================================================================

newposTx = posTx;
newposTy = posTy;

%% ------------------------------------------------------------------------------------
% Produce a movie! Figure window dimensions may need adjustment depending on your screen.
%% ------------------------------------------------------------------------------------
scrsz=get(groot,'ScreenSize');
if ismac
    scrsz=scrsz./1.75;
end
f=figure('Position',[100 scrsz(4)/2-100 scrsz(3)/1.75 scrsz(4)/1.25]);
set(gcf,'OuterPosition',f.OuterPosition);
hold on
xlabel('X position (\mum)')
ylabel('Y position (\mum)')
%set(gca,'fontsize',16,'fontname','arial','ytick',[-2 -1 0 1 2],'yticklabel',[-2 -1 0 1 2]);
set(gca,'fontsize',16,'fontname','arial','ytick',[-4:4],'yticklabel',[-4:4]);

axis image

% Plot species. Get handles for legend inserts.

% Plot a dummy value if nothing's present. Plot outside the window.
if all(isnan(newposTx))
    plot(-99999,99999,'.','color',[220 53 58]/255,'markers',12);
else
    plot(newposTx(:,1),newposTy(:,1),'.','color',[220 53 58]/255,'markers',12);
end
axis tight;
set(gca,'nextplot','replacechildren','Visible','on',...
        'XLim',[-xwin,xwin],'YLim',[-ywin,ywin]);

% Create the video object.
vidObj = QTWriter([filename '_Cdc42Tmov'],'CompressionType','lzw','Transparency',false);

% Render video using every 16 frames of the data.
for i=2:16:ceil(nsteps/datagrain)
    i
    set(gca,'nextplot','replacechildren','Visible','on');
    if all(isnan(newposTx))
        plot(-99999,999999,'.','color',[220 53 58]/255,'markers',12);
    else
        plot(newposTx(:,i),newposTy(:,i),'.','color',[220 53 58]/255,'markers',12);
    end
    axis image
    text(-4.3,4.7,sprintf('Time: %0.1f seconds',i/10),'fontsize',12);
    
    set(gca,'XLim',[-xwin,xwin],'YLim',[-ywin,ywin]);
    writeMovie(vidObj,getframe(gcf));
end
    close(gcf);
    close(vidObj);
end


% Function to establish data structures.
function [outfile,todays_date]=SetFolderbyDate(filebasename)
if ispc
    todays_date = num2str(yyyymmdd(datetime)); % folder
    todays_date = strcat(todays_date,'\');
    outfile     = strcat(todays_date,'\',filebasename);
elseif ismac
    todays_date = num2str(yyyymmdd(datetime)); % folder
    todays_date = strcat(todays_date,'/');
    outfile     = strcat(todays_date,'/',filebasename);
elseif isunix
    % Minor difference from actual dirs in the *nix format..
    % pc and mac give YYYYMMDD
    % *nix gives YYYY_M_D, where M and D can have 1 or 2 digits. Added
    % underscores for clarity; just note you cannot integrate
    % *nix names directly with pc or mac names if automating analysis
    mytime=clock;
    mytime=mytime(1:3); % get YYYYMD only
    todays_date=strrep(regexprep(num2str(fix(mytime)),' +',' '),' ','_');
    todays_date = strcat(todays_date,'/');
    outfile     = strcat(todays_date,'/',filebasename);
end
end

function [newposXs,newposYs] = recenterCoordinates(posXs,posYs,nbins,xwin,ywin)
%%---------------------------------------------
% Compute re-centered coordinates.
%%---------------------------------------------

% get final frame distr, 'xs,ys'
xs = posXs(:,end); ys = posYs(:,end);
myhist = histcounts2(xs,ys,'numbins',nbins);
[~,I] = max(myhist(:));
[I1,I2]=ind2sub(size(myhist),I); % convert to 2D indices
df_I1 = round(nbins/2) - I1; % # bins to shift to get to the center
df_I2 = round(nbins/2) - I2;
df_coordX = 2*xwin*df_I1 / nbins; % How far to shift in coordinate space
df_coordY = 2*ywin*df_I2 / nbins; % Assumes domain is (-xwin,-ywin) to
                                  % (xwin, ywin)
newposXs = df_coordX + posXs(:,:); % Shift coordinates to new center
newposXs = mod(newposXs + xwin, 2*xwin)-xwin; % Shift domain to recenter
newposYs = df_coordY + posYs(:,:);
newposYs = mod(newposYs + ywin, 2*ywin)-ywin; 
end
