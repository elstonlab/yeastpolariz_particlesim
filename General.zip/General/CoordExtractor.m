% Extracts data from CoordTracker
% These are strictly defined, as using 'State' below.
Cdc42T_Trajectories  =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);
Cdc42Dc_Trajectories =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);
Cdc42Dm_Trajectories =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);
GEFc_Trajectories    =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);
GEFm_Trajectories    =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);
GEF42_Trajectories   =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);

% State counts
Cdc42T_Counts=zeros(floor(nsteps/datagrain),1);
Cdc42Dm_Counts=zeros(floor(nsteps/datagrain),1);
Cdc42Dc_Counts=zeros(floor(nsteps/datagrain),1);
GEFm_Counts=zeros(floor(nsteps/datagrain),1);
GEFc_Counts=zeros(floor(nsteps/datagrain),1);
GEF42_Counts=zeros(floor(nsteps/datagrain),1);

%% ---------------------------------------------
% State (for CoordTracker)
%    GEFm    = 1    Cdc42Dm = 4
%    GEFc    = 2    Cdc42Dc = 5
%    GEF42   = 3    Cdc42T  = 6
%% ---------------------------------------------

for iii=1:nCdc42tot+nGEFtot
    for jjj=1:1:nsteps/datagrain 
        switch CoordTracker(jjj,iii,3)
            case -1
                %disp('reservoir');
                continue;
            case 2           
                GEFm_Trajectories(iii,jjj,1) = CoordTracker(jjj,iii,1);
                GEFm_Trajectories(iii,jjj,2) = CoordTracker(jjj,iii,2);
                GEFm_Counts(jjj) = GEFm_Counts(jjj) + 1;
            case 1
                GEFc_Trajectories(iii,jjj,1) = CoordTracker(jjj,iii,1);
                GEFc_Trajectories(iii,jjj,2) = CoordTracker(jjj,iii,2);
                GEFc_Counts(jjj) = GEFc_Counts(jjj) + 1;
            case 3
                GEF42_Trajectories(iii,jjj,1) = CoordTracker(jjj,iii,1);
                GEF42_Trajectories(iii,jjj,2) = CoordTracker(jjj,iii,2);
                GEF42_Counts(jjj) = GEF42_Counts(jjj) + 0.5; % These are labeled x2 from Cdc42 and GEF
            case 5                
                Cdc42Dm_Trajectories(iii,jjj,1) = CoordTracker(jjj,iii,1);
                Cdc42Dm_Trajectories(iii,jjj,2) = CoordTracker(jjj,iii,2);
                Cdc42Dm_Counts(jjj) = Cdc42Dm_Counts(jjj) + 1;
            case 4      
                Cdc42Dc_Trajectories(iii,jjj,1) = CoordTracker(jjj,iii,1);
                Cdc42Dc_Trajectories(iii,jjj,2) = CoordTracker(jjj,iii,2);
                Cdc42Dc_Counts(jjj) = Cdc42Dc_Counts(jjj) + 1;
            case 6   
                Cdc42T_Trajectories(iii,jjj,1) = CoordTracker(jjj,iii,1);
                Cdc42T_Trajectories(iii,jjj,2) = CoordTracker(jjj,iii,2);
                Cdc42T_Counts(jjj) = Cdc42T_Counts(jjj) + 1;
        end
    end
end

Cdc42T_Trajectories(Cdc42T_Trajectories==0)   = nan;
Cdc42Dc_Trajectories(Cdc42Dc_Trajectories==0) = nan;
Cdc42Dm_Trajectories(Cdc42Dm_Trajectories==0) = nan;
GEFc_Trajectories(GEFc_Trajectories==0)       = nan;
GEFm_Trajectories(GEFm_Trajectories==0)       = nan;
GEF42_Trajectories(GEF42_Trajectories==0)     = nan;
