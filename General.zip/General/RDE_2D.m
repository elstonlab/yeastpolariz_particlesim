function RDE_2D(Bem1_tot,Cdc42_tot,k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7,...
                output_basename,xwin,dt,interval,pdeinitFile)
% INPUTS ====================================
% Bem1_tot (particle #)
% Cdc42_tot (particle #)
% k1a (s-1)      BemGEFc           -> BemGEF
% k1b (s-1)      BemGEF            -> BemGEFc
% k2a (uM-1.s-1) BemGEF + Cdc42D   -> Cdc42T
% k2b (s-1)      Cdc42T            -> Cdc42D
% k3  (uM-1.s-1) Cdc42D + GEF42    -> Cdc42T
% k4a (uM-1.s-1) GEF + Cdc42T      -> GEF42
% k4b (s-1)      GEF42             -> GEF + Cdc42T
% k5a (s-1)      Cdc42Dc           -> Cdc42Dm
% k5b (s-1)      Cdc42Dm           -> Cdc42Dc
% k7  (uM-1.s-1) GEFc + Cdc42T     -> GEF42
% output_basename: filename
% xwin: half the domain length.
% dt: diffusion timestep [s-1].


tic;

%% Set parameters
N = 100;   % number of spatial grid points
Dmemb = 0.0025;      % membrane diffusion coefficient
Dcyto = 15;          % cytoplasmic diffusion coefficient
membThickness = 0.0083; % Implicit simulation thickness.

%% Calculate 2D rate constants and 2D concentrations.
k2a = convert3DRateConst(k2a,membThickness);
k3  = convert3DRateConst(k3 ,membThickness);
k4a = convert3DRateConst(k4a,membThickness);
k7  = convert3DRateConst(k7 ,membThickness);
Bem1_tot = Bem1_tot / (xwin*2)^2;
Cdc42_tot = Cdc42_tot / (xwin*2)^2;
fprintf('Initializing simulation with %g Bem1GEF (particles/um^2), %g Cdc42 (particles/um^2)\n',...
        Bem1_tot,Cdc42_tot);
fprintf('rate constants:\n k1a\t%g\nk1b\t%g\nk2a\t%g\nk2b\t%g\nk3\t%g\nk4a\t%g\nk4b\t%g\nk5a\t%g\nk5b\t%g\nk7\t%g\n',...
        k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7);
fprintf('All rate constants are in units of s^-1 and um^2.s^-1\n');

%% Initial state options
% Option 1: Start from fully inactive, cytoplasmic conditions
% Option 2: Generate customized HSS if any of the parameters are changed
%           by setting HSS to 1.
% Option 3: Load from pdeinit file
option = 3;


%% Output base name
[~,todays_date]=SetFolderbyDate(output_basename);
dir_prefix = todays_date;
fullfilename = strcat(dir_prefix,output_basename);
% Create the appropriate folder for the sim.
if ~exist(dir_prefix,'dir')
    mkdir(dir_prefix);
end

%%
% storage files
RT_tc   = zeros((interval+1)*N, N);
M_tc    = zeros((interval+1)*N, N);
Em_tc   = zeros((interval+1)*N, N);
Ec_tc   = zeros((interval+1)*N, N);
RD_tc   = zeros((interval+1)*N, N);
RDc_tc  = zeros((interval+1)*N, N); 
Rtot_tc = zeros(interval+1, 1);
Etot_tc = zeros(interval+1, 1);

% variables for time-stepping
maxt = interval/dt;  % number of time-steps in interval

% variables for spatial discretization
%dx  = Cellsize*sqrt(pi)/N;          % spatial meshsize (1D)
L = xwin*2; % spatial length along 1 axis


curr_t  = 0;          % keeps track of current time
nRsteps = 10;        % defines the initial reaction time-step (dt2)
dt2     = dt/nRsteps; % reaction time-step

% To solve periodic diffusion via Fourier approach
wx2=2*pi/L*[0:N/2 -N/2+1:-1];
wy2=2*pi/L*[0:N/2 -N/2+1:-1];
[Fx, Fy]=meshgrid(wx2,wy2);
Flk=Fx.^2+Fy.^2;

%% Initial condition selection
switch option
    case 1
        Y0 = zeros(6,1);
        Y0(4) = Bem1_tot;  % BemGEFc
        Y0(6) = Cdc42_tot; % Cdc42Dc
             
        Cdc42T0   = Y0(1);
        BemGEF420 = Y0(2);
        BemGEF0   = Y0(3);
        BemGEFc0  = Y0(4);
        Cdc42D0   = Y0(5);
        Cdc42Dc0  = Y0(6);
        
        Cdc42spike = 0.75 .* Cdc42Dc0; % The spike at a single spatial point

        if Cdc42spike ~= 0
            disp('Non-zero initial Cdc42-T spike from pure cyto init')
        end
        
        Cdc42T   = Cdc42T0   .*ones(N); 
        Cdc42T(50, 25) = Cdc42T0 + Cdc42spike;
        BemGEF42 = BemGEF420 .*ones(N);
        BemGEF   = BemGEF0   .*ones(N); 
        BemGEFc  = BemGEFc0  .*ones(N);
        Cdc42D   = Cdc42D0   .*ones(N);
        Cdc42Dc  = Cdc42Dc0  .*ones(N);
        Cdc42D(50,25) = Cdc42D(50,25) - Cdc42spike;
    case 2
        %% Homogeneous steady state k3 = 0 : BemGEF42 + Cdc42D -> BemGEF42 + Cdc42T
        Y0 = zeros(6,1); 
        Y0(4)= Bem1_tot;  % BemGEFc
        Y0(6)= Cdc42_tot;     % Cdc42c
        [~,Y]=ode23s(@(t,y)steady_state_ode(t,y,k1a,k1b,k2a,k2b,k3,...
                                        k4a,k4b,k5a,k5b,k7),[0 10000],Y0);
              Cdc42T0   = Y(end,1);
              BemGEF420 = Y(end,2);
              BemGEF0   = Y(end,3);
              BemGEFc0  = Y(end,4);
              Cdc42D0   = Y(end,5);
              Cdc42Dc0  = Y(end,6);
              
              
              Cdc42spike = 0.75 .* Cdc42D0; % The spike at a single spatial point

        Cdc42T   = Cdc42T0   .*ones(N); 
        Cdc42T(50, 25) = Cdc42T0 + Cdc42spike;
        BemGEF42 = BemGEF420 .*ones(N);
        BemGEF   = BemGEF0   .*ones(N); 
        BemGEFc  = BemGEFc0  .*ones(N);
        Cdc42D   = Cdc42D0   .*ones(N);
        Cdc42Dc  = Cdc42Dc0  .*ones(N);
        Cdc42D(50,25) = Cdc42D(50,25) - Cdc42spike;
    case 3
        Y0 = zeros(6,1);             
        load(pdeinitFile);
        
        Cdc42T   = Cdc42_tot  .* Cdc42T_pdeinit;
        BemGEF42 = Bem1_tot   .* GEF42_pdeinit;
        BemGEF   = Bem1_tot   .* GEFm_pdeinit; 
        BemGEFc  = Bem1_tot   .* GEFc_pdeinit; 
        Cdc42D   = Cdc42_tot  .* Cdc42Dm_pdeinit;
        Cdc42Dc  = Cdc42_tot  .* Cdc42Dc_pdeinit;
end

% print initial conditions into file
RT_tc(1:N,:)   = Cdc42T;
M_tc(1:N,:)    = BemGEF42;
Em_tc(1:N,:)   = BemGEF;
Ec_tc(1:N,:)   = BemGEFc;
RD_tc(1:N,:)   = Cdc42D;
RDc_tc(1:N,:)  = Cdc42Dc; 

% calculate mass balance
Rtot_tc(1) = ((sum(sum(Cdc42Dc))+sum(sum((Cdc42T + Cdc42D + BemGEF42)))));
Etot_tc(1) = sum(sum(BemGEFc))+sum(sum((BemGEF42 + BemGEF)));
 
% print progress scale bar
fprintf('Total simulation time: %d seconds\n\n', interval);
fprintf('0            25          50           75         100 (percent) \n');
fprintf('|------------|-----------|------------|-----------|\n');
  
%% 
progress = 1;
      
for t0=1:1:maxt                   
    curr_t = curr_t+dt;  % update simulation clock

    %% run the actual simulation
    lp = 0;      % Track status of simulation
    react_t = 0; % Internal reaction clock
    et = 0.0001; % Error tolerance

    while  lp ~= 2

        [Cdc42Th, BemGEF42h, BemGEFh, BemGEFch, Cdc42Dh, Cdc42Dch] = Euler_step(Cdc42T, BemGEF42, BemGEF, BemGEFc, Cdc42D, Cdc42Dc, dt2,...
                                                                                k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7);
        [Cdc42Th2, BemGEF42h2, BemGEFh2, BemGEFch2, Cdc42Dh2, Cdc42Dch2] = Euler_step(Cdc42T, BemGEF42, BemGEF, BemGEFc, Cdc42D, Cdc42Dc, dt2/2,...
                                                                                k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7);
        [Cdc42Th2, BemGEF42h2, BemGEFh2, BemGEFch2, Cdc42Dh2, Cdc42Dch2] = Euler_step(Cdc42Th2, BemGEF42h2, BemGEFh2, BemGEFch2, Cdc42Dh2, Cdc42Dch2, dt2/2,...
                                                                                k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7);
     
        % error checking
        Cdc42Te    = max(max(abs(Cdc42Th   - Cdc42Th2   )));
        BemGEF42e  = max(max(abs(BemGEF42h - BemGEF42h2 )));
        BemGEFe    = max(max(abs(BemGEFh   - BemGEFh2   )));
        BemGEFce    = max(max(abs(BemGEFch   - BemGEFch2   )));
        Cdc42De    = max(max(abs(Cdc42Dh   - Cdc42Dh2   )));
        Cdc42Dce    = max(max(abs(Cdc42Dch   - Cdc42Dch2   )));
        
        r = max([Cdc42Te,BemGEF42e,BemGEFe,BemGEFce,Cdc42De,Cdc42Dce]);
        
        % doing the step again with smaller stepsize
        if r > et && lp == 0
            dt2 = dt2/1.5;     
            
        % moving on
        else
            Cdc42T    = Cdc42Th2;
            BemGEF42  = BemGEF42h2;
            BemGEF    = BemGEFh2;
            BemGEFc   = BemGEFch2;
            Cdc42D    = Cdc42Dh2;
            Cdc42Dc   = Cdc42Dch2;
            
            % adding the step on 
            react_t = react_t + dt2;
            % setting new stepsize for next step
            dt2 = 1.5*dt2;
            
            if lp == 1
                lp = 2;
            end
        end   
        % Making sure we stay within the dt interval
        if react_t + dt2 > dt && lp ~= 2
            dt2 = dt - react_t;
            lp = 1; 
        end            
    end
    %% Diffusion
    Cdc42T_ff   = fft2(Cdc42T);
    Cdc42T_nn = Cdc42T_ff.* exp(-dt*Flk*Dmemb); 
    Cdc42T = real(ifft2(Cdc42T_nn));
    
    Cdc42D_ff   = fft2(Cdc42D);
    Cdc42D_nn = Cdc42D_ff.* exp(-dt*Flk*Dmemb); 
    Cdc42D = real(ifft2(Cdc42D_nn));
    
    BemGEF42_ff   = fft2(BemGEF42);
    BemGEF42_nn = BemGEF42_ff.* exp(-dt*Flk*Dmemb); 
    BemGEF42 = real(ifft2(BemGEF42_nn));
    
    BemGEF_ff   = fft2(BemGEF);
    BemGEF_nn = BemGEF_ff.* exp(-dt*Flk*Dmemb); 
    BemGEF = real(ifft2(BemGEF_nn));

    Cdc42Dc_ff = fft2(Cdc42Dc);
    Cdc42Dc_nn = Cdc42Dc_ff .* exp(-dt*Flk*Dcyto);
    Cdc42Dc = real(ifft2(Cdc42Dc_nn));
    
    BemGEFc_ff = fft2(BemGEFc);
    BemGEFc_nn = BemGEFc_ff .* exp(-dt*Flk*Dcyto);
    BemGEFc = real(ifft2(BemGEFc_nn));

    %% metadata and saving
    if(t0 >= interval/dt/50*progress)
      fprintf('*');
      progress = progress +1;
    end
    
    % store data every second
    if(t0>=1/dt && mod(t0,1/dt)==0) 
        
        RT_tc((t0*dt*N + 1):(t0*dt + 1)*N ,:)  = Cdc42T;
        M_tc((t0*dt*N + 1):(t0*dt + 1)*N ,:)   = BemGEF42;
        Em_tc((t0*dt*N + 1):(t0*dt + 1)*N ,:)  = BemGEF;
        Ec_tc((t0*dt*N + 1):(t0*dt + 1)*N ,:)  = BemGEFc;
        RD_tc((t0*dt*N + 1):(t0*dt + 1)*N ,:)  = Cdc42D;
        RDc_tc((t0*dt*N + 1):(t0*dt + 1)*N ,:) = Cdc42Dc; 
  
        % calculate mass balance
        Rtot_tc(t0*dt) = ((sum(sum(Cdc42Dc))+sum(sum((Cdc42T + Cdc42D + BemGEF42)))));
        Etot_tc(t0*dt) = sum(sum(BemGEFc))+sum(sum((BemGEF42 + BemGEF)));

    end    

end  

%% ________________________________________________________________________

time_whole = toc

data_mat = strcat(fullfilename,'_tc.mat');
RT_tc  = RT_tc  * (2*xwin)^2; % Convert to particle #s
M_tc   = M_tc   * (2*xwin)^2;
Em_tc  = Em_tc  * (2*xwin)^2;
Ec_tc  = Ec_tc  * (2*xwin)^2;
RD_tc  = RD_tc  * (2*xwin)^2;
RDc_tc = RDc_tc * (2*xwin)^2; 
save(data_mat, 'RT_tc', 'M_tc', 'Em_tc', 'Ec_tc', 'RD_tc', 'RDc_tc', 'Rtot_tc', 'Etot_tc')

clear RT_tc M_tc Em_tc Ec_tc RD_tc RDc_tc Rtot_tc Etot_tc;

output_mat = strcat(fullfilename, '.mat');
save(output_mat);

end


function dy = steady_state_ode(t,y,k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7)
eta = 1;

%%      
dy = zeros(6,1);

% RT      (Cdc42T)
dy(1) =  ((k2a.*y(3)  +k3.*y(2)  ).*y(5) - k2b.*y(1)  - k4a.*y(3).*y(1) + k4b.*y(2) - k7.*y(4).*y(1));   

% M       (BemGEF42)
dy(2) = (k4a*y(3).*y(1) - k4b*y(2) + k7*y(4).*y(1));
         
% Em      (BemGEF)
dy(3) = (k1a.*y(4) - k1b.*y(3) - k4a.*y(3).*y(1) + k4b.*y(2));

% Ec      (BemGEFc)
dy(4) = (eta.*(k1b.*y(3) - (k1a+k7.*y(1)).*y(4)));

% RD      (Cdc42D)
dy(5) = (k2b.*y(1)  - (k2a.*y(3) +k3.*y(2) ).*y(5) - k5b.*y(5) + k5a.*y(6));

% RDc     (Cdc42Dc)
dy(6) = (eta.*(k5b.*y(5) - k5a.*y(6)));

end

% Euler_step



function [cdc42t, bemgef42, bemgef, bemgefc, cdc42d, cdc42dc] = ... 
    Euler_step(Cdc42T, BemGEF42, BemGEF, BemGEFc, Cdc42D, Cdc42Dc, h,...
               k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7)


cdc42t   = Cdc42T   + h*((k2a *BemGEF +k3 *BemGEF42 ).*Cdc42D - k2b*Cdc42T  - k4a*BemGEF.*Cdc42T  + k4b*BemGEF42  - k7*BemGEFc.*Cdc42T );   
                
bemgef42 = BemGEF42 + h*(k4a*BemGEF.*Cdc42T - k4b*BemGEF42 + k7*BemGEFc.*Cdc42T);   
                  
bemgef   = BemGEF   + h*(k1a*BemGEFc - k1b*BemGEF - k4a*BemGEF.*Cdc42T + k4b*BemGEF42);

         
bemgefc  = BemGEFc  + h*(k1b*BemGEF - (k1a+k7*Cdc42T).*BemGEFc);

cdc42d   = Cdc42D   + h*(k2b*Cdc42T  - (k2a *BemGEF +k3 *BemGEF42).*Cdc42D - k5b*Cdc42D + k5a*Cdc42Dc);
                    
cdc42dc  = Cdc42Dc  + h*(k5b*Cdc42D - k5a*Cdc42Dc);

end

% Function to establish data structures.
function [outfile,todays_date]=SetFolderbyDate(filebasename)
if ispc
    todays_date = num2str(yyyymmdd(datetime)); % folder
    todays_date = strcat(todays_date,'\');
    outfile     = strcat(todays_date,'\',filebasename);
elseif ismac
    todays_date = num2str(yyyymmdd(datetime)); % folder
    todays_date = strcat(todays_date,'/');
    outfile     = strcat(todays_date,'/',filebasename);
elseif isunix
    % Minor difference from actual dirs in the *nix format..
    % pc and mac give YYYYMMDD
    % *nix gives YYYY_M_D, where M and D can have 1 or 2 digits. Added
    % underscores for clarity; just note you cannot integrate
    % *nix names directly with pc or mac names if automating analysis
    mytime=clock;
    mytime=mytime(1:3); % get YYYYMD only
    todays_date=strrep(regexprep(num2str(fix(mytime)),' +',' '),' ','_');
    todays_date = strcat(todays_date,'/');
    outfile     = strcat(todays_date,'/',filebasename);
end
end

function [k2d] = convert3DRateConst(k3d,membThickness)
liters_per_cubic_meters = 10^3;
microns_per_meter = 10^6;
micromoles_per_mol = 10^-6;
Nav = 6.02 * 10^23;
% Assuming ktarg is in units of 1/uM*s and converting to um^3/s
k3d=k3d * microns_per_meter^3 / ... 
        (liters_per_cubic_meters * micromoles_per_mol) / Nav;

% Converting now from um^3/s to um^2/s, adjusting it to a 2D rate constant
k2d=k3d / membThickness;
end
