function make_q3D_pb_inits(inputfile,outputfile)

fprintf('Extracting data from file: %s\n',inputfile);
[Cdc42T_Trajectories,Cdc42Dm_Trajectories,Cdc42Dc_Trajectories,GEFc_Trajectories,GEFm_Trajectories,GEF42_Trajectories,...
    nCdc42Dc_res,nGEFc_res,nCdc42tot,nGEFtot,xwin,ywin] = CoordExtractor(inputfile);

targetSimIdx = 10; % t=1s.

% Data grain is sampling one in every 1000 frames, each frame dt is 0.00001 s.
fprintf('Creating q3D-RDE file, using a snapshot at %g seconds;\tfile @ %s\n',targetSimIdx/10,outputfile);

[Cdc42T_pdeinit,~,~] = histcounts2(Cdc42T_Trajectories(:,targetSimIdx,1),...
                                   Cdc42T_Trajectories(:,targetSimIdx,2),...
                                   'numbins',[100 100],...
                                   'xbinlimits',[-xwin xwin],...
                                   'ybinlimits',[-ywin ywin]);
[Cdc42Dc_pdeinit,~,~] = histcounts2(Cdc42Dc_Trajectories(:,targetSimIdx,1),...
                                    Cdc42Dc_Trajectories(:,targetSimIdx,2),...
                                    'numbins',[100 100],...
                                    'xbinlimits',[-xwin xwin],...
                                    'ybinlimits',[-ywin ywin]);
[Cdc42Dm_pdeinit,~,~] = histcounts2(Cdc42Dm_Trajectories(:,targetSimIdx,1),...
                                    Cdc42Dm_Trajectories(:,targetSimIdx,2),...
                                    'numbins',[100 100],...
                                    'xbinlimits',[-xwin xwin],...
                                    'ybinlimits',[-ywin ywin]);
[GEFc_pdeinit,~,~] = histcounts2(GEFc_Trajectories(:,targetSimIdx,1),...
                                 GEFc_Trajectories(:,targetSimIdx,2),...
                                 'numbins',[100 100],...
                                 'xbinlimits',[-xwin xwin],...
                                 'ybinlimits',[-ywin ywin]);
[GEFm_pdeinit,~,~] = histcounts2(GEFm_Trajectories(:,targetSimIdx,1),...
                                 GEFm_Trajectories(:,targetSimIdx,2),...
                                 'numbins',[100 100],...
                                 'xbinlimits',[-xwin xwin],...
                                 'ybinlimits',[-ywin ywin]);
[GEF42_pdeinit,~,~] = histcounts2(GEF42_Trajectories(:,targetSimIdx,1),...
                                  GEF42_Trajectories(:,targetSimIdx,2),...
                                  'numbins',[100 100],...
                                  'xbinlimits',[-xwin xwin],...
                                  'ybinlimits',[-ywin ywin]);

GEF42_pdeinit = GEF42_pdeinit/2; % GEF42 is double-counted (GEF, then Cdc42)
nCdc42Dc_res_pdeinit = nCdc42Dc_res(targetSimIdx);
nGEFc_res_pdeinit = nGEFc_res(targetSimIdx);

% Normalize all
Cdc42T_pdeinit = Cdc42T_pdeinit / nCdc42tot;
Cdc42Dm_pdeinit = Cdc42Dm_pdeinit / nCdc42tot;
Cdc42Dc_pdeinit = Cdc42Dc_pdeinit / nCdc42tot;
nCdc42Dc_res_pdeinit = nCdc42Dc_res_pdeinit / nCdc42tot;

% Normalize all
GEF42_pdeinit = GEF42_pdeinit / nCdc42tot;
GEFc_pdeinit = GEFc_pdeinit / nGEFtot;
GEFm_pdeinit = GEFm_pdeinit / nGEFtot;
nGEFc_res_pdeinit = nGEFc_res_pdeinit / nGEFtot;

nGEFtot_pdeinit = nGEFtot;
nCdc42tot_pdeinit = nCdc42tot;

save(outputfile,'Cdc42T_pdeinit','Cdc42Dm_pdeinit','Cdc42Dc_pdeinit','nCdc42Dc_res_pdeinit',...
        'GEFc_pdeinit','GEFm_pdeinit','GEF42_pdeinit','nGEFc_res_pdeinit','nGEFtot_pdeinit','nCdc42tot_pdeinit');
end

function [Cdc42T_Trajectories,Cdc42Dm_Trajectories,Cdc42Dc_Trajectories,GEFc_Trajectories,GEFm_Trajectories,GEF42_Trajectories,...
          nCdc42Dc_res,nGEFc_res,nCdc42tot,nGEFtot,xwin,ywin] = CoordExtractor(inputfile)

    % Read in data
    load([inputfile '_par.mat']);
    load([inputfile '_dat.mat']);
        
    Cdc42T_Trajectories  =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);
    Cdc42Dc_Trajectories =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);
    Cdc42Dm_Trajectories =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);
    GEFc_Trajectories    =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);
    GEFm_Trajectories    =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);
    GEF42_Trajectories   =zeros(nCdc42tot+nGEFtot,floor(nsteps/datagrain),2);

    % State counts
    Cdc42T_Counts=zeros(floor(nsteps/datagrain),1);
    Cdc42Dm_Counts=zeros(floor(nsteps/datagrain),1);
    Cdc42Dc_Counts=zeros(floor(nsteps/datagrain),1);
    GEFm_Counts=zeros(floor(nsteps/datagrain),1);
    GEFc_Counts=zeros(floor(nsteps/datagrain),1);
    GEF42_Counts=zeros(floor(nsteps/datagrain),1);

    %% ---------------------------------------------
    % State (for CoordTracker)
    %    GEFm    = 1    Cdc42Dm = 4
    %    GEFc    = 2    Cdc42Dc = 5
    %    GEF42   = 3    Cdc42T  = 6
    %    implicit = 0
    %% ---------------------------------------------

    for iii=1:nCdc42tot+nGEFtot
        for jjj=1:1:nsteps/datagrain 
            switch CoordTracker(jjj,iii,3)
                case 0
                    %disp('reservoir');
                    continue;
                case 2           
                    GEFm_Trajectories(iii,jjj,1) = CoordTracker(jjj,iii,1);
                    GEFm_Trajectories(iii,jjj,2) = CoordTracker(jjj,iii,2);
                    GEFm_Counts(jjj) = GEFm_Counts(jjj) + 1;
                case 1
                    GEFc_Trajectories(iii,jjj,1) = CoordTracker(jjj,iii,1);
                    GEFc_Trajectories(iii,jjj,2) = CoordTracker(jjj,iii,2);
                    GEFc_Counts(jjj) = GEFc_Counts(jjj) + 1;
                case 3
                    GEF42_Trajectories(iii,jjj,1) = CoordTracker(jjj,iii,1);
                    GEF42_Trajectories(iii,jjj,2) = CoordTracker(jjj,iii,2);
                    GEF42_Counts(jjj) = GEF42_Counts(jjj) + 0.5; % These are labeled x2 from Cdc42 and GEF
                case 5                
                    Cdc42Dm_Trajectories(iii,jjj,1) = CoordTracker(jjj,iii,1);
                    Cdc42Dm_Trajectories(iii,jjj,2) = CoordTracker(jjj,iii,2);
                    Cdc42Dm_Counts(jjj) = Cdc42Dm_Counts(jjj) + 1;
                case 4      
                    Cdc42Dc_Trajectories(iii,jjj,1) = CoordTracker(jjj,iii,1);
                    Cdc42Dc_Trajectories(iii,jjj,2) = CoordTracker(jjj,iii,2);
                    Cdc42Dc_Counts(jjj) = Cdc42Dc_Counts(jjj) + 1;
                case 6   
                    Cdc42T_Trajectories(iii,jjj,1) = CoordTracker(jjj,iii,1);
                    Cdc42T_Trajectories(iii,jjj,2) = CoordTracker(jjj,iii,2);
                    Cdc42T_Counts(jjj) = Cdc42T_Counts(jjj) + 1;
            end
        end
    end

    Cdc42T_Trajectories(Cdc42T_Trajectories==0)   = nan;
    Cdc42Dc_Trajectories(Cdc42Dc_Trajectories==0) = nan;
    Cdc42Dm_Trajectories(Cdc42Dm_Trajectories==0) = nan;
    GEFc_Trajectories(GEFc_Trajectories==0)       = nan;
    GEFm_Trajectories(GEFm_Trajectories==0)       = nan;
    GEF42_Trajectories(GEF42_Trajectories==0)     = nan;    
    
    nCdc42Dc_res = nCdc42tot - GEF42_Counts - Cdc42Dm_Counts - Cdc42Dc_Counts - Cdc42T_Counts;
    nGEFc_res    = nGEFtot   - GEF42_Counts - GEFm_Counts    - GEFc_Counts;
end
