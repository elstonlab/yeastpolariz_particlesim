function pbsim_q3d(GEFconc,Cdc42conc,d_cell,...
                   k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7,...
                   Dcyto,Dmemb,rho,sigma,xwin,ywin,...
                   dt,nsteps,filebasename,rngseed,datagrain,loadfile)



try % Check if there is a valid loadfile parameter to continue a prior simulation.

    temploadfile = loadfile;
    load(loadfile)
    disp(strcat('Successfully loaded the initialization file@',temploadfile));
    clear temploadfile % Keep it from getting saved, which would overwrite it in the load.
    
    % Update the folder for new saves.
    [~,newdate]=SetFolderbyDate(filebasename);
    if ~exist(todays_date,'dir');
        mkdir(todays_date);
    end
catch
    disp('WARNING: No valid load file found -- proceeding with NEW simulation.')

% for debugging
DEBUG_POSITION = 0;
DEBUG_CDC42T_COUNT =0;

%% --------------------------
% Initialize file structures
%% --------------------------
[outfile,todays_date]=SetFolderbyDate(filebasename);
fprintf('Initializing quasi3D clustering simulation, saving to %s with rng %i\n',outfile,rngseed);

rng(rngseed);

% Create the appropriate folder for the sim.
if ~exist(todays_date,'dir')
    mkdir(todays_date);
end


%% --------------------------
% Calculate lambdas for bimolecular reactions
%% --------------------------
if k2a == 0
    lambda2a = 0;
else
    lambda2a =computeLambda(k2a,rho,sigma,Dmemb,Dmemb);
end
if k3 == 0
    lambda3 = 0;
else
    lambda3   =computeLambda(k3 ,rho,sigma,Dmemb,Dmemb);
end
if k4a == 0
    lambda4a = 0; 
else
    lambda4a  = computeLambda(k4a,rho,sigma,Dmemb,Dmemb);
end
if k7 == 0
    lambda7= 0;
else    
    lambda7   =computeLambda(k7 ,rho,sigma,Dcyto,Dmemb);
end
fprintf(strcat('Reaction probabilities: P(1a)\t%g\n',...
                                       'P(1b)\t%g\n',...
                                       'P(2a)\t%g\n',...
                                       'P(3)\t%g\n',...
                                       'P(4a)\t%g\n',...
                                       'P(4b)\t%g\n',...
                                       'P(5a)\t%g\n',...
                                       'P(5b)\t%g\n',...
                                       'P(7)\t%g \n'),...
                                       1-exp(-k1a*dt),...
                                       1-exp(-k1b*dt),...
                                       lambda2a*dt,...
                                       lambda3*dt,...
                                       lambda4a*dt,...
                                       1-exp(-k4b*dt),...
                                       1-exp(-k5a*dt),...
                                       1-exp(-k5b*dt),...
                                       lambda7*dt);

%% -------------------------------------
% Calculate particle totals and other
% reservoir-related values.
%% -------------------------------------
z_explicit  = 0.0083; % um. Set as constant
L_to_um3    = 1e-15; % 1e15 um^3 in 1 L
NA          = 6.0221409e+23; % Avogadro's number
umol_to_mol = 1e-6;
Vcell = 4/3*pi*(d_cell/2)^3; % um^3, total cellular volume
SA = 4*pi*(d_cell/2)^2; % um^2
z_full = Vcell/SA - 0.0083; % Cytoplasm z-depth, corrected for membrane volume contribution
z_reserv = z_full - z_explicit; % Threshold height for explicit modeling.

nGEFtot    = round(GEFconc   * L_to_um3 * Vcell * umol_to_mol * NA); % # of molecules in simulation.
nCdc42tot  = round(Cdc42conc * L_to_um3 * Vcell * umol_to_mol * NA);

% Estimate how many explicit molecules will be present
estExplicitGEF   = round(nGEFtot   * z_explicit/z_full);
estExplicitCdc42 = round(nCdc42tot * z_explicit/z_full);
                                   
fprintf('Explicit memb-z \t %g \nExplicit cyto-z \t %g \nImplicit cyto-z \t %g\n',0.0083,z_explicit,z_reserv);
fprintf('Estimated explicit molecules at start (%i Cdc42, %i GEF)\n',estExplicitCdc42,estExplicitGEF);
                                   
%% -------------------------------------------
% Initialize matrices. Some conventions below.
% Estimate the initial number of particles to be a result of UNIFORM
% CYTOPLASMIC DISTRIBUTION (don't begin by worrying about the membrane).
% 
% Membrane
%    Memb. bound = 1
%    Cytosolic   = 0
% Bound
%    Refers to the index of the bound partner.
% GXP
%    GDP = 1
%    GTP = 0
% active
%    Explicitly simulated = 1
%    Implicitly simulated = 0
% State (for CoordTracker)
%    GEFc    = 1    Cdc42Dc = 4
%    GEFm    = 2    Cdc42Dm = 5
%    GEF42   = 3    Cdc42T  = 6
%    Reservoir = 0
% GEF_ID or Cdc42_ID
%    Ranges from 1 to total # of explicit molecules. The total # of 
%    explicit molecules changes throughout the simulation because of
%    the injection/ejection aspect.
%% ---------------------------------------------
CoordTracker = zeros(ceil(nsteps/datagrain),nGEFtot+nCdc42tot,3); % #frames x #particles # {xcoord,ycoord,state}

% Everything in reservoir unless otherwise set.
GEFs          = zeros(nGEFtot,2,5); % #particles x {tn,tn+1} x {xcoord,ycoord,bound,memb,active}
Cdc42s        = zeros(nCdc42tot,2,6); % #particles x {tn,tn+1} x {xcoord,ycoord,bound,memb,gxp,active}
GEFs(1:estExplicitGEF    ,1,1) = unifrnd(-xwin,xwin,estExplicitGEF,1);
GEFs(1:estExplicitGEF    ,1,2) = unifrnd(-ywin,ywin,estExplicitGEF,1);
GEFs(1:nGEFtot    ,:,3) = 0; % None bound
GEFs(1:nGEFtot    ,:,4) = 0; % All cytosolic
GEFs(1:estExplicitGEF,1,5) = 1; % active
Cdc42s(1:estExplicitCdc42,1,1) = unifrnd(-xwin,xwin,estExplicitCdc42,1);
Cdc42s(1:estExplicitCdc42,1,2) = unifrnd(-ywin,ywin,estExplicitCdc42,1);
Cdc42s(1:estExplicitCdc42,:,3) = 0; % None bound
Cdc42s(1:estExplicitCdc42,:,4) = 0; % All cytosolic
Cdc42s(1:estExplicitCdc42,:,5) = 1; % Set all Cdc42s to begin in GDP bound state.
Cdc42s(1:estExplicitCdc42,1,6) = 1;
Cdc42s(:,2,:) = Cdc42s(:,1,:); GEFs(:,2,:) = GEFs(:,1,:); % tn+1 = tn to start

CoordTracker = zeros(ceil(nsteps/datagrain),nGEFtot+nCdc42tot,3); % #frames x #particles # {xcoord,ycoord,state}

%%-------------------------------------------
% Pre-solve the particle injection/ejection integrals.
%%-------------------------------------------
[nGEF_inj,nGEF_inj_prev]     = calc_injection(d_cell,dt,Dcyto,z_explicit,nGEFtot);
[nGEF_ejc,nGEF_ejc_prev]     =  calc_ejection(d_cell,dt,Dcyto,z_explicit,nGEFtot);
[nCdc42_inj,nCdc42_inj_prev] = calc_injection(d_cell,dt,Dcyto,z_explicit,nCdc42tot);
[nCdc42_ejc,nCdc42_ejc_prev] =  calc_ejection(d_cell,dt,Dcyto,z_explicit,nCdc42tot);

simstart = 1;
previousEndpoint = 0;
end

% RESET THE SAVE POINT COUNTER REGARDLESS OF NEW/OLD FILE.
tic

%% ---------------------------
%  Begin iterative simulation
%% ---------------------------
for i=simstart:nsteps
   %% ---------------------------------------------------------
   % Count the number of explicitly simulated particles.
   %% ---------------------------------------------------------
   NcurrExGEF = sum(GEFs(:,1,5));
   NcurrExCdc42 = sum(Cdc42s(:,1,6)); 
    
   % Provide user update
   if (mod(i,nsteps/10)) == 0
       fprintf('Completed %g %% of modelling. Explicit particles: %i\n',...
               100*i/nsteps,NcurrExGEF+NcurrExCdc42);

   end

   % Save file generation -- utilized because of 7-day default maximum runtime on Killdevil.
   savecheckpoint = toc;
   if savecheckpoint > 561600 % 6.5 days
       previousEndpoint = savecheckpoint + previousEndpoint; % For tracking purposes.
       fprintf(strcat('Checkpointed @ t=. Saving and quitting @',strcat(outfile,'_sav.mat')),i*dt);
       simstart = i; % For later initialization.
       save(strcat(outfile,'_sav.mat'));
       return
   end
   
   
   %% ---------------------------------------------------------
   % Precalculate some random numbers for commonly called lines.
   %% ---------------------------------------------------------
   r_diffusCdc42x     = RandVec_Diffus(nCdc42tot);
   r_diffusCdc42y     = RandVec_Diffus(nCdc42tot);
   r_diffusGEFx       = RandVec_Diffus(nGEFtot);
   r_diffusGEFy       = RandVec_Diffus(nGEFtot);
   
   % Using Cdc42 as the reference so make the vector sized to it.
   r_diffusGEF42x     = RandVec_Diffus(nCdc42tot);
   r_diffusGEF42y     = RandVec_Diffus(nCdc42tot); 
   r_dissocGEF42      = RandVec_Dissoc(nCdc42tot); 
   
   r_membAssocCdc42  = RandVec_MembAssoc(nCdc42tot);
   r_membAssocGEF    = RandVec_MembAssoc(nGEFtot);
   r_membDissocCdc42 = RandVec_MembDissoc(nCdc42tot);
   r_membDissocGEF   = RandVec_MembDissoc(nGEFtot);
   
   r_hydrolCdc42     = RandVec_Hydrol(nCdc42tot);
   
   [s_colMat_idx]=getCollisionMatrix(Cdc42s,GEFs,rho,xwin);
   
   %% ---------------------------------------------------------
   % Check binding reactions. 
   % Position is not updated here - set flags that will control
   % binding-dependent position updates during the diffusion update.
   % The first molecule in the argument is the reference particle.
   % The membrane update for GEFs is provided later.
   %% ---------------------------------------------------------
   
   % lambda4a: GEFm + Cdc42T -> GEF42
   % lambda7 : GEFc + Cdc42T -> GEF42
   % Flags are value indices, not logical indices.
   if lambda4a~=0 || lambda7~=0
   [reactFlagCdc42,reactFlagGEF]=getReactionList(s_colMat_idx,...
                                                Cdc42s,GEFs,lambda4a,...
                                                lambda7,dt);
   else
       reactFlagCdc42=[]; reactFlagGEF=[];
   end
   % Set binding state to the index value for associating molecules.
   Cdc42s(reactFlagCdc42(:),2,3) = reactFlagGEF(:);
   GEFs  (reactFlagGEF(:)  ,2,3) = reactFlagCdc42(:);
   
   %% ---------------------------------------------------------
   % Check dissociation reactions. Does not permit newly-bound particles to
   % dissociate. Position is not updated here - set flags that will control
   % binding-dependent position updates during the diffusion update.
   %% ---------------------------------------------------------
   
   % Flags are logical indices.
   % Molecules without binding partners at the current step are ignored.
   [dissocFlagCdc42,dissocFlagGEF]=getDissocList(Cdc42s,nGEFtot,k4b,dt,r_dissocGEF42);
   % Set binding state to zero for dissociated molecules.
   Cdc42s(dissocFlagCdc42,2,3) = 0;
   GEFs  (dissocFlagGEF  ,2,3) = 0;

   %% ---------------------------------------------------------
   % Check nucleotide exchange reactions (GEF catalyzed).
   % Only GDP->GTP or GTP->GDP can occur in a single timestep; no
   % flip-flopping is allowed. While GEFs may attempt catalysis multiple
   % times per timestep, they can only succeed once.
   %% ---------------------------------------------------------
   
   % lambda2a = Cdc42Dm + GEFm  -> Cdc42T
   % lambda3  = Cdc42Dm + GEF42 -> Cdc42T
   % Flags are logical indices.
   if lambda2a~=0 || lambda3 ~=0
   [exchangeFlagCdc42T] = getExchangeList(s_colMat_idx,Cdc42s,...
                                          GEFs,lambda2a,lambda3,dt);
   else
       exchangeFlagCdc42T=[];
   end
   Cdc42s(exchangeFlagCdc42T(:),2,5) = 0;
   
   %% ---------------------------------------------------------
   % GTP hydrolysis reactions (implicit GAPs). Enforces that new GDP
   % remain membrane bound later in the simulation (in a single timestep,
   % Cdc42T->Cdc42Dm->Cdc42Dc could not occur).
   % Assumes GEF42 complexes cannot directly hydrolyze
   %% ---------------------------------------------------------
   
   % Logical indexing.
   [hydrolysisFlagCdc42] = getHydrolList(Cdc42s,k2b,dt,r_hydrolCdc42);
   Cdc42s(hydrolysisFlagCdc42,2,5) = 1;
   
   %% ---------------------------------------------------------
   % Check membrane interactions. Assumes GEF42 complexes cannot become
   % cytosolic, and that Cdc42-GTP must be membrane bound.
   % This forbids Cdc42T -> Cdc42Dc in a single timestep.
   % Membrane association/dissociation flags require the Cdc42 to have been
   % in the GDP state before and after. 
   %% ---------------------------------------------------------
   
   % Flag is logical indices.
   [membAssocFlagCdc42]  = logical(getCdc42MembraneAssocList (Cdc42s,k5a,dt,r_membAssocCdc42));
   [membAssocFlagGEF]    = logical(getGEFMembraneAssocList   (GEFs  ,k1a,dt,r_membAssocGEF));
   [membDissocFlagCdc42] = logical(getCdc42MembraneDissocList(Cdc42s,k5b,dt,r_membDissocCdc42));
   [membDissocFlagGEF]   = logical(getGEFMembraneDissocList  (GEFs  ,k1b,dt,r_membDissocGEF));
      
   % Set dissociation flag to zero if a GEF42 in the next timestep.
   % Set association  flag to one  if a GEF42 in the next timestep.
   % Distinct from newly-reacted particles.
   isGEF42_Cdc42idx    = logical(Cdc42s(:,2,3));
   isGEF42_GEFidx      = logical(GEFs(:,2,3));
   membDissocFlagCdc42 = membDissocFlagCdc42 & ~isGEF42_Cdc42idx;
   membDissocFlagGEF   = membDissocFlagGEF   & ~isGEF42_GEFidx;
   membAssocFlagCdc42  = membAssocFlagCdc42  |  isGEF42_Cdc42idx;
   membAssocFlagGEF    = membAssocFlagGEF    |  isGEF42_GEFidx;
      
   % Set association flag = 1 and dissociation flag = 0 if Cdc42-GTP
   % Require the molecule be explicit beforehand
   isCdc42T = ~logical(Cdc42s(:,2,5)) & logical(Cdc42s(:,1,6));
   membAssocFlagCdc42 (isCdc42T)  = 1;
   membDissocFlagCdc42(isCdc42T)  = 0;
   
   % Update the GEF and Cdc42 membrane states for the next step.
   GEFs  (membAssocFlagGEF   ,2,4) = 1;
   GEFs  (membDissocFlagGEF  ,2,4) = 0;
   Cdc42s(membAssocFlagCdc42 ,2,4) = 1;
   Cdc42s(membDissocFlagCdc42,2,4) = 0;
   
   % Make sure to set next value even if you didn't dissociate or associate
   GEFs(~membAssocFlagGEF     & ~membDissocFlagGEF, 2,4) = ...
       GEFs(~membAssocFlagGEF     & ~membDissocFlagGEF, 1,4);   
   Cdc42s(~membAssocFlagCdc42 & ~membDissocFlagCdc42, 2,4) = ...
       Cdc42s(~membAssocFlagCdc42 & ~membDissocFlagCdc42, 1,4);
      
   %% ---------------------------------------------------------
   % Perform diffusion calculations. Update newly-bound and
   % newly-dissociated molecules accordingly. Reactivity and dissociation
   % flags have already accounted for explicit/implicit modeling.
   %% ---------------------------------------------------------
   
   % Get flags for reactive species. (Cdc42+GEF<->GEF42)
   reactedFlagsCdc42 = ReactedFlags(reactFlagCdc42,dissocFlagCdc42);
   reactedFlagsGEF   = ReactedFlags(reactFlagGEF,dissocFlagGEF);
   
   % Get flags for non-reactive, molecularly assocated species.
   % Force explicit only here.
   boundInertCdc42   = BoundInertFlags(reactedFlagsCdc42,Cdc42s(:,1,3))&Cdc42s(:,1,6);
   
   % Get flags for non-reactive, unbound species. 
   % Separate based on membrane or cytoplasmic. Force explicit here.
   unboundInertCdc42c = UnboundInertFlags(reactedFlagsCdc42,GEFs  (:,1,3),Cdc42s(:,1,4),'cyto') & Cdc42s(:,1,6);
   unboundInertCdc42m = UnboundInertFlags(reactedFlagsCdc42,GEFs  (:,1,3),Cdc42s(:,1,4),'memb') & Cdc42s(:,1,6);
   unboundInertGEFc   = UnboundInertFlags(reactedFlagsGEF  ,Cdc42s(:,1,3),GEFs  (:,1,4),'cyto') & GEFs(:,1,5);
   unboundInertGEFm   = UnboundInertFlags(reactedFlagsGEF  ,Cdc42s(:,1,3),GEFs  (:,1,4),'memb') & GEFs(:,1,5);
   
   % Move GEF particles away from Cdc42 particles because of dissociation.
   [x_dissoc_displ,y_dissoc_displ] = ...
       CalcPos_Dissociation(dissocFlagGEF,GEFs(:,1,1),GEFs(:,1,2),xwin,ywin,sigma);
   
   GEFs(:,2,1) = x_dissoc_displ; % This needs to go first - this is the only 
   GEFs(:,2,2) = y_dissoc_displ; % position update that hits all particles.
   
   % Brownian diffusion only for non-reactive species.
   % Bound species are in the membrane. Move bound GEFs with Cdc42s.
   Cdc42s(boundInertCdc42          ,2,1) = calcPos(Cdc42s(boundInertCdc42,1,1),Dmemb,dt,xwin,r_diffusGEF42x(boundInertCdc42));
   Cdc42s(boundInertCdc42          ,2,2) = calcPos(Cdc42s(boundInertCdc42,1,2),Dmemb,dt,ywin,r_diffusGEF42y(boundInertCdc42));
   GEFs(Cdc42s(boundInertCdc42,1,3),2,1) = Cdc42s(boundInertCdc42,2,1);
   GEFs(Cdc42s(boundInertCdc42,1,3),2,2) = Cdc42s(boundInertCdc42,2,2);
   
   % Separately need to perform calculations using membrane and cytoplasmic
   % diffusivities. Start with the x-dimension.
   Cdc42s(unboundInertCdc42c,2,1) = calcPos(Cdc42s(unboundInertCdc42c,1,1),Dcyto,dt,xwin,r_diffusCdc42x(unboundInertCdc42c));
   Cdc42s(unboundInertCdc42m,2,1) = calcPos(Cdc42s(unboundInertCdc42m,1,1),Dmemb,dt,xwin,r_diffusCdc42x(unboundInertCdc42m));
   GEFs(unboundInertGEFc    ,2,1) = calcPos(GEFs(unboundInertGEFc,1,1)    ,Dcyto,dt,xwin,r_diffusGEFx(unboundInertGEFc));
   GEFs(unboundInertGEFm    ,2,1) = calcPos(GEFs(unboundInertGEFm,1,1)    ,Dmemb,dt,xwin,r_diffusGEFx(unboundInertGEFm));
   % Y-dimension, typical diffusion
   Cdc42s(unboundInertCdc42c,2,2) = calcPos(Cdc42s(unboundInertCdc42c,1,2),Dcyto,dt,ywin,r_diffusCdc42y(unboundInertCdc42c));
   Cdc42s(unboundInertCdc42m,2,2) = calcPos(Cdc42s(unboundInertCdc42m,1,2),Dmemb,dt,ywin,r_diffusCdc42y(unboundInertCdc42m));
   GEFs(unboundInertGEFc    ,2,2) = calcPos(GEFs(unboundInertGEFc,1,2)    ,Dcyto,dt,ywin,r_diffusGEFy(unboundInertGEFc));
   GEFs(unboundInertGEFm    ,2,2) = calcPos(GEFs(unboundInertGEFm,1,2)    ,Dmemb,dt,ywin,r_diffusGEFy(unboundInertGEFm));
   
   % Move GEF particles to Cdc42 particles because of new binding.
   GEFs(reactFlagGEF(:),2,1) = Cdc42s(reactFlagCdc42(:),2,1);
   GEFs(reactFlagGEF(:),2,2) = Cdc42s(reactFlagCdc42(:),2,2);
   
   %% ---------------------------------------------------------
   % Perform particle injections and ejections, and set flags as
   % necessary. Note that GEF42 complexes are not cytosolic so there's no
   % concern over losing a binding partner.
   % Ejection uses the NEW states of particles to perform checks.
   %% ---------------------------------------------------------

   % Compute how many molecules to inject/eject. 
   NcurrGEFmemb   = sum(logical(GEFs(:,2,4))   & logical(GEFs(:,1,5)));
   NcurrCdc42memb = sum(logical(Cdc42s(:,2,4)) & logical(Cdc42s(:,1,6)));

   % Search the injection/ejection integral lookup tables
   targ_GEF_inj   = find(nGEF_inj_prev   == (nGEFtot-NcurrExGEF)                 ,1);
   targ_GEF_ejc   = find(nGEF_ejc_prev   == (        NcurrExGEF-NcurrGEFmemb)    ,1);
   targ_Cdc42_inj = find(nCdc42_inj_prev == (nCdc42tot-NcurrExCdc42)             ,1);
   targ_Cdc42_ejc = find(nCdc42_ejc_prev == (        NcurrExCdc42-NcurrCdc42memb),1);

   % Determine how many to inject/eject based on the target values
   mean_next_GEF_inj   = round(nGEF_inj(targ_GEF_inj));
   mean_next_Cdc42_inj = round(nCdc42_inj(targ_Cdc42_inj));
   mean_next_GEF_ejc   = round(nGEF_ejc(targ_GEF_ejc));
   mean_next_Cdc42_ejc = round(nCdc42_ejc(targ_Cdc42_ejc));

   % Generate random samples from Poisson distribution. Limit inj/ejc by
   % the available number of molecules 
   injejcRands = rand(1,4);
   next_GEF_inj = min(poissinv(injejcRands(1),mean_next_GEF_inj),nGEFtot-NcurrExGEF);
   next_Cdc42_inj = min(poissinv(injejcRands(2),mean_next_Cdc42_inj),nCdc42tot-NcurrExCdc42);
   next_GEF_ejc = min(poissinv(injejcRands(3),mean_next_GEF_ejc),NcurrExGEF-NcurrGEFmemb);
   next_Cdc42_ejc = min(poissinv(injejcRands(4),mean_next_Cdc42_ejc),NcurrExCdc42-NcurrCdc42memb);
   
   if DEBUG_CDC42T_COUNT % && (mod(i,100) ==0)      
     fprintf('count Cdc42T(@%i) pre-set: %i\n',i,sum(~Cdc42s(:,1,5)));
   end

   % Randomly select cytoplasmic particles to remove
   if next_GEF_ejc > 0
       explicit_cyto_GEFs = find( logical(GEFs(:,1,5)) & ~logical(GEFs(:,2,4)) );
       GEFs_to_eject = datasample(explicit_cyto_GEFs,next_GEF_ejc,'replace',false);
       GEFs(GEFs_to_eject,2,5) = 0; % Set as implicit.
   end
   if next_Cdc42_ejc > 0
       explicit_memb_Cdc42s = find( logical(Cdc42s(:,1,6)) & ~logical(Cdc42s(:,2,4)) );
       Cdc42s_to_eject = datasample(explicit_memb_Cdc42s,next_Cdc42_ejc,'replace',false);
       Cdc42s(Cdc42s_to_eject,2,6) = 0; % Set as implicit.
   end

   % Add in new cytoplasmic particles at new positions.
   if next_GEF_inj > 0
       GEFs_to_add     = datasample(find(GEFs(:,1,5)==0),next_GEF_inj,'replace',false);
       GEFs(GEFs_to_add,2,1) = unifrnd(-xwin,xwin,next_GEF_inj,1);
       GEFs(GEFs_to_add,2,2) = unifrnd(-ywin,ywin,next_GEF_inj,1);
       GEFs(GEFs_to_add,2,3) = 0;
       GEFs(GEFs_to_add,2,4) = 0;
       GEFs(GEFs_to_add,2,5) = 1;
   end

   if DEBUG_CDC42T_COUNT % && (mod(i,100) ==0)      
      fprintf('count Cdc42T(@%i) post-set: %i\n',i,sum(~Cdc42s(:,1,5)));
   end

   if next_Cdc42_inj > 0
       Cdc42s_to_add = datasample(find(Cdc42s(:,1,6)==0),next_Cdc42_inj,'replace',false);
       Cdc42s(Cdc42s_to_add,2,1) = unifrnd(-xwin,xwin,next_Cdc42_inj,1);
       Cdc42s(Cdc42s_to_add,2,2) = unifrnd(-ywin,ywin,next_Cdc42_inj,1);
       Cdc42s(Cdc42s_to_add,2,3) = 0; % no bound partner
       Cdc42s(Cdc42s_to_add,2,4) = 0; % cytoplasmic
       Cdc42s(Cdc42s_to_add,2,5) = 1; % GDP bound form
       Cdc42s(Cdc42s_to_add,2,6) = 1;
   end
   

   if DEBUG_POSITION
      fprintf('coord Cdc42(1@%i): (%g,%g)\n',i,Cdc42s(1,2,1),Cdc42s(1,2,2));
   end
   
   if DEBUG_CDC42T_COUNT && (mod(i,100) ==0)      
      fprintf('count Cdc42T(@%i): %i\n',i,sum(~Cdc42s(:,1,5)));
   end
   
   
   %% ---------------------------------------------------------
   % Transfer timestep information within the matrices.
   %% ---------------------------------------------------------
   Cdc42s(:,1,1) = Cdc42s(:,2,1);
   Cdc42s(:,1,2) = Cdc42s(:,2,2);
   Cdc42s(:,1,3) = Cdc42s(:,2,3);
   Cdc42s(:,1,4) = Cdc42s(:,2,4);
   Cdc42s(:,1,5) = Cdc42s(:,2,5);
   Cdc42s(:,1,6) = Cdc42s(:,2,6);
   
   GEFs(:,1,1)   = GEFs(:,2,1);
   GEFs(:,1,2)   = GEFs(:,2,2);
   GEFs(:,1,3)   = GEFs(:,2,3);
   GEFs(:,1,4)   = GEFs(:,2,4);
   GEFs(:,1,5)   = GEFs(:,2,5);
   
   %% ---------------------------------------------------------
   % Export data to a the CoordTracker matrix.
   % 1 - GEFc       4 - Cdc42Dc
   % 2 - GEFm       5 - Cdc42Dm
   % 3 - GEF42      6 - Cdc42T
   %% ---------------------------------------------------------
   if mod(i-1,datagrain) == 0
       grainstep = ceil(i/datagrain);
       
       CoordTracker(grainstep,        1:nGEFtot          ,1) = GEFs(:,1,1);
       CoordTracker(grainstep,        1:nGEFtot          ,2) = GEFs(:,1,2);
       CoordTracker(grainstep,nGEFtot+1:nCdc42tot+nGEFtot,1) = Cdc42s(:,1,1);
       CoordTracker(grainstep,nGEFtot+1:nCdc42tot+nGEFtot,2) = Cdc42s(:,1,2);
       
       % Stitch together binding information.
       retainedBindingFlagsCdc42 = RetainedBindingFlags(Cdc42s(:,1,3),dissocFlagCdc42);
       combinedBoundCdc42 = retainedBindingFlagsCdc42;
       combinedBoundCdc42(reactFlagCdc42) = true;
       combinedBoundGEF = Cdc42s(combinedBoundCdc42,1,3); 

       % Inverted because a bound value refers to the index of the
       % corresponding particle.
       boundGEF   = Cdc42s(combinedBoundCdc42,1,3);
       boundCdc42 = GEFs(combinedBoundGEF,1,3); 

       % Filter for unbound
       unboundGEF   = setdiff(1:nGEFtot,boundGEF);
       unboundCdc42 = setdiff(1:nCdc42tot,boundCdc42);

       % Filter for membrane association. 
       % Get index values, not logical indexes.
       unbound_membraneGEF   = intersect(unboundGEF,find(GEFs(:,1,4)));
       unbound_membraneCdc42 = intersect(unboundCdc42,find(Cdc42s(:,1,4)));

       unbound_cytoGEF       = setdiff(unboundGEF,unbound_membraneGEF);
       unbound_cytoCdc42     = setdiff(unboundCdc42,unbound_membraneCdc42);

       % Filter Cdc42s for GxP
       gdp_cdc42 = find(Cdc42s(:,1,5));
       unbound_membraneCdc42_gdp = intersect(gdp_cdc42,unbound_membraneCdc42);
       unbound_cytoCdc42_gdp     = intersect(gdp_cdc42,unbound_cytoCdc42);
       gtp_cdc42 = find(~Cdc42s(:,1,5)); % All Cdc42T
       GEF42s    = intersect(boundCdc42,gtp_cdc42); % All GEF42
       gtp_cdc42 = setdiff(gtp_cdc42,GEF42s); % Cdc42s without GEF bound

       implicitGEFs = find(GEFs(:,1,5)==0);
       implicitCdc42s = find(Cdc42s(:,1,6)==0);
       
       % Export data to a the CoordTracker matrix.
       % 1 - GEFc       4 - Cdc42Dc
       % 2 - GEFm       5 - Cdc42Dm
       % 3 - GEF42      6 - Cdc42T
       % Note that GEF42s will be counted twice - one from Cdc42 particles 
       % and one from GEF particles
       CoordTracker(grainstep,        unbound_cytoGEF,          3) = 1;
       CoordTracker(grainstep,        unbound_membraneGEF,      3) = 2;
       CoordTracker(grainstep,        boundGEF,                 3) = 3;
       CoordTracker(grainstep,nGEFtot+unbound_cytoCdc42_gdp,    3) = 4;
       CoordTracker(grainstep,nGEFtot+unbound_membraneCdc42_gdp,3) = 5;
       CoordTracker(grainstep,nGEFtot+gtp_cdc42,                3) = 6;
       CoordTracker(grainstep,nGEFtot+GEF42s,                   3) = 3;
       CoordTracker(grainstep,        implicitGEFs,             3) = 0;
       CoordTracker(grainstep,nGEFtot+implicitCdc42s,           3) = 0;
   
   
   end
   
end

%% ---------------------------------------------------------
% Timestep iteration over. Save data and clear objects.
%% ---------------------------------------------------------

time_whole = toc

% Save .mat files
data_mat = strcat(outfile,'_dat.mat');
save(data_mat,'CoordTracker','-v7.3'); % These files can get really large if the simulation runs a long time.
clear CoordTracker;
output_mat = strcat(outfile,'_par.mat');
save(output_mat);

%matlabpool close

end

% Function to establish data structures.
function [outfile,todays_date]=SetFolderbyDate(filebasename)
if ispc
    todays_date = num2str(yyyymmdd(datetime)); % folder
    todays_date = strcat(todays_date,'\');
    outfile     = strcat(todays_date,'\',filebasename);
elseif ismac
    todays_date = num2str(yyyymmdd(datetime)); % folder
    todays_date = strcat(todays_date,'/');
    outfile     = strcat(todays_date,'/',filebasename);
elseif isunix
    % Minor difference from actual dirs in the *nix format..
    % pc and mac give YYYYMMDD
    % *nix gives YYYY_M_D, where M and D can have 1 or 2 digits. Added
    % underscores for clarity; just note you cannot integrate
    % *nix names directly with pc or mac names if automating analysis
    mytime=clock;
    mytime=mytime(1:3); % get YYYYMD only
    todays_date=strrep(regexprep(num2str(fix(mytime)),' +',' '),' ','_');
    todays_date = strcat(todays_date,'/');
    outfile     = strcat(todays_date,'/',filebasename);
end
end


% Function to calculate the lambda reaction probability rate. 
function [ lambda_targ ] = computeLambda(ktarg,r,s,d1,d2)
% Lambda depends on a macroscopic bimolecular rate constant ktarg,
% reaction capture radius r, and diffusion coefficients d1 and d2.
% Derived by M. Pablo for a 2D polar coordinate model based on the 2011
% Lipkova/Erban paper in SIAM J Appl. Math. Assumes ktarg is in units of
% 1/uM*s

liters_per_cubic_meters = 10^3;
microns_per_meter = 10^6;
micromoles_per_mol = 10^-6;
Nav = 6.02 * 10^23;
membThickness = 0.0083; % um

% Assuming ktarg is in units of 1/uM*s and converting to um^3/s
ktarg=ktarg * microns_per_meter^3 / ... 
        (liters_per_cubic_meters * micromoles_per_mol) / Nav;

% Converting now from um^3/s to um^2/s, adjusting it to a 2D rate constant
ktarg=ktarg / membThickness

% Solving this function's zeros returns lambda_targ
f =@(rho,sigma,Dtot,lambda)findRate_lim(rho,sigma,Dtot,lambda)-ktarg;

% Possible values of lambda (reasonable range to guess)
l=0.1:0.1:10^5; % --> May need to adjust this initial guess range depending on the kinetics specified.


% Find solutions for findRate_lim(lambda;rho,sigma,Dtot) = ktarg
t = f(r,s,d1+d2,l) > 0;
i0 = find(diff(t(:))~=0);
i0 = [i0(:)';i0(:)'+1];
n=size(i0,2);
xout = zeros(n,1);
rho=r;
sigma=s;
Dtot=d1+d2;
for jj = 1:n
    xout(jj) = fzero(@(lambda) f(rho,sigma,Dtot,lambda),l(i0(:,jj)));
end

lambda_targ=xout;
if isempty(lambda_targ)    
    error(strcat('Could not find a solution for lambda for rate',{' '},...
                 num2str(ktarg)));
end
end

                        
                         
% Analytic functions that relate macroscopic rate constant k to lambda and
% stochastic reaction parameters. Chooses different functionscompute based on the
% sigma:rho ratio.
function [k] = findRate_lim(r,s,D,p)
% Analytic function k=f(lambda;r,D,p).
% Returns the synthesis rate constant in limiting case described.
% D is the sum of both diffusion constants.
% r is capture radius
% p is reaction probability.

    temp=r.*sqrt(p./D);

    if s >= r
        k = (D.*2.*pi.*temp.*(besseli(1,temp)./besseli(0,temp)))./...
                    (1+log(s./r).*temp.*(besseli(1,temp)./besseli(0,temp)));
    else
        error('Invalid choice of sigma and rho')
    end
end

% This is kept as a legacy function, but the simulation code really uses the _mex version for speed.
function [d2] = SQeuclTorus(ZI,ZJ,FULLXWIN,FULLYWIN)
% Calculates squared euclidean distances between points on a periodic 2D plane.
% The plane is described xwin, ywin.
% the inputs:
%     ZI - some arbitrary 1-by-n vector that contains a single observation
%     from X or Y in pdist2(X,Y,@euclTorus(ZI,ZJ) euclTorus(X,Y,XWIN,YWIN))
%     ZJ - the m2-by-n matrix containing multiple observations from Y or X.
%the output:
%     d2 - an m2-by-1 vector of distances whose Jth element is the distance
%     between the observations ZI and ZJ(J,:).

diff=bsxfun(@minus,ZI,ZJ); % subtract each coordinate in the ZI observation...
                     % from each coordinate in the ZJ(j)-th observation.
                     % Return a matrix size ZJ.

% Take the sum of the minimized squares.
d2=bsxfun(@min,abs(diff(:,1)),FULLXWIN-abs(diff(:,1))).^2 + ...
   bsxfun(@min,abs(diff(:,2)),FULLYWIN-abs(diff(:,2))).^2;

end

% Function to obtain a collision matrix. The matrix is sorted, and the
% pre-sort indices are given alongside it.
function [CollMatIdx] = getCollisionMatrix(partsA,partsB,rad,xwin)
% Precalculate this for all explicit particles so I only need to do it
% once.

% Logical indexing to speed things up
Ahash = logical(partsA(:,1,6));
Bhash = logical(partsB(:,1,5));

posA = squeeze(partsA(Ahash,1,1:2)); % Squeeze to remove the singleton dimension
posB = squeeze(partsB(Bhash,1,1:2));

collMat = true(sum(Ahash),sum(Bhash));

collMat = sqEuclTorus_mex(posA,posB,xwin*2) >= (rad^2);
CollMatIdx = find(collMat==0);
end

% Function to find paired association reactions
function [listA,listB] = getReactionList(sortedIDX,partsA,partsB,lambda1,lambda2,dt)
%  Returns flagged particle indices.

prob1 = lambda1*dt; % Membrane GEF
prob2 = lambda2*dt; % Cytosolic GEF
[numA,~,~] = size(partsA);
[numB,~,~] = size(partsB);

% Build the hash vectors
Ahash = find(partsA(:,1,6));
Bhash = find(partsB(:,1,5));

listA=zeros(numA,1);
listB=zeros(numB,1);
returnIndex=1;
for i=1:length(sortedIDX)
%     if sorted(i) == true
%         break;
%     else
        % Return to 'true' indices -- single step indexing from
        % the collision matrix in hashed indices, to the real indices.
        idxA=Ahash(mod(sortedIDX(i)-1,length(Ahash))+1);
        idxB=Bhash(floor((sortedIDX(i)-1)/length(Ahash))+1);
        
        % Skip if the particle is in a complex already
        if partsA(idxA,1,3) ~= 0 || partsB(idxB,1,3) ~= 0
            continue;
        end
        % Skip if the Cdc42 is in the GDP bound state.
        if partsA(idxA,1,5) == 1
            continue;
        end
                
        % Use different probabilities depending on the state of the GEF.
        if  partsB(idxB,1,4) == 1 % Membrane bound
            prob = prob1;
        elseif partsB(idxB,1,4) == 0 % Cytosolic
            prob = prob2;
        end
        
        check=rand(1,1);
        if check<prob
            % Check if the particle is already flagged
            if max(max(idxA==listA)) || max(max(idxB==listB))
                continue;
            end
                         
            listA(returnIndex)=idxA;
            listB(returnIndex)=idxB;
            returnIndex=returnIndex+1;
        end
end
listA=listA(listA~=0);
listB=listB(listB~=0);
end

% Function to find paired dissociation reactions
% Uses A-particles as the reference.
function [dissocFlagA,dissocFlagB] = getDissocList(partsA,NB,kr,dt,rand_dissocAB)
probDissoc = dissociationProbability(kr,dt);
dissocFlagA = logical(rand_dissocAB < probDissoc);

% Set flags to zero if there is nothing bound; ignore implicit particles
dissocFlagA=dissocFlagA & logical(partsA(:,1,3)) & logical(partsA(:,1,6));    

dissocFlagB = false(NB,1);
dissocFlagB(partsA(dissocFlagA,1,3)) = 1; % Flag the corresponding partners

end

% Function to find Cdc42T hydrolysis reactions.
function [hydrolFlag] = getHydrolList(partsA,k,dt,rand_hydrol)
hydrolFlag = logical(rand_hydrol < hydrolysisProbability(k,dt));

% Require the molecule to originally be in Cdc42-GTP state with no GEF.
hasGTP   = ~logical(partsA(:,1,5));
hasNoGEF = ~logical(partsA(:,1,3));
isExplicit = logical(partsA(:,1,6));
hydrolFlag = hydrolFlag & hasGTP & hasNoGEF & isExplicit;
end

% Function to find membrane association reactions.
function [membraneAssocFlag] = getCdc42MembraneAssocList(partsA,k,dt,rand_membAssoc)
probMembAssoc = membraneAssocProbability(k,dt);
membraneAssocFlag = logical(rand_membAssoc < probMembAssoc);

% Require the molecule originally be in the cytosol.
isCytosolic = ~logical(partsA(:,1,4));
hasGDP      =  logical(partsA(:,1,5));
willhaveGDP =  logical(partsA(:,2,5)); % GxP exchange should be done by the time this is called.
isExplicit  =  logical(partsA(:,1,6));
membraneAssocFlag = membraneAssocFlag & isCytosolic & hasGDP & ...
                    willhaveGDP & isExplicit;
end

% Function to find membrane dissociation reactions.
function [membraneDissocFlag] = getCdc42MembraneDissocList(partsA,k,dt,rand_membDissoc)
probMembDissoc = membraneDissocProbability(k,dt);
membraneDissocFlag = logical(rand_membDissoc < probMembDissoc);

% Require the molecule originally be in the membrane.
isInMembrane = logical(partsA(:,1,4));
hasGDP      = logical(partsA(:,1,5));
willhaveGDP = logical(partsA(:,2,5)); % GxP exchange should be done by the time this is called.
isExplicit  = logical(partsA(:,1,6));
membraneDissocFlag = membraneDissocFlag & isInMembrane & hasGDP & ...
                     willhaveGDP & isExplicit;
end

% Function to find membrane association reactions.
function [membraneAssocFlag] = getGEFMembraneAssocList(partsA,k,dt,rand_membAssoc)
probMembAssoc = membraneAssocProbability(k,dt);
membraneAssocFlag = logical(rand_membAssoc < probMembAssoc);

% Require the molecule originally be in the cytosol.
isCytosolic = ~logical(partsA(:,1,4));
isExplicit = logical(partsA(:,1,5));
membraneAssocFlag = membraneAssocFlag & isCytosolic & isExplicit;
end

% Function to find membrane dissociation reactions.
function [membraneDissocFlag] = getGEFMembraneDissocList(partsA,k,dt,rand_membDissoc)
probMembDissoc = membraneDissocProbability(k,dt);
membraneDissocFlag = logical(rand_membDissoc < probMembDissoc);

% Require the molecule originally be in the membrane.

% require the molecule to not have been previously bound to a Cdc42?

isInMembrane = logical(partsA(:,1,4));
isExplicit = logical(partsA(:,1,5));
membraneDissocFlag = membraneDissocFlag & isInMembrane & isExplicit;
end


% Function to find GEF-catalyzed GDP -> GTP exchange reactions.
% Cdc42 MUST be the first argument for GxP state checks.
function [found] = getExchangeList(sortedIDX,partsA,partsB,lambda2,lambda3,dt)

prob2 = lambda2*dt; % Membrane bound GEF
prob3 = lambda3*dt; % GEF42 complex
[numA,~,~]=size(partsA);

% Build the hash vectors
Ahash = find(partsA(:,1,6));
Bhash = find(partsB(:,1,5));

found=zeros(numA,1);
successfulCatalysis=[];
for i=1:length(sortedIDX)
%     if sorted(i) == true
%         break;
%     end
    
    % Calling sort() unwrapped the matrix into a vector, so calculate
    % what matrix indices the vector index corresponds to.
    idxA=Ahash(mod(sortedIDX(i)-1,length(Ahash))+1);
    idxB=Bhash(floor((sortedIDX(i)-1)/length(Ahash))+1);

    % Skip if the Cdc42 has GTP bound or if it is in the cytoplasm
    if partsA(idxA,1,5) == 0 || partsA(idxA,1,4) == 0
        continue;
    end
    
    % Skip if the GEF is cytoplasmic.
    if partsB(idxB,1,4) == 0
        continue;
    end
    
    % Use different probabilities depending on the state of the GEF.
    if partsB(idxB,1,4) == 1 % Membrane bound
        prob = prob2;
    end
    if partsB(idxB,1,3) ~= 0 % Cdc42-GEF complex
        prob = prob3;
    end

    % If the GEF already has performed catalysis, skip.
    if max(max(idxB == successfulCatalysis))
        continue;
    end

    if rand(1,1) < prob
        if max(max(idxA==found))
            continue;
        end
                         
        found(idxA) = idxA;
        successfulCatalysis=vertcat(successfulCatalysis,idxB);
     end
end
found=found(found~=0);
end

% Function to determine if dissociation happens
function [P] = dissociationProbability(k,dt)
P=1-exp(-k*dt);
end

% Function to determine if hydrolysis happens
function [P] = hydrolysisProbability(k,dt)
P=1-exp(-k*dt);
end

% Function to determine if membrane association happens.
function [P] = membraneAssocProbability(k,dt)
P=1-exp(-k*dt);
end

% Function to determine if membrane dissociation happens.
function [P] = membraneDissocProbability(k,dt)
P=1-exp(-k*dt);
end

% Function to perform a diffusion step
function [newPos] = calcPos(pos, D, dt, bound, z)
% The position function is updated (symetrically for x and y)
% as x(t+dt)=x(t)+sqrt(2D*dt)Z_i
% where
% x is a vector of coordinates (x1 = x, x2 = y)
% t is time
% dt is the timestep
% D is the diffusion coefficient of the particle
% Z_i is an vector of Gaussian random variable, mean=0, stdev=1

delta=sqrt(2*D*dt)*z;
newPos=pos+delta;

newPos=adjustForBounds(newPos,bound); 

end

% Function to adjust the input coordinates for the boundary conditions.
    % Can use as oldXY == newXY to see if a change occurs
function [pos] = adjustForBounds(pos, bound)

% PERIODIC BOUNDARIES MODE FOR VECTOR pos
timesExceeded=floor((abs(pos)+bound)/(2*bound));
pos = pos -sign(pos)* 2*bound.*timesExceeded;

end
        
% Function to represent a NULLVAL
function [val] = NULLVAL()
val=999999;
end

% Get a random number vector for dissociation reactions
% Maximal # needed is based on the limiting reagent
function [ret] = RandVec_Dissoc(N)
ret=rand(N,1);
end

% Get a random number vector for diffusion
% These are normal random numbers with mean zero and variance 1.
function [ret] = RandVec_Diffus(N)
ret=normrnd(0,1,N,1);
end

% Get a random number vector for GTP hydrolysis
function [ret] = RandVec_Hydrol(N)
ret = rand(N,1);
end

% Get a random number vector for membrane dissociation
function [ret] = RandVec_MembDissoc(N)
ret = rand(N,1);
end

% Get a random number vector for membrane association
function [ret] = RandVec_MembAssoc(N)
ret = rand(N,1);
end

% Compute new positions for all particles of A after dissociation from
% complexes AB. The B particles do not move.
% Expects oldApos as a Nx1 matrix in 1D, or Nx2 matrix in 2D.
function [newAposx,newAposy] = CalcPos_Dissociation(dissocFlagA,oldAposx,oldAposy,xwin,ywin,sigma)
randTheta = rand(length(dissocFlagA),1)*2*pi;

% In 2D
newAposx = oldAposx + sigma*cos(randTheta).*logical(dissocFlagA);
newAposy = oldAposy + sigma*sin(randTheta).*logical(dissocFlagA);

newAposx = adjustForBounds(newAposx,xwin);
newAposy = adjustForBounds(newAposy,ywin);
end

% Get flags for particles that have retained binding
function [flags] = RetainedBindingFlags(Abinders,Adissocs)
flags=logical(Abinders)&(~Adissocs);
end

% Get flags for particles that reacted this timestep
function [flags] = ReactedFlags(assocflags,dissocflags)
% Adissocs is NA x 1 vector
% Aassocs  is an arbitrarily sized vector with unique values [1,NA]
flags=logical(dissocflags);
flags(assocflags)=1;
end

% Get flags for particles that were unreactive but are bound to something
% Pass the reaction flags for A, and As(:,1,actualbounds)
function [flags] = BoundInertFlags(reactedflags,boundindexes)
flags= logical(boundindexes)&(~reactedflags);
end

% Get flags for particles that were unreactive and are not bound 
function [flags] = UnboundInertFlags(reactedflags,boundindexes,membdata,specialRule)

boundflags=zeros(length(membdata),1);
boundindexes=boundindexes(boundindexes~=0); % get index values of the bound speces of interest
boundflags(boundindexes)=1;
isInMembrane = logical(membdata);
if strcmp(specialRule,'cyto')   
    flags = (~boundflags) & (~reactedflags) & ~isInMembrane;
elseif strcmp(specialRule,'memb')
    flags = (~boundflags) & (~reactedflags) &  isInMembrane;
else
    error('Invalid argument to UnboundInertFlags');
end

end

function [n_inj_exact,n_inj_depend] = calc_injection(d_cell,dt,D,z_eff,potential_N)
% d_cell : Cell diameter (um)
%     dt : timestep (s)
%      D : diffusivity (um^2/s)
%  z_eff : effective explicit cytoplasmic depth.
% Probabilities vary along z, which is the 'depth' of the cell assuming a
% rectangular prism geometry.
% Integrates over all relevant z values, then returns the distribution
% that corresponds to all potential N values (depend)
% Additionally corrects for membrane implicit thickness (0.0083)


Vcell = 4/3*pi*(d_cell/2)^3; % um^3
SA = 4*pi*(d_cell/2)^2; % um^2
z_reserv = (Vcell/SA-0.0083) - z_eff;

% Rectangular prism reservoir, discretized at 100000 slices
z = linspace(0,Vcell/SA - z_eff-0.0083,100000); 

n_inj_depend = (0:potential_N);
n_inj_exact  = n_inj_depend / (z_reserv*SA) * SA * trapz(z,1/2*(erf( ((Vcell/SA-0.0083) - z) / sqrt(4*D*dt)) - erf( ((Vcell/SA-0.0083) - z_eff - z) / sqrt(4*D*dt))));
end

function [n_eject_exact,n_eject_depend] = calc_ejection(d_cell,dt,D,z_eff,potential_N)
% d_cell : Cell diameter (um)
%     dt : timestep (s)
%      D : diffusivity (um^2/s)
%  z_eff : effective explicit cytoplasmic depth.
% Probabilities vary along z, which is the 'depth' of the cell assuming a
% rectangular prism geometry.
% Integrates over all relevant z values, then returns the distribution
% that corresponds to all potential N values
% Additionally corrects for membrane implicit thickness (0.0083)


Vcell = 4/3*pi*(d_cell/2)^3; % um^3
SA = 4*pi*(d_cell/2)^2; % um^2

% Explicit cytoplasm, discretized at 100000 slices
z = linspace(Vcell/SA-z_eff-0.0083,Vcell/SA-0.0083,100000); 

n_eject_depend = (0:potential_N);
n_eject_exact  = n_eject_depend / (SA*z_eff) * SA * trapz(z,1/2*(erf(z/sqrt(4*D*dt)) - erf( (z + z_eff - (Vcell/SA-0.0083)) / sqrt(4*D*dt))));
end

