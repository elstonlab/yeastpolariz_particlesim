function empiricalFitSim(nA,nB,nC,DAmemb,DBmemb,DAcyto,DBcyto,lambda,konA,koffA,konB,koffB,rho,sigma,halfwinlen,dt,nsteps,datagrain,filebasename,rngseed)
% If a membrane on-rate is specified, all molecules begin in the cytoplasm (no bimolec. rxns there)

tic

DO_DIAGNOSTICS = true;

fprintf('Initializing simulation with rng %i\n',rngseed);

rng(rngseed);

% For record keeping, estimate expected kf based on the 2D-lambda rho method.
D = DAmemb + DBmemb;
beta=rho.*sqrt(lambda./D);
kf = (D.*2.*pi.*beta.*(besseli(1,beta)./besseli(0,beta)))./...
     (1+log(sigma./rho).*beta.*(besseli(1,beta)./besseli(0,beta)));
  
kr = 0;

A = zeros(nA,4); % x y bound memb
B = zeros(nB,4); % x y bound memb
A(:,1:2) = unifrnd(-halfwinlen,halfwinlen,nA,2);
B(:,1:2) = unifrnd(-halfwinlen,halfwinlen,nB,2);

if konA == 0
    disp('There is no membrane on-rate specified for A, so setting all species to begin in the membrane.');
    A(:,4) = 1;
end
if konB == 0
    disp('There is no membrane on-rate specified for B, so setting all species to begin in the membrane.');
    B(:,4) = 1;
end

P_fwd = lambda*dt;
P_rev = 1-exp(-kr*dt);
P_onA  = 1-exp(-konA*dt);
P_offA = 1-exp(-koffA*dt);
P_onB  = 1-exp(-konB*dt);
P_offB = 1-exp(-koffB*dt);

fprintf('P_fwd = %g \t P_rev = %g\n P_onA = %g \t P_pffA = %g \n P_onB = %g \t P_offB = %g\n',...
        P_fwd,P_rev,P_onA,P_offA,P_onB,P_offB);

if DO_DIAGNOSTICS
    disp('Diagnostics:')
    RMS_to_rho = sqrt(2*(DAmemb+DBmemb)*dt)/rho;
    fprintf('stepRMS/rho = %g\n',RMS_to_rho)
    if RMS_to_rho > 0.1
        fprintf('\tstepRMS/rho value perhaps too large?\n');
    end
    fprintf('P_fwd = %g\n',P_fwd);
    fprintf('P_rev = %g\n',P_rev);
    fprintf('P_on = %g\n',P_onA);
    fprintf('P_off = %g\n',P_offA);
end

outputsteps = nsteps/datagrain;
assert(mod(nsteps,datagrain)==0,'Invalid slicing of nsteps by datagrain');

CoordTracker.A = zeros([outputsteps,size(A)]);
CoordTracker.B = zeros([outputsteps,size(B)]);
CoordTracker.time = 0:dt*datagrain:(nsteps-1)*dt;

if nC ~= 0
   assert(nC < nA && nC < nB,'Specified more complex present than reactants');
   fprintf('Initializing with %i complexes at start \n',nC);
   
   A(1:nC,1:2) = B(1:nC,1:2);
   A(1:nC,3) = 1:nC;
   B(1:nC,3) = 1:nC;    
end

% Simulation loop -------------------------------------------------------
for i=1:nsteps
   if mod(i,nsteps/10) == 0
       fprintf('Completed %g %% of modelling.\n',100*i/nsteps);
   end
   
   if mod(i-1,datagrain) == 0
       grainstep = ceil(i/datagrain);
       CoordTracker.A(grainstep,:,:) = A;
       CoordTracker.B(grainstep,:,:) = B;
   end
   
   % Get reaction flags -------------------------------------------------
   [AidxBidx_fwdrxn] = GetRxnMat(A,B,P_fwd,rho,halfwinlen);  
   [bool_Aidx_revrxn] = GetRxnFirstOrder(logical(A(:,3)),P_rev);
   Bidx_revrxn = A(bool_Aidx_revrxn,3);
   bool_Bidx_revrxn = false(nB,1); bool_Bidx_revrxn(Bidx_revrxn) = true;
   bool_A_didReact = false(nA,1);   
   bool_B_didReact = false(nB,1);
   if ~isempty(AidxBidx_fwdrxn)
      bool_A_didReact(AidxBidx_fwdrxn(:,1)) = true;
      bool_B_didReact(AidxBidx_fwdrxn(:,2)) = true;
   end
   bool_A_didReact(bool_Aidx_revrxn) = true;
   bool_B_didReact(bool_Bidx_revrxn) = true;
   
   [bool_Aoff2on] = GetRxnFirstOrder(~logical(A(:,4)),P_onA); % Cytoplasmic species cannot have other reactions
   [bool_Aon2off] = GetRxnFirstOrder(logical(A(:,4)) & ~bool_A_didReact & ~logical(A(:,3)),P_offA); % Must be membrane bound, cannot have reacted, and cannot have a bound partner.
   
   [bool_Boff2on] = GetRxnFirstOrder(~logical(B(:,4)),P_onB); % Cytoplasmic species cannot have other reactions
   [bool_Bon2off] = GetRxnFirstOrder(logical(B(:,4)) & ~bool_B_didReact & ~logical(B(:,3)),P_offB);% Must be membrane bound, cannot have reacted, and cannot have a bound partner.

   
   % Positional updates -------------------------------------------------
   
   % Sort through reaction flags as needed.
   A_doDissocMove = bool_Aidx_revrxn;
   B_doDissocMove = bool_Bidx_revrxn;
   
   bool_A_retainsPartner = logical(A(:,3)) & ~bool_Aidx_revrxn;
   bool_B_retainsPartner = logical(B(:,3)) & ~bool_Bidx_revrxn;
   
   Bidx_retainsPartner = A(bool_A_retainsPartner,3);
   Aidx_retainsPartner = B(Bidx_retainsPartner,3);
   nRemainedBound = sum(logical(Aidx_retainsPartner));
   
   bool_A_doRandomWalk = true(nA,1);
   bool_B_doRandomWalk = true(nB,1);
   
   bool_A_doRandomWalk(A_doDissocMove | bool_A_retainsPartner) = false;   
   bool_B_doRandomWalk(B_doDissocMove | bool_B_retainsPartner) = false;
   if ~isempty(AidxBidx_fwdrxn)
      bool_A_doRandomWalk(AidxBidx_fwdrxn(:,1)) = false;
      bool_B_doRandomWalk(AidxBidx_fwdrxn(:,2)) = false;
   end
      

   
   
   % Bring together new binders
   if ~isempty(AidxBidx_fwdrxn)
      A(AidxBidx_fwdrxn(:,1),1:2) = B(AidxBidx_fwdrxn(:,2),1:2);
   end
   % Codiffuse those retaining binding
   A(Aidx_retainsPartner,1) = calcPos(A(Aidx_retainsPartner,1),DAmemb,dt,halfwinlen,normrnd(0,1,nRemainedBound,1));
   A(Aidx_retainsPartner,2) = calcPos(A(Aidx_retainsPartner,2),DAmemb,dt,halfwinlen,normrnd(0,1,nRemainedBound,1));
   B(Bidx_retainsPartner,1:2) = A(Aidx_retainsPartner,1:2);
   
   % Dissociate as needed
   A(A_doDissocMove,1:2) = calcPos_dissoc(B(B_doDissocMove,1:2),halfwinlen,sigma);
   
   % Let the remainder diffuse according to random walk
   A_RWmemb = bool_A_doRandomWalk &  logical(A(:,4));
   B_RWmemb = bool_B_doRandomWalk &  logical(B(:,4));
   A_RWcyto = bool_A_doRandomWalk & ~logical(A(:,4));
   B_RWcyto = bool_B_doRandomWalk & ~logical(B(:,4));
   
   nA_RWm = sum(A_RWmemb);
   nB_RWm = sum(B_RWmemb);   
   nA_RWc = sum(A_RWcyto);
   nB_RWc = sum(B_RWcyto);
   
   A(A_RWmemb,1) = calcPos(A(A_RWmemb,1),DAmemb,dt,halfwinlen,normrnd(0,1,nA_RWm,1));
   A(A_RWmemb,2) = calcPos(A(A_RWmemb,2),DAmemb,dt,halfwinlen,normrnd(0,1,nA_RWm,1));
   B(B_RWmemb,1) = calcPos(B(B_RWmemb,1),DBmemb,dt,halfwinlen,normrnd(0,1,nB_RWm,1));
   B(B_RWmemb,2) = calcPos(B(B_RWmemb,2),DBmemb,dt,halfwinlen,normrnd(0,1,nB_RWm,1));
   
   A(A_RWcyto,1) = calcPos(A(A_RWcyto,1),DAcyto,dt,halfwinlen,normrnd(0,1,nA_RWc,1));
   A(A_RWcyto,2) = calcPos(A(A_RWcyto,2),DAcyto,dt,halfwinlen,normrnd(0,1,nA_RWc,1));
   B(B_RWcyto,1) = calcPos(B(B_RWcyto,1),DBcyto,dt,halfwinlen,normrnd(0,1,nB_RWc,1));
   B(B_RWcyto,2) = calcPos(B(B_RWcyto,2),DBcyto,dt,halfwinlen,normrnd(0,1,nB_RWc,1));
   
   
   % Resolve reaction states --------------------------------------------
   A(bool_Aidx_revrxn,3) = 0;
   B(bool_Bidx_revrxn,3) = 0;
   
   A(bool_Aoff2on,4) = 1;
   A(bool_Aon2off,4) = 0;
   B(bool_Boff2on,4) = 1;
   B(bool_Bon2off,4) = 0;
   
   if ~isempty(AidxBidx_fwdrxn)
   A(AidxBidx_fwdrxn(:,1),3) = AidxBidx_fwdrxn(:,2);
   B(AidxBidx_fwdrxn(:,2),3) = AidxBidx_fwdrxn(:,1);
   end
end
time_whole = toc

% Export data.
[outfile,todays_date]=SetFolderbyDate(filebasename);
fprintf('Ended simulation, saving to %s\n',outfile);

% Create the appropriate folder for the sim.
if ~exist(todays_date,'dir')
    mkdir(todays_date);
end

% Save .mat files
data_mat = strcat(outfile,'_dat.mat');

% Check size of CoordTracker to specify correct MATLAB save style.
data_metadata = whos('CoordTracker');
if data_metadata.bytes > 1e9 
    save(data_mat,'CoordTracker','-v7.3');
else
    save(data_mat,'CoordTracker');
end
clear CoordTracker;
output_mat = strcat(outfile,'_par.mat');
save(output_mat);

end

% Function to establish data structures.
function [outfile,todays_date]=SetFolderbyDate(filebasename)
if ispc
    todays_date = num2str(yyyymmdd(datetime)); % folder
    todays_date = strcat(todays_date,'\');
    outfile     = strcat(todays_date,'\',filebasename);
elseif ismac
    todays_date = num2str(yyyymmdd(datetime)); % folder
    todays_date = strcat(todays_date,'/');
    outfile     = strcat(todays_date,'/',filebasename);
elseif isunix
    % Minor difference from actual dirs in the *nix format..
    % pc and mac give YYYYMMDD
    % *nix gives YYYY_M_D, where M and D can have 1 or 2 digits. Added
    % underscores for clarity; just note you cannot integrate
    % *nix names directly with pc or mac names if automating analysis
    mytime=clock;
    mytime=mytime(1:3); % get YYYYMD only
    todays_date=strrep(regexprep(num2str(fix(mytime)),' +',' '),' ','_');
    todays_date = strcat(todays_date,'/');
    outfile     = strcat(todays_date,'/',filebasename);
end
end



function [AidxBidx] = GetRxnMat(A,B,pr,rad,halfwinlen)
bool_freeA = ~logical(A(:,3)) & logical(A(:,4)); % Must have no molecule bound, must be in membrane
bool_freeB = ~logical(B(:,3)) & logical(B(:,4));
% Obtain matrix which only contains entries from free A/B.
sqdists = sqEuclTorus_mex(A(bool_freeA,1:2),B(bool_freeB,1:2),2*halfwinlen);
reactionMat = false(size(sqdists));
filterMat = sqdists < rad^2;
% Assign random numbers ~Unif(0,1) for each 'true' in filterMat
reactionMat(filterMat) = rand(sum(sum(filterMat)),1) < pr;
[Aidx,Bidx]=find(reactionMat); % Reactives, but in 'free A/B' indices
if ~isempty(Aidx)
    translator_A = find(bool_freeA); % Need to translate from free A/B indices
    translator_B = find(bool_freeB);
    AidxBidx = zeros(length(Aidx),2);
    AidxBidx(:,1) = translator_A(Aidx); % Convert to 'raw' A/B indices.
    AidxBidx(:,2) = translator_B(Bidx);
    % Remove duplicated indices; avoid assigning one reactant to two parnters
    [~,iduA]=unique(AidxBidx(:,1));
    [~,iduB]=unique(AidxBidx(:,2));
    AidxBidx=AidxBidx(intersect(iduA,iduB),:);
else
    AidxBidx=[];
end
end

% General function for obtaining logical indices for a first order rxn
function [flags] = GetRxnFirstOrder(bool_targets,p_rxn)
flags = bool_targets; % Copy the vector, as we do not intend to alter the input.
nrxns = sum(bool_targets);
flags(flags)=rand(nrxns,1) < p_rxn; % Store successful reactions at valid indices
end

function [posxy]=calcPos_dissoc(posxy,xwin,sigma)
% Nx2 vector format for posxy
% xwin, ywin are the half-win len
% sigma is the separation distance
[n,~]=size(posxy);
randTheta = rand(n,1)*2*pi; 

posxy(:,1) = posxy(:,1) + sigma*cos(randTheta);
posxy(:,2) = posxy(:,2) + sigma*sin(randTheta);
posxy=adjustForBounds(posxy,xwin);
end

% Function to perform a diffusion step
function [newPos] = calcPos(pos, D, dt, bound, z)
% The position function is updated (symetrically for x and y)
% as x(t+dt)=x(t)+sqrt(2D*dt)Z_i
% where
% x is a vector of coordinates (x1 = x, x2 = y)
% t is time
% dt is the timestep
% D is a 1xN vector of diffusion coefficients for all particles.
% Z_i is an vector of Gaussian random variable, mean=0, stdev=1

delta=sqrt(2*D*dt).*z;
newPos=pos+delta;

newPos=adjustForBounds(newPos,bound); 

end

% Function to adjust the input coordinates for the boundary conditions.
% Can use as oldXY == newXY to see if a change occurs
function [pos] = adjustForBounds(pos, bound)

% PERIODIC BOUNDARIES MODE FOR VECTOR pos
timesExceeded=floor((abs(pos)+bound)/(2*bound));
pos = pos -sign(pos)* 2*bound.*timesExceeded;

end

