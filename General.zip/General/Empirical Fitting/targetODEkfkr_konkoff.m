function dy = targetODEkfkr_konkoff(t,y,kf,kr,konA,koffA,konB,koffB,Ar)
% Values of A,B,C here are in particles
% Amemb Acyto Bmemb Bcyto Cmemb
% kf here is in um^2/s
% Ar (domain area) is in um2

dy=zeros(5,1);
% Am
dy(1) = -kf/Ar*y(1)*y(3) + kr*y(5) - koffA*y(1) + konA*y(2);

% Ac
dy(2) = -konA*y(2) + koffA*y(1);

% Bm
dy(3) = -kf/Ar*y(1)*y(3) + kr*y(5) - koffB*y(3) + konB*y(4);

% Bc
dy(4) = -konB*y(4) + koffB*y(3);

% C
dy(5) =  kf/Ar*y(1)*y(3) - kr*y(5);

end
