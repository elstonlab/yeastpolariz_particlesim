function SSE = objectiveFnkfkr_konkoff(data_t,data_x,p,konA,koffA,konB,koffB,area,x0)
    %p(1) = kf
    %p(2) = kr
    penalty = 1;

    if any(p<0)
        penalty = penalty*1e50; % big penalty to negative values
        p(p<0) = 0; % zero out, since ODE may error.
        disp('Warning, attempted to use negative parameters during objective fit');
    end

    f = @(t,x) targetODEkfkr_konkoff(t,x,p(1),p(2),konA,koffA,konB,koffB,area);
    [~,pred_x] = ode45(f,data_t,x0);

    % Normalize to avoid bias to a single species
    datamaxes=max(data_x);
    
    for i=1:5
        if datamaxes(i) ~= 0
            pred_x(:,i) = pred_x(:,i)/datamaxes(i);
            data_x(:,i) = data_x(:,i)/datamaxes(i);
        else
            assert(isempty(find(pred_x(:,i),1)),'Data has maximum zero, but predicted non-zero value');
        end
    end
    err = data_x - pred_x;
    SSE = sum(sum(err.^2)) * penalty;
end
