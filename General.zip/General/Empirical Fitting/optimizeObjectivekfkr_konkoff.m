function optimizeObjectivekfkr_konkoff(filedat,filepar)
% Takes the file locations of the data file (filedat) and parameter file (filepar)
% for the target particle simulation. Fits a kf (and kr, if relevant) to the data,
% using a system of ODEs that accounting for membrane on/off rates as needed.
disp('Loading and normalizing data');

loadfiledat=load(filedat);
loadfilepar=load(filepar);

% Initial conditions, as concentrations
area = (loadfilepar.halfwinlen*2)^2;

Am_0 = sum( logical(loadfiledat.CoordTracker.A(1,:,4)) & ~logical(loadfiledat.CoordTracker.A(1,:,3))); % Non-complexed membrane species
Ac_0 = sum(~logical(loadfiledat.CoordTracker.A(1,:,4)) & ~logical(loadfiledat.CoordTracker.A(1,:,3))); % Non-complexed cytoplasmic species
Bm_0 = sum( logical(loadfiledat.CoordTracker.B(1,:,4)) & ~logical(loadfiledat.CoordTracker.B(1,:,3))); % Non-complexed membrane species
Bc_0 = sum(~logical(loadfiledat.CoordTracker.B(1,:,4)) & ~logical(loadfiledat.CoordTracker.B(1,:,3))); % Non-complexed cytoplasmic species
C_0  = sum( logical(loadfiledat.CoordTracker.A(1,:,3))); % Complexed species.

x0 = [Am_0 Ac_0 Bm_0 Bc_0 C_0];

% Timecourse data
Am_tc = zeros(loadfilepar.outputsteps,1);
Ac_tc = zeros(loadfilepar.outputsteps,1);
Bm_tc = zeros(loadfilepar.outputsteps,1);
Bc_tc = zeros(loadfilepar.outputsteps,1);
C_tc  = zeros(loadfilepar.outputsteps,1);

for i=1:loadfilepar.outputsteps
    Am_tc(i) = sum(~logical(loadfiledat.CoordTracker.A(i,:,3)) &  logical(loadfiledat.CoordTracker.A(i,:,4)));
    Ac_tc(i) = sum(~logical(loadfiledat.CoordTracker.A(i,:,3)) & ~logical(loadfiledat.CoordTracker.A(i,:,4)));
    Bm_tc(i) = sum(~logical(loadfiledat.CoordTracker.B(i,:,3)) &  logical(loadfiledat.CoordTracker.B(i,:,4)));  
    Bc_tc(i) = sum(~logical(loadfiledat.CoordTracker.B(i,:,3)) & ~logical(loadfiledat.CoordTracker.B(i,:,4)));
    C_tc(i)  = sum( logical(loadfiledat.CoordTracker.A(i,:,3))); 
end

% Concentrations
data_x = horzcat(Am_tc,Ac_tc,Bm_tc,Bc_tc,C_tc); 
data_t = loadfiledat.CoordTracker.time;

% Get the target parameters.
ktarg = loadfilepar.kf;
liters_per_cubic_meters = 10^3;
microns_per_meter = 10^6;
moles_per_umol = 10^-6;
Nav = 6.02 * 10^23;
membThickness = 0.0083; % um
% Assuming ktarg is in units of 1/uM*s and converting to um^3/s
ktarg=ktarg * microns_per_meter^3 / (liters_per_cubic_meters * moles_per_umol) / Nav;
% Converting now from um^3/s to um^2/s, adjusting it to a 2D rate constant
ktarg=ktarg / membThickness;

disp('Loading and normalizing done. Beginning optimization with fminsearch');

guessparams = [ktarg, loadfilepar.kr];
fprintf('Guess parameters:\nkf %g (um^2/s)\nkr %g (1/s)\n',guessparams);

options = optimset('PlotFcns',@optimplotfval);%,'Display','Iter');
if loadfilepar.kr ~= 0
[psolve,fval,exitflag,output]=fminsearch(@(p) objectiveFnkfkr_konkoff(data_t,data_x,p,...
                                         loadfilepar.konA,loadfilepar.koffA,...
                                         loadfilepar.konB,loadfilepar.koffB,area,x0),guessparams,options);

disp('Completed optimization, computing realized optimization');
[opt_t,opt_y]=ode45(@(t,y) targetODEkfkr_konkoff(t,y,psolve(1),psolve(2),...
                                                 loadfilepar.konA,loadfilepar.koffA,...
                                                 loadfilepar.konB,loadfilepar.koffB,area),[0 max(data_t)],x0);

                                             
else
[psolve,fval,exitflag,output]=fminsearch(@(p) objectiveFnkfonly_konkoff(data_t,data_x,p,...
                                        loadfilepar.konA,loadfilepar.koffA,...
                                        loadfilepar.konB,loadfilepar.koffB,area,x0),guessparams(1),options);
disp('Completed optimization, computing realized optimization');
[opt_t,opt_y]=ode45(@(t,y) targetODEkfkr_konkoff(t,y,psolve(1),0,...
                                                loadfilepar.konA,loadfilepar.koffA,...
                                                loadfilepar.konB,loadfilepar.koffB,area),[0 max(data_t)],x0);
end
    
figure;
plotinterval=1:3:length(opt_t);
colororder=get(gca,'colororder');
hold on;
plot(data_t,data_x(:,1)+data_x(:,2),'color',colororder(1,:),'linewidth',4);
plot(data_t,data_x(:,3)+data_x(:,4),'color',colororder(2,:),'linewidth',4);
plot(data_t,data_x(:,5),'color',colororder(3,:),'linewidth',4);
plot(opt_t(plotinterval),opt_y(plotinterval,1)+opt_y(plotinterval,2),'color','black','linewidth',1,'marker','o','markeredgecolor',colororder(1,:),'markerfacecolor','white','markersize',6);
plot(opt_t(plotinterval),opt_y(plotinterval,3)+opt_y(plotinterval,4),'color','black','linewidth',1,'marker','o','markeredgecolor',colororder(2,:),'markerfacecolor','white','markersize',6);
plot(opt_t(plotinterval),opt_y(plotinterval,5),'color','black','linewidth',1,'marker','o','markeredgecolor',colororder(3,:),'markerfacecolor','white','markersize',6);
xlabel('Time (s)');
ylabel('Molecules');
set(gca,'xlim',[0 1]);
legend('PB-A','PB-B','PB-C','Fit-A','Fit-B','Fit-C','location','northeast');
set(gca,'fontsize',16);
