% "quasi3D" RDEs; applied the reservoir-based injection-ejection method
% used for PB sims. instead of poisson sampling and injecting to a random coordinate,
% use the local concentration at each pixel vs. the shared reservoir.
function RDE_q3D(Bem1_tot,Cdc42_tot,k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7,...
                 output_basename,xwin,dt,interval,pdeinitFile)
% INPUTS ====================================
% Bem1_tot (particle #)
% Cdc42_tot (particle #)
% k1a (s-1)      BemGEFc           -> BemGEF
% k1b (s-1)      BemGEF            -> BemGEFc
% k2a (uM-1.s-1) BemGEF + Cdc42D   -> Cdc42T
% k2b (s-1)      Cdc42T            -> Cdc42D
% k3  (uM-1.s-1) Cdc42D + GEF42    -> Cdc42T
% k4a (uM-1.s-1) GEF + Cdc42T      -> GEF42
% k4b (s-1)      GEF42             -> GEF + Cdc42T
% k5a (s-1)      Cdc42Dc           -> Cdc42Dm
% k5b (s-1)      Cdc42Dm           -> Cdc42Dc
% k7  (uM-1.s-1) GEFc + Cdc42T     -> GEF42
% output_basename: filename
% xwin: half the domain length.
% dt: diffusion timestep [s-1].

tic;
%% Set parameters
N = 100;   % number of spatial grid points
Dmemb = 0.0025;      % membrane diffusion coefficient
Dcyto = 15;          % cytoplasmic diffusion coefficient
membThickness = 0.0083; % Implicit simulation thickness.

%% Calculate 2D rate constants and 2D concentrations.
k2a = convert3DRateConst(k2a,membThickness);
k3  = convert3DRateConst(k3 ,membThickness);
k4a = convert3DRateConst(k4a,membThickness);
k7  = convert3DRateConst(k7 ,membThickness);
Bem1_tot = Bem1_tot / (xwin*2)^2;
Cdc42_tot = Cdc42_tot / (xwin*2)^2;
fprintf('Initializing simulation with %g Bem1GEF (particles/um^2), %g Cdc42 (particles/um^2)\n',...
        Bem1_tot,Cdc42_tot);
fprintf('rate constants:\n k1a\t%g\nk1b\t%g\nk2a\t%g\nk2b\t%g\nk3\t%g\nk4a\t%g\nk4b\t%g\nk5a\t%g\nk5b\t%g\nk7\t%g\n',...
        k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7);
fprintf('All rate constants are in units of s^-1 and um^2.s^-1\n');

%% Initial state options
% Option 1: For numerical bifurcation determination; starts system with strong polarized state
% Option 3: Load from pdeinit file
% Option 6: Load everything homogeneously in the explicit/reservoir cytoplasm
%           and turn off all reactions: debug mode for injection/ejection.
option = 3;

reactionsEnabled = true; % Default state.

%% Output base name
[~,todays_date]=SetFolderbyDate(output_basename);
dir_prefix = todays_date;
fullfilename = strcat(dir_prefix,output_basename);
% Create the appropriate folder for the sim.
if ~exist(dir_prefix,'dir')
    mkdir(dir_prefix);
end

%%
% storage files
RT_tc   = zeros((interval+1)*N, N);
M_tc    = zeros((interval+1)*N, N);
Em_tc   = zeros((interval+1)*N, N);
Ec_tc   = zeros((interval+1)*N, N);
Ec_res_tc = zeros(interval+1,1); % Reservoir cytoplas
RD_tc   = zeros((interval+1)*N, N);
RDc_tc  = zeros((interval+1)*N, N);
RDc_res_tc = zeros(interval+1,1); % Reservoir cytoplasm

Rtot_tc = zeros(interval+1, 1);
Etot_tc = zeros(interval+1, 1);

% variables for time-stepping
maxt = interval/dt;  % number of time-steps in interval

% variables for spatial discretization
%dx  = Cellsize*sqrt(pi)/N;          % spatial meshsize (1D)
L = xwin*2; % spatial length along 1 axis


curr_t  = 0;          % keeps track of current time
nRsteps = 10;        % defines the initial reaction time-step (dt2)
dt2     = dt/nRsteps; % reaction time-step

%added diffusion parameters based on Meng Jin's model -Lior
wx2=2*pi/L*[0:N/2 -N/2+1:-1];
wy2=2*pi/L*[0:N/2 -N/2+1:-1];
[Fx, Fy]=meshgrid(wx2,wy2);
Flk=Fx.^2+Fy.^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pre-calculate the injection/ejection tables.
% Since the concentration values are continuous, we can either calculate an exact answer
% for every diffusive timestep (no tables), or we can satisfy ourselves with computing 
% these tables to a specified tolerance. We choose the pre-calculated tables and use a tolerance
% of 1 molecule.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Use functions in particle # rather than particles/um2 to stay
% consistent with PB implementation. Last argument is tolerance value.
%% -------------------------------------
d_cell = 5; % um
[nGEF_inj,nGEF_inj_prev]     =  calc_injection(d_cell,dt,Dcyto,membThickness,Bem1_tot*(xwin*2)^2,1);
[nGEF_ejc,nGEF_ejc_prev]     =   calc_ejection(d_cell,dt,Dcyto,membThickness,Bem1_tot*(xwin*2)^2,1);
[nCdc42_inj,nCdc42_inj_prev] =  calc_injection(d_cell,dt,Dcyto,membThickness,Cdc42_tot*(xwin*2)^2,1);
[nCdc42_ejc,nCdc42_ejc_prev] =   calc_ejection(d_cell,dt,Dcyto,membThickness,Cdc42_tot*(xwin*2)^2,1);


%% Initial condition
% With the first two options, using concentration spikes give rise to peaks
switch option
    case 1
        %error('Spectral RDE with injection/ejection not implemented for initialization option 1.')
        warning('Using option 1 for spectral RDE injection/ejection -- not rigorously tested')
        Y0 = zeros(6,1);
        Y0(4) = Bem1_tot;  % BemGEFc
        Y0(6) = Cdc42_tot; % Cdc42Dc
             
        Cdc42T0   = Y0(1);
        BemGEF420 = Y0(2);
        BemGEF0   = Y0(3);
        BemGEFc0  = Y0(4);
        Cdc42D0   = Y0(5);
        Cdc42Dc0  = Y0(6);
        
        Cdc42spike = 0.9 .* Cdc42Dc0; % The spike at a single spatial point

        if Cdc42spike ~= 0
            disp('Non-zero initial Cdc42-T spike from pure cyto init')
        end
        
        Cdc42T   = Cdc42T0   .*ones(N);
        
        
        Cdc42T(40:60, 40:60) = Cdc42T0 + Cdc42spike;
        BemGEF42 = BemGEF420 .*ones(N);
        BemGEF   = BemGEF0   .*ones(N); 
        BemGEFc  = BemGEFc0  .*ones(N)/N^2 .* 0.01;
        % BemGEFc_res = something
        Cdc42D   = Cdc42D0   .*ones(N);
        Cdc42Dc  = Cdc42Dc0  .*ones(N)/N^2 .* 0.01;
        % Cdc42Dc_res = something
        Cdc42D(40:60, 40:60) = Cdc42D(40:60, 40:60) - Cdc42spike;
        nBemGEFc_res = BemGEFc0  .* (2*xwin)^2 * 0.99;
        nCdc42Dc_res = Cdc42Dc0  .* (2*xwin)^2 * 0.99;
    case 3
        %Y0 = zeros(6,1);             
        load(pdeinitFile);
        
        % The *_pdeinit files are based on fractional particle number.
        % The _tot variables are in particles/um^2
        
        % In this implementation, m/c have same "volume", so no rescaling.
        % The reservoir has 49x greater "volume" than the m+c. BUT
        % we want to use absolute particle numbers to be compatible with the lookup tables.
        
        Cdc42T   = Cdc42_tot    .* Cdc42T_pdeinit;
        BemGEF42 = Cdc42_tot    .* GEF42_pdeinit;
        BemGEF   = Bem1_tot     .* GEFm_pdeinit;
        BemGEFc  = Bem1_tot     .* GEFc_pdeinit;;
        
        nBemGEFc_res = Bem1_tot  * nGEFc_res_pdeinit .*(xwin*2)^2; 
        Cdc42D   = Cdc42_tot    .* Cdc42Dm_pdeinit;
        Cdc42Dc  = Cdc42_tot    .* Cdc42Dc_pdeinit;
        nCdc42Dc_res = Cdc42_tot * nCdc42Dc_res_pdeinit .*(xwin*2)^2;
    case 6
        disp('Putting everything in the cytoplasm, checking mean partitioning')
        Cdc42T = zeros(N);
        Cdc42D = zeros(N);
        Cdc42Dc = Cdc42_tot.*ones(N);
        BemGEF42 = zeros(N);
        BemGEF = zeros(N);
        BemGEFc = Bem1_tot.*ones(N);
        nBemGEFc_res = 0;
        nCdc42Dc_res = 0;
        reactionsEnabled = false;
end

% print initial conditions into file
RT_tc(1:N,:)   = Cdc42T;
M_tc(1:N,:)    = BemGEF42;
Em_tc(1:N,:)   = BemGEF;
Ec_tc(1:N,:)   = BemGEFc;
nEc_res_tc(1) = nBemGEFc_res;
RD_tc(1:N,:)   = Cdc42D;
RDc_tc(1:N,:)  = Cdc42Dc;
nRDc_res_tc(1) = nCdc42Dc_res;

% calculate mass balance based on particle
Rtot_tc(1) = ((sum(sum(Cdc42Dc+Cdc42T + Cdc42D + BemGEF42)))).*(xwin*2)^2 + nCdc42Dc_res;
Etot_tc(1) = (sum(sum(BemGEFc+BemGEF42 + BemGEF))).*(xwin*2)^2 + nBemGEFc_res;
 
% print progress scale bar
fprintf('Total simulation time: %d seconds\n\n', interval);
fprintf('0            25          50           75         100 (percent) \n');
fprintf('|------------|-----------|------------|-----------|\n');
  
%% 
progress = 1;
      
if ~reactionsEnabled
    warning('Reactions are turned off. Did you mean to set this option?')
end


for t0=1:1:maxt                   
    curr_t = curr_t+dt;           % update clock    

    if reactionsEnabled

    lp = 0;
    react_t = 0;
    et = 0.0001;

    while  lp ~= 2
        % Reservoir has no effect on rxns
        [Cdc42Th, BemGEF42h, BemGEFh, BemGEFch, Cdc42Dh, Cdc42Dch] = Euler_step(Cdc42T, BemGEF42, BemGEF, BemGEFc, Cdc42D, Cdc42Dc, dt2,...
                                                                                k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7);
        [Cdc42Th2, BemGEF42h2, BemGEFh2, BemGEFch2, Cdc42Dh2, Cdc42Dch2] = Euler_step(Cdc42T, BemGEF42, BemGEF, BemGEFc, Cdc42D, Cdc42Dc, dt2/2,...
                                                                                k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7);
        [Cdc42Th2, BemGEF42h2, BemGEFh2, BemGEFch2, Cdc42Dh2, Cdc42Dch2] = Euler_step(Cdc42Th2, BemGEF42h2, BemGEFh2, BemGEFch2, Cdc42Dh2, Cdc42Dch2, dt2/2,...
                                                                                k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7);
     
        % error checking
        Cdc42Te    = max(max(abs(Cdc42Th   - Cdc42Th2   )));
        BemGEF42e  = max(max(abs(BemGEF42h - BemGEF42h2 )));
        BemGEFe    = max(max(abs(BemGEFh   - BemGEFh2   )));
        BemGEFce    = max(max(abs(BemGEFch   - BemGEFch2   )));
        Cdc42De    = max(max(abs(Cdc42Dh   - Cdc42Dh2   )));
        Cdc42Dce    = max(max(abs(Cdc42Dch   - Cdc42Dch2   )));
        
        r = max([Cdc42Te,BemGEF42e,BemGEFe,BemGEFce,Cdc42De,Cdc42Dce]);
        
        % doing the step again with different stepsize        
        if r > et && lp == 0
            dt2 = dt2/1.5;     
            
        % moving on
        else
            Cdc42T    = Cdc42Th2;
            BemGEF42  = BemGEF42h2;
            BemGEF    = BemGEFh2;
            BemGEFc   = BemGEFch2;
            Cdc42D    = Cdc42Dh2;
            Cdc42Dc   = Cdc42Dch2;
            
            % adding the step on 
            react_t = react_t + dt2;
            % setting new stepsize for next step
            dt2 = 1.5*dt2;
            
            if lp == 1
                lp = 2;
            end
        end   
        % Making sure we stay within the dt interval
        if react_t + dt2 > dt && lp ~= 2
            dt2 = dt - react_t;
            lp = 1; 
        end            
    end
    
    
    % Reservoir is assumed perfectly mixed, and does not change during Euler step
    % so no need to update
    Cdc42T_ff   = fft2(Cdc42T);
    Cdc42T_nn = Cdc42T_ff.* exp(-dt*Flk*Dmemb); 
    Cdc42T = real(ifft2(Cdc42T_nn));
    
    Cdc42D_ff   = fft2(Cdc42D);
    Cdc42D_nn = Cdc42D_ff.* exp(-dt*Flk*Dmemb); 
    Cdc42D = real(ifft2(Cdc42D_nn));
    
    BemGEF42_ff   = fft2(BemGEF42);
    BemGEF42_nn = BemGEF42_ff.* exp(-dt*Flk*Dmemb); 
    BemGEF42 = real(ifft2(BemGEF42_nn));
    
    BemGEF_ff   = fft2(BemGEF);
    BemGEF_nn = BemGEF_ff.* exp(-dt*Flk*Dmemb); 
    BemGEF = real(ifft2(BemGEF_nn));

    Cdc42Dc_ff = fft2(Cdc42Dc);
    Cdc42Dc_nn = Cdc42Dc_ff .* exp(-dt*Flk*Dcyto);
    Cdc42Dc = real(ifft2(Cdc42Dc_nn));
    
    BemGEFc_ff = fft2(BemGEFc);
    BemGEFc_nn = BemGEFc_ff .* exp(-dt*Flk*Dcyto);
    BemGEFc = real(ifft2(BemGEFc_nn));
    
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Apply injection/ejection INDEPENDENTLY for each pixel
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Search tables for injection/ejection using TOTAL amounts, then re-scale to release appropriate fraction from each pixel.
    % GEF to inject from the reservoir.
    [~,targ_GEF_inj_index] = min(abs(nGEF_inj_prev - nBemGEFc_res));
    
    % GEF to eject from the explicit cytoplasm
    [~,targ_GEF_ejc_index] = min(abs(nGEF_ejc_prev - sum(BemGEFc(:))*(2*xwin)^2/N^2));
    
    % Cdc42 to inject from the reservoir.
    [~,targ_Cdc42_inj_index] = min(abs(nCdc42_inj_prev - nCdc42Dc_res));
    
    % Cdc42 to eject
    [~,targ_Cdc42_ejc_index] = min(abs(nCdc42_ejc_prev - sum(Cdc42Dc(:))*(2*xwin)^2/N^2));
    
    % Get probability scaling so we know how to divide the ejection mass
    pr_GEFc    = BemGEFc./sum(BemGEFc(:));
    pr_Cdc42Dc = Cdc42Dc./sum(Cdc42Dc(:));
    
    mean_next_GEF_inj   = nGEF_inj(targ_GEF_inj_index).*ones(N);
    mean_next_GEF_ejc   = nGEF_ejc(targ_GEF_ejc_index).*pr_GEFc*N^2; % each pixel should be scaled [0,1] instead of [0,N^(-2)]
    mean_next_Cdc42_inj = nCdc42_inj(targ_Cdc42_inj_index).*ones(N);
    mean_next_Cdc42_ejc = nCdc42_ejc(targ_Cdc42_ejc_index).*pr_Cdc42Dc*N^2;
        
    % Injection/ejection.
    BemGEFc      = BemGEFc      + (-mean_next_GEF_ejc + mean_next_GEF_inj) / (2*xwin)^2;
    nBemGEFc_res = mean(mean(nBemGEFc_res +   mean_next_GEF_ejc - mean_next_GEF_inj));
    
    Cdc42Dc      = Cdc42Dc      + (-mean_next_Cdc42_ejc + mean_next_Cdc42_inj) / (2*xwin)^2; 
    nCdc42Dc_res = mean(mean(nCdc42Dc_res +   mean_next_Cdc42_ejc - mean_next_Cdc42_inj));
    
    %% metadata and saving
    if(t0 >= interval/dt/50*progress)
      fprintf('*');
      progress = progress +1;
    end
    
    % store data every second
    if(t0>=1/dt && mod(t0,1/dt)==0)
        RT_tc((t0*dt*N + 1):(t0*dt + 1)*N ,:)  = Cdc42T;
        M_tc((t0*dt*N + 1):(t0*dt + 1)*N ,:)   = BemGEF42;
        Em_tc((t0*dt*N + 1):(t0*dt + 1)*N ,:)  = BemGEF;
        Ec_tc((t0*dt*N + 1):(t0*dt + 1)*N ,:)  = BemGEFc;
        nEc_res_tc(t0*dt)                      = nBemGEFc_res;
        RD_tc((t0*dt*N + 1):(t0*dt + 1)*N ,:)  = Cdc42D;
        RDc_tc((t0*dt*N + 1):(t0*dt + 1)*N ,:) = Cdc42Dc; 
        nRDc_res_tc(t0*dt)                     = nCdc42Dc_res;
        
        % calculate mass balance
        Rtot_tc(t0*dt) = ((sum(sum(Cdc42Dc))+sum(sum((Cdc42T + Cdc42D + BemGEF42)))))/N^2.*(xwin*2)^2 + nCdc42Dc_res;
        Etot_tc(t0*dt) = (sum(sum(BemGEFc))+sum(sum((BemGEF42 + BemGEF))))/N^2.*(xwin*2)^2 + nBemGEFc_res;
 
    end    

end  

%% ________________________________________________________________________

time_whole = toc

data_mat = strcat(fullfilename,'_tc.mat');
RT_tc  = RT_tc  * (2*xwin)^2; % Convert to particle #s
M_tc   = M_tc   * (2*xwin)^2;
Em_tc  = Em_tc  * (2*xwin)^2;
Ec_tc  = Ec_tc  * (2*xwin)^2;
RD_tc  = RD_tc  * (2*xwin)^2;
RDc_tc = RDc_tc * (2*xwin)^2;
% no need to convert reservoir quantities
save(data_mat, 'RT_tc', 'M_tc', 'Em_tc', 'Ec_tc', 'RD_tc', 'RDc_tc', 'Rtot_tc', 'Etot_tc', 'nEc_res_tc', 'nRDc_res_tc')

clear RT_tc M_tc Em_tc Ec_tc RD_tc RDc_tc Rtot_tc Etot_tc nEc_res_tc nRDc_res_tc;

output_mat = strcat(fullfilename, '.mat');
save(output_mat);

end


function dy = steady_state_ode(t,y,k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7)
eta = 1; % No volume rescaling here.

%%      
dy = zeros(6,1);

% RT      (Cdc42T)
dy(1) =  ((k2a.*y(3)  +k3.*y(2)  ).*y(5) - k2b.*y(1)  - k4a.*y(3).*y(1) + k4b.*y(2) - k7.*y(4).*y(1));   

% M       (BemGEF42)
dy(2) = (k4a*y(3).*y(1) - k4b*y(2) + k7*y(4).*y(1));
         
% Em      (BemGEF)
dy(3) = (k1a.*y(4) - k1b.*y(3) - k4a.*y(3).*y(1) + k4b.*y(2));

% Ec      (BemGEFc)
dy(4) = (eta.*(k1b.*y(3) - (k1a+k7.*y(1)).*y(4)));

% RD      (Cdc42D)
dy(5) = (k2b.*y(1)  - (k2a.*y(3) +k3.*y(2) ).*y(5) - k5b.*y(5) + k5a.*y(6));

% RDc     (Cdc42Dc)
dy(6) = (eta.*(k5b.*y(5) - k5a.*y(6)));

end

% Euler_step



function [cdc42t, bemgef42, bemgef, bemgefc, cdc42d, cdc42dc] = ... 
    Euler_step(Cdc42T, BemGEF42, BemGEF, BemGEFc, Cdc42D, Cdc42Dc, h,...
               k1a,k1b,k2a,k2b,k3,k4a,k4b,k5a,k5b,k7)


cdc42t   = Cdc42T   + h*((k2a *BemGEF +k3 *BemGEF42 ).*Cdc42D - k2b*Cdc42T  - k4a*BemGEF.*Cdc42T  + k4b*BemGEF42  - k7*BemGEFc.*Cdc42T );   
                
bemgef42 = BemGEF42 + h*(k4a*BemGEF.*Cdc42T - k4b*BemGEF42 + k7*BemGEFc.*Cdc42T);   
                  
bemgef   = BemGEF   + h*(k1a*BemGEFc - k1b*BemGEF - k4a*BemGEF.*Cdc42T + k4b*BemGEF42);

         
bemgefc  = BemGEFc  + h*(k1b*BemGEF - (k1a+k7*Cdc42T).*BemGEFc);

cdc42d   = Cdc42D   + h*(k2b*Cdc42T  - (k2a *BemGEF +k3 *BemGEF42).*Cdc42D - k5b*Cdc42D + k5a*Cdc42Dc);
                    
cdc42dc  = Cdc42Dc  + h*(k5b*Cdc42D - k5a*Cdc42Dc);

end

% Function to establish data structures.
function [outfile,todays_date]=SetFolderbyDate(filebasename)
if ispc
    todays_date = num2str(yyyymmdd(datetime)); % folder
    todays_date = strcat(todays_date,'\');
    outfile     = strcat(todays_date,'\',filebasename);
elseif ismac
    todays_date = num2str(yyyymmdd(datetime)); % folder
    todays_date = strcat(todays_date,'/');
    outfile     = strcat(todays_date,'/',filebasename);
elseif isunix
    % Minor difference from actual dirs in the *nix format..
    % pc and mac give YYYYMMDD
    % *nix gives YYYY_M_D, where M and D can have 1 or 2 digits. Added
    % underscores for clarity; just note you cannot integrate
    % *nix names directly with pc or mac names if automating analysis
    mytime=clock;
    mytime=mytime(1:3); % get YYYYMD only
    todays_date=strrep(regexprep(num2str(fix(mytime)),' +',' '),' ','_');
    todays_date = strcat(todays_date,'/');
    outfile     = strcat(todays_date,'/',filebasename);
end
end

function [k2d] = convert3DRateConst(k3d,membThickness)
liters_per_cubic_meters = 10^3;
microns_per_meter = 10^6;
micromoles_per_mol = 10^-6;
Nav = 6.02 * 10^23;
% Assuming ktarg is in units of 1/uM*s and converting to um^3/s
k3d=k3d * microns_per_meter^3 / ... 
        (liters_per_cubic_meters * micromoles_per_mol) / Nav;

% Converting now from um^3/s to um^2/s, adjusting it to a 2D rate constant
k2d=k3d / membThickness;
end

function [n_inj_exact,n_inj_depend] = calc_injection(d_cell,dt,D,z_eff,potential_N,depTol)
% d_cell : Cell diameter (um)
%     dt : timestep (s)
%      D : diffusivity (um^2/s)
%  z_eff : effective explicit cytoplasmic depth.
% depTol : the tolerance for the dependent variable.
% Probabilities vary along z, which is the 'depth' of the cell assuming a
% rectangular prism geometry.
% Integrates over all relevant z values, then returns the distribution
% that corresponds to all potential N values (depend)

Vcell = 4/3*pi*(d_cell/2)^3; % um^3
SA = 4*pi*(d_cell/2)^2; % um^2
z_reserv = Vcell/SA - 2*z_eff;

z = linspace(0,Vcell/SA - z_eff*2,10000000); 

n_inj_depend = (0:depTol:potential_N);
n_inj_exact  = n_inj_depend / (z_reserv*SA) * SA * trapz(z,1/2*(erf( ((Vcell/SA-z_eff) - z) / sqrt(4*D*dt)) - erf( ((Vcell/SA-z_eff) - z_eff - z) / sqrt(4*D*dt))));
end

function [n_eject_exact,n_eject_depend] = calc_ejection(d_cell,dt,D,z_eff,potential_N,depTol)
% d_cell : Cell diameter (um)
%     dt : timestep (s)
%      D : diffusivity (um^2/s)
%  z_eff : effective explicit cytoplasmic depth.
% depTol : the tolerance for the dependent variable.
% Probabilities vary along z, which is the 'depth' of the cell assuming a
% rectangular prism geometry.
% Integrates over all relevant z values, then returns the distribution
% that corresponds to all potential N values

Vcell = 4/3*pi*(d_cell/2)^3; % um^3
SA = 4*pi*(d_cell/2)^2; % um^2

z = linspace(Vcell/SA-z_eff-z_eff,Vcell/SA-z_eff,10000000); 

n_eject_depend = (0:depTol:potential_N);
n_eject_exact  = n_eject_depend / (SA*z_eff) * SA * trapz(z,1/2*(erf(z/sqrt(4*D*dt)) - erf( (z + z_eff - (Vcell/SA-z_eff)) / sqrt(4*D*dt))));
end
