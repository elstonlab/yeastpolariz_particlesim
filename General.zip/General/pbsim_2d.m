function pbsim_2d(nGEFm,nGEFc,nCdc42Dm,nCdc42Dc,...
                  nCdc42T,nGEF42,k1a,k1b,k2a,k2b,...
                  k3,k4a,k4b,k5a,k5b,k7,...
                  Dcyto,Dmemb,rho,sigma,xwin,ywin,...
                  dt,nsteps,filebasename,rngseed,datagrain)

tic

% for debugging
DEBUG_POSITION = 0;
DEBUG_CDC42T_COUNT =0;

%% --------------------------
% Initialize file structures
%% --------------------------
[outfile,todays_date]=SetFolderbyDate(filebasename);
fprintf('Initializing 2D polarity simulation, saving to %s with rng %i\n',outfile,rngseed);

rng(rngseed);

% Create the appropriate folder for the sim.
if ~exist(todays_date,'dir')
    mkdir(todays_date);
end


%% ----------------------------------------------------
% Calculate lambdas for bimolecular reactions
%% ----------------------------------------------------
if k2a == 0
    lambda2a = 0;
else
    lambda2a =computeLambda(k2a,rho,sigma,Dmemb,Dmemb);
end
if k3 == 0
    lambda3 = 0;
else
    lambda3   =computeLambda(k3 ,rho,sigma,Dmemb,Dmemb);
end
if k4a == 0
    lambda4a = 0; 
else
    lambda4a  = computeLambda(k4a,rho,sigma,Dmemb,Dmemb);
end
if k7 == 0
    lambda7= 0;
else    
    lambda7   =computeLambda(k7 ,rho,sigma,Dcyto,Dmemb);
end
fprintf(strcat('Reaction probabilities: P(1a)\t%g\n',...
                                       'P(1b)\t%g\n',...
                                       'P(2a)\t%g\n',...
                                       'P(3)\t%g\n',...
                                       'P(4a)\t%g\n',...
                                       'P(4b)\t%g\n',...
                                       'P(5a)\t%g\n',...
                                       'P(5b)\t%g\n',...
                                       'P(7)\t%g \n'),...
                                       1-exp(-k1a*dt),...
                                       1-exp(-k1b*dt),...
                                       lambda2a*dt,...
                                       lambda3*dt,...
                                       lambda4a*dt,...
                                       1-exp(-k4b*dt),...
                                       1-exp(-k5a*dt),...
                                       1-exp(-k5b*dt),...
                                       lambda7*dt);
%% -------------------------------------------
% Initialize matrices. Some conventions below.
% Membrane
%    Memb. bound = 1
%    Cytosolic   = 0
% Bound
%    Refers to the index of the bound partner.
% GXP
%    GDP = 1
%    GTP = 0
% State (for CoordTracker)
%    GEFc    = 1    Cdc42Dc = 4
%    GEFm    = 2    Cdc42Dm = 5
%    GEF42   = 3    Cdc42T  = 6
%% ---------------------------------------------
nGEFtot       = nGEFm+nGEFc+nGEF42;
nCdc42tot     = nCdc42Dm+nCdc42Dc+nCdc42T+nGEF42; 
GEFs          = zeros(nGEFtot,2,4); % #particles x {tn,tn+1} x {xcoord,ycoord,bound,memb}
Cdc42s        = zeros(nCdc42tot,2,5); % #particles x {tn,tn+1} x {xcoord,ycoord,bound,memb,gxp}
GEFs(:,1,1)   = unifrnd(-xwin,xwin,nGEFtot,1); 
GEFs(:,1,2)   = unifrnd(-ywin,ywin,nGEFtot,1); 
Cdc42s(:,1,1) = unifrnd(-xwin,xwin,nCdc42tot,1);
Cdc42s(:,1,2) = unifrnd(-ywin,ywin,nCdc42tot,1);
Cdc42s(:,:,5) = 1; % Set all Cdc42s to begin in GDP bound state.
Cdc42s(:,2,:) = Cdc42s(:,1,:); GEFs(:,2,:) = GEFs(:,1,:); % tn+1 = tn to start

CoordTracker = zeros(ceil(nsteps/datagrain),nGEFtot+nCdc42tot,3); % #frames x #particles # {xcoord,ycoord,state}

%% ---------------------------
%  Begin iterative simulation
%% ---------------------------
for i=1:nsteps
   % Provide user update
   if (mod(i,nsteps/10)) == 0
       fprintf('Completed %g %% of modelling.\n',100*i/nsteps);
   end
   
   %% ---------------------------------------------------------
   % Precalculate some random numbers for commonly called lines.
   %% ---------------------------------------------------------
   r_diffusCdc42x     = RandVec_Diffus(nCdc42tot);
   r_diffusCdc42y     = RandVec_Diffus(nCdc42tot);
   r_diffusGEFx       = RandVec_Diffus(nGEFtot);
   r_diffusGEFy       = RandVec_Diffus(nGEFtot);
   
   % Using Cdc42 as the reference so make the vector sized to it.
   r_diffusGEF42x     = RandVec_Diffus(nCdc42tot);
   r_diffusGEF42y     = RandVec_Diffus(nCdc42tot); 
   r_dissocGEF42      = RandVec_Dissoc(nCdc42tot); 
   
   r_membAssocCdc42  = RandVec_MembAssoc(nCdc42tot);
   r_membAssocGEF    = RandVec_MembAssoc(nGEFtot);
   r_membDissocCdc42 = RandVec_MembDissoc(nCdc42tot);
   r_membDissocGEF   = RandVec_MembDissoc(nGEFtot);
   
   r_hydrolCdc42     = RandVec_Hydrol(nCdc42tot);
   
   [s_colMat,s_colMat_idx]=getSortedCollisionMatrix(Cdc42s,GEFs,rho,xwin,ywin);
   
   %% ---------------------------------------------------------
   % Check binding reactions. 
   % Position is not updated here - set flags that will control
   % binding-dependent position updates during the diffusion update.
   % The first molecule in the argument is the reference particle.
   % The membrane update for GEFs is provided later.
   %% ---------------------------------------------------------
   
   % lambda4a: GEFm + Cdc42T -> GEF42
   % lambda7 : GEFc + Cdc42T -> GEF42
   % Flags are value indices, not logical indices.
   if lambda4a~=0 || lambda7~=0
   [reactFlagCdc42,reactFlagGEF]=getReactionList(s_colMat,s_colMat_idx,...
                                                Cdc42s,GEFs,lambda4a,...
                                                lambda7,dt);
   else
       reactFlagCdc42=[]; reactFlagGEF=[];
   end
   % Set binding state to the index value for associating molecules.
   Cdc42s(reactFlagCdc42(:),2,3) = reactFlagGEF(:);
   GEFs  (reactFlagGEF(:)  ,2,3) = reactFlagCdc42(:);
   
   %% ---------------------------------------------------------
   % Check dissociation reactions. Does not permit newly-bound particles to
   % dissociate. Position is not updated here - set flags that will control
   % binding-dependent position updates during the diffusion update.
   %% ---------------------------------------------------------
   
   % Flags are logical indices.
   % Molecules without binding partners at the current step are ignored.
   [dissocFlagCdc42,dissocFlagGEF]=getDissocList(Cdc42s,nGEFtot,k4b,dt,r_dissocGEF42);
   % Set binding state to zero for dissociated molecules.
   Cdc42s(dissocFlagCdc42,2,3) = 0;
   GEFs  (dissocFlagGEF  ,2,3) = 0;

   %% ---------------------------------------------------------
   % Check nucleotide exchange reactions (GEF catalyzed).
   % Only GDP->GTP or GTP->GDP can occur in a single timestep; no
   % flip-flopping is allowed. While GEFs may attempt catalysis multiple
   % times per timestep, they can only succeed once.
   %% ---------------------------------------------------------
   
   % lambda2a = Cdc42Dm + GEFm  -> Cdc42T
   % lambda3  = Cdc42Dm + GEF42 -> Cdc42T
   % Flags are logical indices.
   if lambda2a~=0 || lambda3 ~=0
   [exchangeFlagCdc42T] = getExchangeList(s_colMat,s_colMat_idx,Cdc42s,...
                                          GEFs,lambda2a,lambda3,dt);
   else
       exchangeFlagCdc42T=[];
   end
   Cdc42s(exchangeFlagCdc42T(:),2,5) = 0;
   
   %% ---------------------------------------------------------
   % GTP hydrolysis reactions (implicit GAPs). Enforces that new GDP
   % remain membrane bound later in the simulation (in a single timestep,
   % Cdc42T->Cdc42Dm->Cdc42Dc could not occur).
   % Assumes GEF42 complexes cannot directly hydrolyze
   %% ---------------------------------------------------------
   
   % Logical indexing.
   [hydrolysisFlagCdc42] = getHydrolList(Cdc42s,k2b,dt,r_hydrolCdc42);
   Cdc42s(hydrolysisFlagCdc42,2,5) = 1;
   
   %% ---------------------------------------------------------
   % Check membrane interactions. Assumes GEF42 complexes cannot become
   % cytosolic, and that Cdc42-GTP must be membrane bound.
   % This forbids Cdc42T -> Cdc42Dc in a single timestep.
   % Membrane association/dissociation flags require the Cdc42 to have been
   % in the GDP state before and after. 
   %% ---------------------------------------------------------
   
   % Flag is logical indices.
   [membAssocFlagCdc42]  = logical(getCdc42MembraneAssocList (Cdc42s,k5a,dt,r_membAssocCdc42));
   [membAssocFlagGEF]    = logical(getGEFMembraneAssocList   (GEFs  ,k1a,dt,r_membAssocGEF));
   [membDissocFlagCdc42] = logical(getCdc42MembraneDissocList(Cdc42s,k5b,dt,r_membDissocCdc42));
   [membDissocFlagGEF]   = logical(getGEFMembraneDissocList  (GEFs  ,k1b,dt,r_membDissocGEF));
      
   % Set dissociation flag to zero if a GEF42 in the next timestep.
   % Set association  flag to one  if a GEF42 in the next timestep.
   % Distinct from newly-reacted particles.
   isGEF42_Cdc42idx    = logical(Cdc42s(:,2,3));
   isGEF42_GEFidx      = logical(GEFs(:,2,3));
   membDissocFlagCdc42 = membDissocFlagCdc42 & ~isGEF42_Cdc42idx;
   membDissocFlagGEF   = membDissocFlagGEF   & ~isGEF42_GEFidx;
   membAssocFlagCdc42  = membAssocFlagCdc42  |  isGEF42_Cdc42idx;
   membAssocFlagGEF    = membAssocFlagGEF    |  isGEF42_GEFidx;
      
   % Set association flag = 1 and dissociation flag = 0 if Cdc42-GTP 
   isCdc42T = ~logical(Cdc42s(:,2,5));
   membAssocFlagCdc42 (isCdc42T)  = 1;
   membDissocFlagCdc42(isCdc42T)  = 0;
   
   % Update the GEF and Cdc42 membrane states for the next step.
   GEFs  (membAssocFlagGEF   ,2,4) = 1;
   GEFs  (membDissocFlagGEF  ,2,4) = 0;
   Cdc42s(membAssocFlagCdc42 ,2,4) = 1;
   Cdc42s(membDissocFlagCdc42,2,4) = 0;
   
   % Make sure to set next value even if you didn't dissociate or associate
   GEFs(~membAssocFlagGEF     & ~membDissocFlagGEF, 2,4) = ...
       GEFs(~membAssocFlagGEF     & ~membDissocFlagGEF, 1,4);   
   Cdc42s(~membAssocFlagCdc42 & ~membDissocFlagCdc42, 2,4) = ...
       Cdc42s(~membAssocFlagCdc42 & ~membDissocFlagCdc42, 1,4);
   
   
   %% ---------------------------------------------------------
   % Perform diffusion calculations. Update newly-bound and
   % newly-dissociated molecules accordingly.
   %% ---------------------------------------------------------
   
   % Get flags for reactive species. (Cdc42+GEF<->GEF42)
   reactedFlagsCdc42 = ReactedFlags(reactFlagCdc42,dissocFlagCdc42);
   reactedFlagsGEF   = ReactedFlags(reactFlagGEF,dissocFlagGEF);
   
   % Get flags for non-reactive, molecularly assocated species.
   boundInertCdc42   = BoundInertFlags(reactedFlagsCdc42,Cdc42s(:,1,3));
   
   % Get flags for non-reactive, unbound species. 
   % Separate based on membrane or cytoplasmic.
   unboundInertCdc42c = UnboundInertFlags(reactedFlagsCdc42,GEFs  (:,1,3),Cdc42s(:,1,4),'cyto');
   unboundInertCdc42m = UnboundInertFlags(reactedFlagsCdc42,GEFs  (:,1,3),Cdc42s(:,1,4),'memb');
   unboundInertGEFc   = UnboundInertFlags(reactedFlagsGEF  ,Cdc42s(:,1,3),GEFs  (:,1,4),'cyto');
   unboundInertGEFm   = UnboundInertFlags(reactedFlagsGEF  ,Cdc42s(:,1,3),GEFs  (:,1,4),'memb');
   
   % Move GEF particles away from Cdc42 particles because of dissociation.
   [x_dissoc_displ,y_dissoc_displ] = ...
       CalcPos_Dissociation(dissocFlagGEF,GEFs(:,1,1),GEFs(:,1,2),xwin,ywin,sigma);
   
   GEFs(:,2,1) = x_dissoc_displ; % This needs to go first - this is the only 
   GEFs(:,2,2) = y_dissoc_displ; % position update that hits all particles.
   
   % Brownian diffusion only for non-reactive species.
   % Bound species are in the membrane. Move bound GEFs with Cdc42s.
   Cdc42s(boundInertCdc42          ,2,1) = calcPos(Cdc42s(boundInertCdc42,1,1),Dmemb,dt,xwin,r_diffusGEF42x(boundInertCdc42));
   Cdc42s(boundInertCdc42          ,2,2) = calcPos(Cdc42s(boundInertCdc42,1,2),Dmemb,dt,ywin,r_diffusGEF42y(boundInertCdc42));
   GEFs(Cdc42s(boundInertCdc42,1,3),2,1) = Cdc42s(boundInertCdc42,2,1);
   GEFs(Cdc42s(boundInertCdc42,1,3),2,2) = Cdc42s(boundInertCdc42,2,2);
   
   % Separately need to perform calculations using membrane and cytoplasmic
   % diffusivities. Start with the x-dimension.
   Cdc42s(unboundInertCdc42c,2,1) = calcPos(Cdc42s(unboundInertCdc42c,1,1),Dcyto,dt,xwin,r_diffusCdc42x(unboundInertCdc42c));
   Cdc42s(unboundInertCdc42m,2,1) = calcPos(Cdc42s(unboundInertCdc42m,1,1),Dmemb,dt,xwin,r_diffusCdc42x(unboundInertCdc42m));
   GEFs(unboundInertGEFc    ,2,1) = calcPos(GEFs(unboundInertGEFc,1,1)    ,Dcyto,dt,xwin,r_diffusGEFx(unboundInertGEFc));
   GEFs(unboundInertGEFm    ,2,1) = calcPos(GEFs(unboundInertGEFm,1,1)    ,Dmemb,dt,xwin,r_diffusGEFx(unboundInertGEFm));
   % Y-dimension, typical diffusion
   Cdc42s(unboundInertCdc42c,2,2) = calcPos(Cdc42s(unboundInertCdc42c,1,2),Dcyto,dt,ywin,r_diffusCdc42y(unboundInertCdc42c));
   Cdc42s(unboundInertCdc42m,2,2) = calcPos(Cdc42s(unboundInertCdc42m,1,2),Dmemb,dt,ywin,r_diffusCdc42y(unboundInertCdc42m));
   GEFs(unboundInertGEFc    ,2,2) = calcPos(GEFs(unboundInertGEFc,1,2)    ,Dcyto,dt,ywin,r_diffusGEFy(unboundInertGEFc));
   GEFs(unboundInertGEFm    ,2,2) = calcPos(GEFs(unboundInertGEFm,1,2)    ,Dmemb,dt,ywin,r_diffusGEFy(unboundInertGEFm));
   
   % Move GEF particles to Cdc42 particles because of new binding.
   GEFs(reactFlagGEF(:),2,1) = Cdc42s(reactFlagCdc42(:),2,1);
   GEFs(reactFlagGEF(:),2,2) = Cdc42s(reactFlagCdc42(:),2,2);
   

   if DEBUG_POSITION
      fprintf('coord Cdc42(1@%i): (%g,%g)\n',i,Cdc42s(1,2,1),Cdc42s(1,2,2));
   end
   
   if DEBUG_CDC42T_COUNT && (mod(i,100) ==0)      
      fprintf('count Cdc42T(@%i): %i\n',i,sum(~Cdc42s(:,1,5)));
   end
   
   
   %% ---------------------------------------------------------
   % Transfer timestep information within the matrices.
   %% ---------------------------------------------------------
   Cdc42s(:,1,1) = Cdc42s(:,2,1);
   Cdc42s(:,1,2) = Cdc42s(:,2,2);
   Cdc42s(:,1,3) = Cdc42s(:,2,3);
   Cdc42s(:,1,4) = Cdc42s(:,2,4);
   Cdc42s(:,1,5) = Cdc42s(:,2,5);
   
   GEFs(:,1,1)   = GEFs(:,2,1);
   GEFs(:,1,2)   = GEFs(:,2,2);
   GEFs(:,1,3)   = GEFs(:,2,3);
   GEFs(:,1,4)   = GEFs(:,2,4);
   
   %% ---------------------------------------------------------
   % Export data to a the CoordTracker matrix.
   % 1 - GEFc       4 - Cdc42Dc
   % 2 - GEFm       5 - Cdc42Dm
   % 3 - GEF42      6 - Cdc42T
   %% ---------------------------------------------------------
   if mod(i-1,datagrain) == 0
       grainstep = ceil(i/datagrain);
       
       CoordTracker(grainstep,        1:nGEFtot          ,1) = GEFs(:,1,1);
       CoordTracker(grainstep,        1:nGEFtot          ,2) = GEFs(:,1,2);
       CoordTracker(grainstep,nGEFtot+1:nCdc42tot+nGEFtot,1) = Cdc42s(:,1,1);
       CoordTracker(grainstep,nGEFtot+1:nCdc42tot+nGEFtot,2) = Cdc42s(:,1,2);
       
       % Stitch together binding information.
       retainedBindingFlagsCdc42 = RetainedBindingFlags(Cdc42s(:,1,3),dissocFlagCdc42);
       combinedBoundCdc42 = retainedBindingFlagsCdc42;
       combinedBoundCdc42(reactFlagCdc42) = true;
       combinedBoundGEF = Cdc42s(combinedBoundCdc42,1,3); 

       % Bound value refers to the index of the corresponding particle.
       boundGEF   = Cdc42s(combinedBoundCdc42,1,3);
       boundCdc42 = GEFs(combinedBoundGEF,1,3); 

       % Filter for unbound
       unboundGEF   = setdiff(1:nGEFtot,boundGEF);
       unboundCdc42 = setdiff(1:nCdc42tot,boundCdc42);

       % Filter for membrane association. 
       % Get index values, not logical indexes.
       unbound_membraneGEF   = intersect(unboundGEF,find(GEFs(:,1,4)));
       unbound_membraneCdc42 = intersect(unboundCdc42,find(Cdc42s(:,1,4)));

       unbound_cytoGEF       = setdiff(unboundGEF,unbound_membraneGEF);
       unbound_cytoCdc42     = setdiff(unboundCdc42,unbound_membraneCdc42);

       % Filter Cdc42s for GxP
       gdp_cdc42 = find(Cdc42s(:,1,5));
       unbound_membraneCdc42_gdp = intersect(gdp_cdc42,unbound_membraneCdc42);
       unbound_cytoCdc42_gdp     = intersect(gdp_cdc42,unbound_cytoCdc42);
       gtp_cdc42 = find(~Cdc42s(:,1,5)); % All Cdc42T
       GEF42s    = intersect(boundCdc42,gtp_cdc42); % All GEF42
       gtp_cdc42 = setdiff(gtp_cdc42,GEF42s); % Cdc42s without GEF bound

       % Export data to a the CoordTracker matrix.
       % 1 - GEFc       4 - Cdc42Dc
       % 2 - GEFm       5 - Cdc42Dm
       % 3 - GEF42      6 - Cdc42T
       % Note that GEF42s will be counted twice - one from Cdc42 particles 
       % and one from GEF particles
       CoordTracker(grainstep,        unbound_cytoGEF,          3) = 1;
       CoordTracker(grainstep,        unbound_membraneGEF,      3) = 2;
       CoordTracker(grainstep,        boundGEF,                 3) = 3;
       CoordTracker(grainstep,nGEFtot+unbound_cytoCdc42_gdp,    3) = 4;
       CoordTracker(grainstep,nGEFtot+unbound_membraneCdc42_gdp,3) = 5;
       CoordTracker(grainstep,nGEFtot+gtp_cdc42,                3) = 6;
       CoordTracker(grainstep,nGEFtot+GEF42s,                   3) = 3;
   end
end

%% ---------------------------------------------------------
% Timestep iteration over. Save data and clear objects.
%% ---------------------------------------------------------

time_whole = toc

% Save .mat files
data_mat = strcat(outfile,'_dat.mat');
save(data_mat,'CoordTracker');
clear CoordTracker;
output_mat = strcat(outfile,'_par.mat');
save(output_mat);

end

% Function to establish data structures.
function [outfile,todays_date]=SetFolderbyDate(filebasename)
if ispc
    todays_date = num2str(yyyymmdd(datetime)); % folder
    todays_date = strcat(todays_date,'\');
    outfile     = strcat(todays_date,'\',filebasename);
elseif ismac
    todays_date = num2str(yyyymmdd(datetime)); % folder
    todays_date = strcat(todays_date,'/');
    outfile     = strcat(todays_date,'/',filebasename);
elseif isunix
    % Minor difference from actual dirs in the *nix format..
    % pc and mac give YYYYMMDD
    % *nix gives YYYY_M_D, where M and D can have 1 or 2 digits. Added
    % underscores for clarity; just note you cannot integrate
    % *nix names directly with pc or mac names if automating analysis
    mytime=clock;
    mytime=mytime(1:3); % get YYYYMD only
    todays_date=strrep(regexprep(num2str(fix(mytime)),' +',' '),' ','_');
    todays_date = strcat(todays_date,'/');
    outfile     = strcat(todays_date,'/',filebasename);
end
end


% Function to calculate the lambda reaction probability rate. 
function [ lambda_targ ] = computeLambda(ktarg,r,s,d1,d2)
% Lambda depends on a macroscopic bimolecular rate constant ktarg,
% reaction capture radius r, and diffusion coefficients d1 and d2.
% Derived by M. Pablo for a 2D polar coordinate model based on the 2011
% Lipkova/Erban paper in SIAM J Appl. Math. Assumes ktarg is in units of
% 1/uM*s

liters_per_cubic_meters = 10^3;
microns_per_meter = 10^6;
micromoles_per_mol = 10^-6;
Nav = 6.02 * 10^23;
membThickness = 0.0083; % um

% Assuming ktarg is in units of 1/uM*s and converting to um^3/s
ktarg=ktarg * microns_per_meter^3 / ... 
        (liters_per_cubic_meters * micromoles_per_mol) / Nav;

% Converting now from um^3/s to um^2/s, adjusting it to a 2D rate constant
ktarg=ktarg / membThickness

% Solving this function's zeros returns lambda_targ
f =@(rho,sigma,Dtot,lambda)findRate_lim(rho,sigma,Dtot,lambda)-ktarg;

% Possible values of lambda (reasonable range to guess)
l=0.1:0.1:10^5; % --> May need to adjust this initial guess range depending on the kinetics specified.

% Find solutions for findRate_lim(lambda;rho,sigma,Dtot) = ktarg
t = f(r,s,d1+d2,l) > 0;
i0 = find(diff(t(:))~=0);
i0 = [i0(:)';i0(:)'+1];
n=size(i0,2);
xout = zeros(n,1);
rho=r;
sigma=s;
Dtot=d1+d2;
for jj = 1:n
    xout(jj) = fzero(@(lambda) f(rho,sigma,Dtot,lambda),l(i0(:,jj)));
end

lambda_targ=xout;
if isempty(lambda_targ)    
    error(strcat('Could not find a solution for lambda for rate',{' '},...
                 num2str(ktarg)));
end
end

% Analytic functions that relate macroscopic rate constant k to lambda and
% stochastic reaction parameters.
function [k] = findRate_lim(r,s,D,p)
% Analytic function k=f(lambda;r,D,p).
% Returns the synthesis rate constant in limiting case described.
% D is the sum of both diffusion constants.
% r is capture radius
% p is reaction probability.

    temp=r.*sqrt(p./D);

    if s >= r
        k = (D.*2.*pi.*temp.*(besseli(1,temp)./besseli(0,temp)))./...
                    (1+log(s./r).*temp.*(besseli(1,temp)./besseli(0,temp)));
    else
        error('Invalid choice of sigma and rho')
    end
end

% Used this form for early simulations, but can swap out for the _mex version.
function [d2] = SQeuclTorus(ZI,ZJ,FULLXWIN,FULLYWIN)
% Calculates squared euclidean distances between points on a periodic 2D plane.
% The plane is described xwin, ywin.
% the inputs:
%     ZI - some arbitrary 1-by-n vector that contains a single observation
%     from X or Y in pdist2(X,Y,@euclTorus(ZI,ZJ) euclTorus(X,Y,XWIN,YWIN))
%     ZJ - the m2-by-n matrix containing multiple observations from Y or X.
%the output:
%     d2 - an m2-by-1 vector of distances whose Jth element is the distance
%     between the observations ZI and ZJ(J,:).

diff=bsxfun(@minus,ZI,ZJ); % subtract each coordinate in the ZI observation...
                     % from each coordinate in the ZJ(j)-th observation.
                     % Return a matrix size ZJ.

% Take the sum of the minimized squares.
d2=bsxfun(@min,abs(diff(:,1)),FULLXWIN-abs(diff(:,1))).^2 + ...
   bsxfun(@min,abs(diff(:,2)),FULLYWIN-abs(diff(:,2))).^2;

end

% Function to obtain a collision matrix. The matrix is sorted, and the
% pre-sort indices are given alongside it.
function [sortedCollMat,sortedCollMatIdx] = getSortedCollisionMatrix(partsA,partsB,rad,xwin,ywin)
% Precalculate this for all explicit particles so I only need to do it once per step.

posA = squeeze(partsA(:,1,1:2)); % Squeeze to remove the singleton dimension
posB = squeeze(partsB(:,1,1:2));

% Calculate pairwise distances based on periodic 2D plane (torus)
collMat = pdist2(posA,posB,@(ZI,ZJ) SQeuclTorus(ZI,ZJ,xwin*2,ywin*2));
collMat(collMat>=(rad^2))=NULLVAL();
collMat(collMat<(rad^2))=false;
collMat(collMat==NULLVAL())=true;
[sortedCollMat,sortedCollMatIdx]=sort(collMat(:));
end

% Function to find paired association reactions
function [listA,listB] = getReactionList(sorted,sortedIDX,partsA,partsB,lambda1,lambda2,dt)
%  Returns flagged particle indices.

prob1 = lambda1*dt; % Membrane GEF
prob2 = lambda2*dt; % Cytosolic GEF
[numA,~,~] = size(partsA);
[numB,~,~] = size(partsB);

listA=zeros(numA,1);
listB=zeros(numB,1);
returnIndex=1;
for i=1:length(sortedIDX)
    if sorted(i) == true
        break;
    else
        idxA=mod(sortedIDX(i)-1,numA)+1;
        idxB=floor((sortedIDX(i)-1)/numA)+1;
        % Skip if the particle is in a complex already
        if partsA(idxA,1,3) ~= 0 || partsB(idxB,1,3) ~= 0
            continue;
        end
        % Skip if the Cdc42 is in the GDP bound state.
        if partsA(idxA,1,5) == 1
            continue;
        end
                
        % Use different probabilities depending on the state of the GEF.
        if     partsB(idxB,1,4) == 1 % Membrane bound
            prob = prob1;
        elseif partsB(idxB,1,4) == 0 % Cytosolic
            prob = prob2;
        end
        
        check=rand(1,1);
        if check<prob
            % Check if the particle is already flagged
            if max(max(idxA==listA)) || max(max(idxB==listB))
                continue;
            end
            listA(returnIndex)=idxA;
            listB(returnIndex)=idxB;
            returnIndex=returnIndex+1;
        end
    end
end
listA=listA(listA~=0);
listB=listB(listB~=0);
end

% Function to find paired dissociation reactions
% Uses A-particles as the reference.
function [dissocFlagA,dissocFlagB] = getDissocList(partsA,NB,kr,dt,rand_dissocAB)
probDissoc = dissociationProbability(kr,dt);
dissocFlagA = logical(rand_dissocAB < probDissoc);

% Set flags to zero if there is nothing bound
dissocFlagA=dissocFlagA & logical(partsA(:,1,3));    

dissocFlagB = false(NB,1);
dissocFlagB(partsA(dissocFlagA,1,3)) = 1; % Flag the corresponding partners

end

% Function to find Cdc42T hydrolysis reactions.
function [hydrolFlag] = getHydrolList(partsA,k,dt,rand_hydrol)
hydrolFlag = logical(rand_hydrol < hydrolysisProbability(k,dt));

% Require the molecule to originally be in Cdc42-GTP state with no GEF.
hasGTP   = ~logical(partsA(:,1,5));
hasNoGEF = ~logical(partsA(:,1,3)); 
hydrolFlag = hydrolFlag & hasGTP & hasNoGEF;
end

% Function to find membrane association reactions.
function [membraneAssocFlag] = getCdc42MembraneAssocList(partsA,k,dt,rand_membAssoc)
probMembAssoc = membraneAssocProbability(k,dt);
membraneAssocFlag = logical(rand_membAssoc < probMembAssoc);

% Require the molecule originally be in the cytosol.
isCytosolic = ~logical(partsA(:,1,4));
hasGDP      =  logical(partsA(:,1,5));
willhaveGDP =  logical(partsA(:,2,5)); % GxP exchange should be done by the time this is called.
membraneAssocFlag = membraneAssocFlag & isCytosolic & hasGDP & willhaveGDP;
end

% Function to find membrane dissociation reactions.
function [membraneDissocFlag] = getCdc42MembraneDissocList(partsA,k,dt,rand_membDissoc)
probMembDissoc = membraneDissocProbability(k,dt);
membraneDissocFlag = logical(rand_membDissoc < probMembDissoc);

% Require the molecule originally be in the membrane.
isInMembrane = logical(partsA(:,1,4));
hasGDP      = logical(partsA(:,1,5));
willhaveGDP = logical(partsA(:,2,5)); % GxP exchange should be done by the time this is called.
membraneDissocFlag = membraneDissocFlag & isInMembrane & hasGDP & willhaveGDP;
end

% Function to find membrane association reactions.
function [membraneAssocFlag] = getGEFMembraneAssocList(partsA,k,dt,rand_membAssoc)
probMembAssoc = membraneAssocProbability(k,dt);
membraneAssocFlag = logical(rand_membAssoc < probMembAssoc);

% Require the molecule originally be in the cytosol.
isCytosolic = ~logical(partsA(:,1,4));
membraneAssocFlag = membraneAssocFlag & isCytosolic;
end

% Function to find membrane dissociation reactions.
function [membraneDissocFlag] = getGEFMembraneDissocList(partsA,k,dt,rand_membDissoc)
probMembDissoc = membraneDissocProbability(k,dt);
membraneDissocFlag = logical(rand_membDissoc < probMembDissoc);

% Require the molecule originally be in the membrane.

% require the molecule to not have been previously bound to a Cdc42?

isInMembrane = logical(partsA(:,1,4));
membraneDissocFlag = membraneDissocFlag & isInMembrane;
end


% Function to find GEF-catalyzed GDP -> GTP exchange reactions.
% Cdc42 MUST be the first argument for GxP state checks.
function [found] = getExchangeList(sorted,sortedIDX,partsA,partsB,lambda2,lambda3,dt)

prob2 = lambda2*dt; % Membrane bound GEF
prob3 = lambda3*dt; % GEF42 complex
[numA,~,~]=size(partsA);
found=zeros(numA,1);
successfulCatalysis=[];
for i=1:length(sortedIDX)
    if sorted(i) == true
        break;
    end
    
    % Calling sort() unwrapped the matrix into a vector, so calculate
    % what matrix indices the vector index corresponds to.
    idxA=mod(sortedIDX(i)-1,numA)+1;
    idxB=floor((sortedIDX(i)-1)/numA)+1;

    % Skip if the Cdc42 has GTP bound or if it is in the cytoplasm
    if partsA(idxA,1,5) == 0 || partsA(idxA,1,4) == 0
        continue;
    end
    
    % Skip if the GEF is cytoplasmic.
    if partsB(idxB,1,4) == 0
        continue;
    end
    
    % Use different probabilities depending on the state of the GEF.
    if partsB(idxB,1,4) == 1 % Membrane bound
        prob = prob2;
    end
    if partsB(idxB,1,3) ~= 0 % Cdc42-GEF complex
        prob = prob3;
    end

    % If the GEF already has performed catalysis, skip.
    if max(max(idxB == successfulCatalysis))
        continue;
    end

    if rand(1,1) < prob
        if max(max(idxA==found))
            continue;
        end
        %fprintf('catalysis reaction\n');
        found(idxA) = idxA;
        successfulCatalysis=vertcat(successfulCatalysis,idxB);
    end
end
found=found(found~=0);
end

% Function to determine if dissociation happens
function [P] = dissociationProbability(k,dt)
P=1-exp(-k*dt);
end

% Function to determine if hydrolysis happens
function [P] = hydrolysisProbability(k,dt)
P=1-exp(-k*dt);
end

% Function to determine if membrane association happens.
function [P] = membraneAssocProbability(k,dt)
P=1-exp(-k*dt);
end

% Function to determine if membrane dissociation happens.
function [P] = membraneDissocProbability(k,dt)
P=1-exp(-k*dt);
end

% Function to perform a diffusion step
function [newPos] = calcPos(pos, D, dt, bound, z)
% The position function is updated (symetrically for x and y)
% as x(t+dt)=x(t)+sqrt(2D*dt)Z_i
% where
% x is a vector of coordinates (x1 = x, x2 = y)
% t is time
% dt is the timestep
% D is the diffusion coefficient of the particle
% Z_i is an vector of Gaussian random variable, mean=0, stdev=1

delta=sqrt(2*D*dt)*z;
newPos=pos+delta;

newPos=adjustForBounds(newPos,bound); 

end

% Function to adjust the input coordinates for the boundary conditions.
    % Can use as oldXY == newXY to see if a change occurs
function [pos] = adjustForBounds(pos, bound)

% PERIODIC BOUNDARIES MODE FOR VECTOR pos
timesExceeded=floor((abs(pos)+bound)/(2*bound));
pos = pos -sign(pos)* 2*bound.*timesExceeded;

end
        
% Function to represent a NULLVAL
function [val] = NULLVAL()
val=999999;
end

% Get a random number vector for dissociation reactions
% Maximal # needed is based on the limiting reagent
function [ret] = RandVec_Dissoc(N)
ret=rand(N,1);
end

% Get a random number vector for diffusion
% These are normal random numbers with mean zero and variance 1.
function [ret] = RandVec_Diffus(N)
ret=normrnd(0,1,N,1);
end

% Get a random number vector for GTP hydrolysis
function [ret] = RandVec_Hydrol(N)
ret = rand(N,1);
end

% Get a random number vector for membrane dissociation
function [ret] = RandVec_MembDissoc(N)
ret = rand(N,1);
end

% Get a random number vector for membrane association
function [ret] = RandVec_MembAssoc(N)
ret = rand(N,1);
end

% Compute new positions for all particles of A after dissociation from
% complexes AB. The B particles do not move.
% Expects oldApos as a Nx1 matrix in 1D, or Nx2 matrix in 2D.
function [newAposx,newAposy] = CalcPos_Dissociation(dissocFlagA,oldAposx,oldAposy,xwin,ywin,sigma)
randTheta = rand(length(dissocFlagA),1)*2*pi;

% In 2D
newAposx = oldAposx + sigma*cos(randTheta).*logical(dissocFlagA);
newAposy = oldAposy + sigma*sin(randTheta).*logical(dissocFlagA);

newAposx = adjustForBounds(newAposx,xwin);
newAposy = adjustForBounds(newAposy,ywin);
end

% Get flags for particles that have retained binding
function [flags] = RetainedBindingFlags(Abinders,Adissocs)
flags=logical(Abinders)&(~Adissocs);
end

% Get flags for particles that reacted this timestep
function [flags] = ReactedFlags(assocflags,dissocflags)
% Adissocs is NA x 1 vector
% Aassocs  is an arbitrarily sized vector with unique values [1,NA]
flags=logical(dissocflags);
flags(assocflags)=1;
end

% Get flags for particles that were unreactive but are bound to something
% Pass the reaction flags for A, and As(:,1,actualbounds)
function [flags] = BoundInertFlags(reactedflags,boundindexes)
flags= logical(boundindexes)&(~reactedflags);
end

% Get flags for particles that were unreactive and are not bound 
function [flags] = UnboundInertFlags(reactedflags,boundindexes,membdata,specialRule)

boundflags=zeros(length(membdata),1);
boundindexes=boundindexes(boundindexes~=0); % get index values of the bound speces of interest
boundflags(boundindexes)=1;
isInMembrane = logical(membdata);
if strcmp(specialRule,'cyto')   
    flags = (~boundflags) & (~reactedflags) & ~isInMembrane;
elseif strcmp(specialRule,'memb')
    flags = (~boundflags) & (~reactedflags) &  isInMembrane;
else
    error('Invalid argument to UnboundInertFlags');
end

end
