load('fig3_data');

figure;
% 2D, Cdc42Dm + BemGEFm -> Cdc42T
subplot(2,3,1); hold on
plot(panel1_pb.t,panel1_pb.y,'linewidth',4,'color',[0.929 0.694 0.125])
plot(panel1_fit.t,panel1_fit.y,'k');
axis([0 10 0 700]);
% 2D, Cdc42Dm + BemGEF42 -> Cdc42T
subplot(2,3,2); hold on
plot(panel2_pb.t,panel2_pb.y,'linewidth',4,'color',[0.929 0.694 0.125])
plot(panel2_fit.t,panel2_fit.y,'k');
axis([0 10 1000 1550]);
% 2D, BemGEFm + Cdc42T <-> BemGEF42
subplot(2,3,3); hold on
plot(panel3_pb.t,panel3_pb.y,'linewidth',4,'color',[0.929 0.694 0.125]);
plot(panel3_fit.t,panel3_fit.y,'k');
axis([0 5 0 1500]);
% q3D, Cdc42Dm + BemGEFm -> Cdc42T
subplot(2,3,4); hold on
plot(panel4_pb.t,panel4_pb.y,'linewidth',4,'color',[0.929 0.694 0.125]);
plot(panel4_fit.t,panel4_fit.y,'k');
axis([0 10 0 1500]);
% q3D, Cdc42Dm + BemGEF42 -> Cdc42T
subplot(2,3,5); hold on
plot(panel5_pb.t,panel5_pb.y,'linewidth',4,'color',[0.929 0.694 0.125]);
plot(panel5_fit.t,panel5_fit.y,'k');
axis([0 10 200 400]);
% q3D BemGEFm + Cdc42T <-> BemGEF42
subplot(2,3,6); hold on
plot(panel6_pb.t,panel6_pb.y,'linewidth',4,'color',[0.929 0.694 0.125]);
plot(panel6_fit.t,panel6_fit.y,'k');
axis([0 5 0 700]);
