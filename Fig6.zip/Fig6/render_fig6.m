%recalc_Hs;
load('fig6_data')



% Cdc42 bifurcation: 905 molecules
% GEF bifurcation: 24 molecules
% Domain bifurcation: 1.742 um2
figure('position',[1173 174 466 420]); hold on; box on; % Panel A, Cdc42
errorbar(trscrn4b_cdc42s,mean(trscrn4b_rde200s,2),std(trscrn4b_rde200s,[],2),...
         'linestyle','none','color','k','markerfacecolor',[1 1 0],'markeredgecolor','k',...
         'marker','^','markersize',8);
errorbar(trscrn4b_cdc42s,mean(trscrn4b_rde600s,2),std(trscrn4b_rde600s,[],2),...
         'linestyle','none','color','k','markerfacecolor',[1 0 0],'markeredgecolor','k',...
         'marker','square','markersize',8);
errorbar(trscrn4b_cdc42s,mean(trscrn4b_pb200s,2),std(trscrn4b_pb200s,[],2),...
         'linestyle','none','color','k','markerfacecolor',[0 0 1],'markeredgecolor','k',...
         'marker','o','markersize',8);
plot([905 905],[-1 2],'r--');
axis([0 2000 -0.1 1.1]);
set(gca,'fontsize',18)
xlabel('Cdc42 molecules');
ylabel('H(r=0.5 \mum)');
set(gca,'fontsize',20,'fontname','arial','linewidth',1.5)

figure('position',[1173 174 466 420]); hold on; box on; % Panel B, GEF
errorbar(trscrn4a_gefs,mean(trscrn4a_rde200s,2),std(trscrn4a_rde200s,[],2),...
         'linestyle','none','color','k','markerfacecolor',[1 1 0],'markeredgecolor','k',...
         'marker','^','markersize',8);
errorbar(trscrn4a_gefs,mean(trscrn4a_rde600s,2),std(trscrn4a_rde600s,[],2),...
         'linestyle','none','color','k','markerfacecolor',[1 0 0],'markeredgecolor','k',...
         'marker','square','markersize',8);
errorbar(trscrn4a_gefs,mean(trscrn4a_pb200s,2),std(trscrn4a_pb200s,[],2),...
         'linestyle','none','color','k','markerfacecolor',[0 0 1],'markeredgecolor','k',...
         'marker','o','markersize',8);
plot([24 24],[-1 2],'r--');
axis([0 120 -0.1 1.25]);
xlabel('GEF molecules');
ylabel('H(r=0.5 \mum)');
set(gca,'fontsize',20,'fontname','arial','linewidth',1.5)

figure('position',[1173 174 466 420]); hold on; box on; % Panel C, domain size
errorbar(trscrn3_domains,mean(trscrn3_rde200s,2),std(trscrn3_rde200s,[],2),...
         'linestyle','none','color','k','markerfacecolor',[1 1 0],'markeredgecolor','k',...
         'marker','^','markersize',8);
errorbar(trscrn3_domains,mean(trscrn3_rde600s,2),std(trscrn3_rde600s,[],2),...
         'linestyle','none','color','k','markerfacecolor',[1 0 0],'markeredgecolor','k',...
         'marker','square','markersize',8);
errorbar(trscrn3_domains,mean(trscrn3_pb200s,2),std(trscrn3_pb200s,[],2),...
         'linestyle','none','color','k','markerfacecolor',[0 0 1],'markeredgecolor','k',...
         'marker','o','markersize',8);
plot([1.742 1.742],[-1 2],'r--');
axis([0 29 -0.2 1.6]);
xlabel('Simulation domain (\mum^2)');
ylabel('H(r=0.5 \mum)');
set(gca,'fontsize',20,'fontname','arial','linewidth',1.5)
legend('RDE, t=200s','RDE, t=600s','PB, t=200s','Bifurcation','location','northwest')

     

