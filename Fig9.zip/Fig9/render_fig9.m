%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The H(r=2 um) timecourse panel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('fig9_timecourse');
colors=flipud(colors);
figure; hold on;
plot(pb1.t,pb1.h,'k','marker','square','markerfacecolor',colors(1,:),'markeredgecolor',colors(1,:));
plot(pb2.t,pb2.h,'k','marker','square','markerfacecolor',colors(2,:),'markeredgecolor',colors(2,:));
plot(pb3.t,pb3.h,'k','marker','square','markerfacecolor',colors(3,:),'markeredgecolor',colors(3,:));
plot(rde1.t,rde1.h,'k','marker','^','markerfacecolor',colors(1,:),'markeredgecolor',colors(1,:));
% order is flipped to get front/back arrangement the same as the main fig.
plot(rde3.t,rde3.h,'k','marker','^','markerfacecolor',colors(3,:),'markeredgecolor',colors(3,:));
plot(rde2.t,rde2.h,'k','marker','^','markerfacecolor',colors(2,:),'markeredgecolor',colors(2,:));
axis([0 1800 -0.1 3])


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The H(r) @ final time plots
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('fig9_Hcurves');
figure; hold on;
plot(pb1.r,pb1.h,'k','marker','square','markerfacecolor',colors(2,:),'markeredgecolor',colors(2,:));
plot(pb2.r,pb2.h,'k','marker','square','markerfacecolor',colors(3,:),'markeredgecolor',colors(3,:));
plot(pb3.r,pb3.h,'k','marker','square','markerfacecolor',colors(4,:),'markeredgecolor',colors(4,:));
plot(prepol.r,prepol.h,'k','marker','diamond','markerfacecolor',colors(1,:),'markeredgecolor','k');
axis([0 4 0 3])
