%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Componenets for Panel A.
%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('fig5a_data');
figure; hold on;
for i=1:5
    plot(pb_times,pb(i).H,'k','marker','square','markerfacecolor',colors(i,:),'markeredgecolor',colors(i,:));
end
axis([0 200 0 1.4])

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Componenets for Panel B.
%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('fig5b_data')
figure; hold on;
for i=1:5
    plot(rde_times,rde(i).H,'k','marker','square','markerfacecolor',colors(i,:),'markeredgecolor',colors(i,:));
end
axis([0 600 -0.2 1.6]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Componenets for Panel C.
%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('fig5c_data');
figure;
subplot(1,2,1); hold on;
plot(unif.r,unif.P,'k','linewidth',4);
plot(pol.r,pol.P,'r','linewidth',4);
axis([0 2.5 0 1.3]);
subplot(1,2,2); hold on;
plot(unif.r,unif.H,'k','linewidth',4);
plot(pol.r,pol.H,'r','linewidth',4);
axis([0 2.5 -0.2 2.2]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Componenets for Panel D.
%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('fig5d_data');
figure;
idx = 1;
for i=1:5
    for j=1:2
        subplot(5,2,idx);
        hold on;
        plot(pb_coords{i,j}.x,pb_coords{i,j}.y,'linestyle','none','marker','.','color',colors(i,:));
        plot([-2 -1.5],[-2 -2],'k','linewidth',4);
        set(gca,'xtick',[],'ytick',[])
        axis image
        axis([-2.57 2.57 -2.57 2.57]);
        idx = idx+1;
    end
end