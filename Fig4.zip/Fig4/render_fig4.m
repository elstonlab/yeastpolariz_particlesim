%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Componenets for Panel A.
%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('fig4A_pbdata')
figure; % Particle-based part of panel A.
% 1 second PB simulation
subplot(1,3,1); hold on; box on;
plot(pb_1s.x,pb_1s.y,'r.','linestyle','none','markersize',6);
plot([-2 -1.5],[-2 -2],'k','linewidth',4)
axis([-2.57 2.57 -2.57 2.57]);
axis image;
set(gca,'xtick',[],'ytick',[])
% 100 second PB simulation
subplot(1,3,2); hold on; box on;
plot(pb_100s.x,pb_100s.y,'r.','linestyle','none','markersize',6);
plot([-2 -1.5],[-2 -2],'k','linewidth',4)
axis([-2.57 2.57 -2.57 2.57]);
axis image;
set(gca,'xtick',[],'ytick',[])
% 200 second PB simulation
subplot(1,3,3); hold on; box on;
plot(pb_200s.x,pb_200s.y,'r.','linestyle','none','markersize',6);
plot([-2 -1.5],[-2 -2],'k','linewidth',4)
axis([-2.57 2.57 -2.57 2.57]);
axis image;
set(gca,'xtick',[],'ytick',[])

load('fig4A_RDEdata');

figure; % Reaction-diffusion part of panel A.
colormap(jet);
% 1 second RDE simulation
subplot(1,3,1); hold on; box on; 
imagesc(RDE_1s.x,RDE_1s.y,RDE_1s.c);
plot([-2 -1.5],[-2 -2],'k','linewidth',4);
axis([-2.57 2.57 -2.57 2.57]);
axis image
set(gca,'xtick',[],'ytick',[]);
clb=colorbar;
clb.Location = 'SouthOutside';
set(gca,'clim',[0 3000]);

subplot(1,3,2); hold on; box on; 
imagesc(RDE_100s.x,RDE_100s.y,RDE_100s.c);
plot([-2 -1.5],[-2 -2],'k','linewidth',4);
axis([-2.57 2.57 -2.57 2.57]);
axis image
set(gca,'xtick',[],'ytick',[]);
clb=colorbar;
clb.Location = 'SouthOutside';
set(gca,'clim',[0 3000]);

subplot(1,3,3); hold on; box on; 
imagesc(RDE_200s.x,RDE_200s.y,RDE_200s.c);
plot([-2 -1.5],[-2 -2],'k','linewidth',4);
axis([-2.57 2.57 -2.57 2.57]);
axis image
set(gca,'xtick',[],'ytick',[]);
clb=colorbar;
clb.Location = 'SouthOutside';
set(gca,'clim',[0 3000]);

figure; % The last panel for the RDE;
        % Easier to have separate color scaling on a new figure
colormap(jet)
subplot(1,3,3); hold on; box on; % to enforce same sizing
imagesc(RDE_600s.x,RDE_600s.y,RDE_600s.c);
plot([-2 -1.5],[-2 -2],'k','linewidth',4);
axis([-2.57 2.57 -2.57 2.57]);
axis image
set(gca,'xtick',[],'ytick',[]);
clb=colorbar;
clb.Location = 'SouthOutside';
set(gca,'clim',[0 100000]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Componenets for Panel B.
%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('fig4B_data');
figure;
histogram2('xbinedges',pb_hist.xedges,'ybinedges',pb_hist.yedges,'bincounts',pb_hist.values,'facecolor','r')
figure;
histogram2('xbinedges',rde_hist.xedges,'ybinedges',rde_hist.yedges,'bincounts',rde_hist.values,'facecolor','r')