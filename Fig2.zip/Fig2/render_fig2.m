figure; hold on
load('fig2_data');
plot(D,y1,'-.k');
plot(D,y2,'r-')
plot(D,y3,'--','color',[0 0.5 0.4]);
plot(D,y4','marker','diamond','linestyle','none','markerfacecolor',[0.85 0.65 0.13],'markeredgecolor','none');
set(gca,'xlim',[10^-6 10^0],'ylim',[10^-6 10^-1],'xscale','log','yscale','log');
